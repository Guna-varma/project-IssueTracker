-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: issuetracker
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `assignee` varchar(255) DEFAULT NULL,
  `attributeDate1` datetime(6) DEFAULT NULL,
  `attributeDate10` datetime(6) DEFAULT NULL,
  `attributeDate11` datetime(6) DEFAULT NULL,
  `attributeDate12` datetime(6) DEFAULT NULL,
  `attributeDate13` datetime(6) DEFAULT NULL,
  `attributeDate14` datetime(6) DEFAULT NULL,
  `attributeDate15` datetime(6) DEFAULT NULL,
  `attributeDate16` datetime(6) DEFAULT NULL,
  `attributeDate17` datetime(6) DEFAULT NULL,
  `attributeDate18` datetime(6) DEFAULT NULL,
  `attributeDate19` datetime(6) DEFAULT NULL,
  `attributeDate2` datetime(6) DEFAULT NULL,
  `attributeDate20` datetime(6) DEFAULT NULL,
  `attributeDate3` datetime(6) DEFAULT NULL,
  `attributeDate4` datetime(6) DEFAULT NULL,
  `attributeDate5` datetime(6) DEFAULT NULL,
  `attributeDate6` datetime(6) DEFAULT NULL,
  `attributeDate7` datetime(6) DEFAULT NULL,
  `attributeDate8` datetime(6) DEFAULT NULL,
  `attributeDate9` datetime(6) DEFAULT NULL,
  `attributeMultiLineString1` longtext,
  `attributeMultiLineString10` longtext,
  `attributeMultiLineString2` longtext,
  `attributeMultiLineString3` longtext,
  `attributeMultiLineString4` longtext,
  `attributeMultiLineString5` longtext,
  `attributeMultiLineString6` longtext,
  `attributeMultiLineString7` longtext,
  `attributeMultiLineString8` longtext,
  `attributeMultiLineString9` longtext,
  `attributeMultilineTextField1` mediumtext,
  `attributeMultilineTextField10` mediumtext,
  `attributeMultilineTextField2` mediumtext,
  `attributeMultilineTextField3` mediumtext,
  `attributeMultilineTextField4` mediumtext,
  `attributeMultilineTextField5` mediumtext,
  `attributeMultilineTextField6` mediumtext,
  `attributeMultilineTextField7` mediumtext,
  `attributeMultilineTextField8` mediumtext,
  `attributeMultilineTextField9` mediumtext,
  `attributeNumberField1` float DEFAULT NULL,
  `attributeNumberField10` float DEFAULT NULL,
  `attributeNumberField2` float DEFAULT NULL,
  `attributeNumberField3` float DEFAULT NULL,
  `attributeNumberField4` float DEFAULT NULL,
  `attributeNumberField5` float DEFAULT NULL,
  `attributeNumberField6` float DEFAULT NULL,
  `attributeNumberField7` float DEFAULT NULL,
  `attributeNumberField8` float DEFAULT NULL,
  `attributeNumberField9` float DEFAULT NULL,
  `attributeNumericField1` int DEFAULT NULL,
  `attributeNumericField10` int DEFAULT NULL,
  `attributeNumericField2` int DEFAULT NULL,
  `attributeNumericField3` int DEFAULT NULL,
  `attributeNumericField4` int DEFAULT NULL,
  `attributeNumericField5` int DEFAULT NULL,
  `attributeNumericField6` int DEFAULT NULL,
  `attributeNumericField7` int DEFAULT NULL,
  `attributeNumericField8` int DEFAULT NULL,
  `attributeNumericField9` int DEFAULT NULL,
  `attributePickList1` json DEFAULT NULL,
  `attributePickList10` json DEFAULT NULL,
  `attributePickList2` json DEFAULT NULL,
  `attributePickList3` json DEFAULT NULL,
  `attributePickList4` json DEFAULT NULL,
  `attributePickList5` json DEFAULT NULL,
  `attributePickList6` json DEFAULT NULL,
  `attributePickList7` json DEFAULT NULL,
  `attributePickList8` json DEFAULT NULL,
  `attributePickList9` json DEFAULT NULL,
  `attributeSingleLine1` text,
  `attributeSingleLine10` text,
  `attributeSingleLine2` text,
  `attributeSingleLine3` text,
  `attributeSingleLine4` text,
  `attributeSingleLine5` text,
  `attributeSingleLine6` text,
  `attributeSingleLine7` text,
  `attributeSingleLine8` text,
  `attributeSingleLine9` text,
  `attributeTextField1` varchar(255) DEFAULT NULL,
  `attributeTextField10` varchar(255) DEFAULT NULL,
  `attributeTextField2` varchar(255) DEFAULT NULL,
  `attributeTextField3` varchar(255) DEFAULT NULL,
  `attributeTextField4` varchar(255) DEFAULT NULL,
  `attributeTextField5` varchar(255) DEFAULT NULL,
  `attributeTextField6` varchar(255) DEFAULT NULL,
  `attributeTextField7` varchar(255) DEFAULT NULL,
  `attributeTextField8` varchar(255) DEFAULT NULL,
  `attributeTextField9` varchar(255) DEFAULT NULL,
  `attributeUserPickList1` json DEFAULT NULL,
  `attributeUserPickList10` json DEFAULT NULL,
  `attributeUserPickList2` json DEFAULT NULL,
  `attributeUserPickList3` json DEFAULT NULL,
  `attributeUserPickList4` json DEFAULT NULL,
  `attributeUserPickList5` json DEFAULT NULL,
  `attributeUserPickList6` json DEFAULT NULL,
  `attributeUserPickList7` json DEFAULT NULL,
  `attributeUserPickList8` json DEFAULT NULL,
  `attributeUserPickList9` json DEFAULT NULL,
  `createdAt` datetime(6) NOT NULL,
  `description` varchar(255) NOT NULL,
  `issueStatus` varchar(255) DEFAULT NULL,
  `issueTypeId` bigint NOT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `projectId` bigint NOT NULL,
  `reporter` varchar(255) DEFAULT NULL,
  `resolution` varchar(255) DEFAULT NULL,
  `summary` varchar(255) NOT NULL,
  `updatedAt` datetime(6) NOT NULL,
  `votes` bigint DEFAULT NULL,
  `watches` bigint DEFAULT NULL,
  `workflowId` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgcaav2w259iyppwx23ofjcglg` (`issueTypeId`),
  KEY `FK1frl9pi4ao9d5paae71amxx1g` (`projectId`),
  CONSTRAINT `FK1frl9pi4ao9d5paae71amxx1g` FOREIGN KEY (`projectId`) REFERENCES `project` (`id`),
  CONSTRAINT `FKgcaav2w259iyppwx23ofjcglg` FOREIGN KEY (`issueTypeId`) REFERENCES `issuetype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (1,'Akshay Kalia','2016-10-10 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:12:47.915000','Issue In Bug Tracker description',NULL,1,'LOW',2,'Miteanjay','Resolved','Bug Tracker Summary','2023-04-05 18:12:47.915000',NULL,NULL,NULL),(2,'Miteanjay Kumar','2017-05-11 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','Issue In Issue Tracker description',NULL,2,'HIGH',1,'Miteanjay','UnResolved','Issue Tracker SUmmary','2023-04-05 18:14:47.915000',NULL,NULL,NULL),(3,'Meda Guna Varma','2018-04-05 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','Bug In Issue Tracker description',NULL,1,'MEDIUM',3,'Shashi Kumar','DONE','Bug In Issue Tracker','2023-04-05 18:15:47.915000',NULL,NULL,NULL),(4,'Shashi Kumar Yadav','2019-04-11 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','Bug In Project description',NULL,3,'LOWEST',3,'Shashi Kumar','UnResolved','Bug In Project','2023-04-05 18:15:14.915000',NULL,NULL,NULL),(5,'Shashi Kumar Yadav','2020-11-01 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','FeedBack for Collector description','',4,'HIGH',2,'Somiya Parmar','DONE','FeedBack for Collector','2023-04-05 18:16:15.915000',NULL,NULL,NULL),(6,'Akshay kalia','2021-05-10 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','Improvement description',NULL,2,'MEDIUM',1,'Somiya Parmar','Resolved','Improvement','2023-04-05 18:17:45.915000',NULL,NULL,NULL),(7,'Somiya Parmar','2023-09-27 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','Error in TDS',NULL,1,'LOWEST',3,'Guna Varma','DONE','TDS Error in Salary Module','2023-04-05 18:20:47.915000',NULL,NULL,NULL),(8,'Miteanjay Kumar','2023-11-04 00:00:00.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2023-04-05 18:14:47.915000','Sample Testing of Epic',NULL,3,'LOWEST',1,'GunaVarma','Resolved','Epic Sample1','2023-04-05 18:22:47.915000',NULL,NULL,NULL);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-04-11 17:00:26
