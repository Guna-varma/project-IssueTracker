package cubastion.xnet.issuetracker.xnet_issuetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XnetIssueTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
