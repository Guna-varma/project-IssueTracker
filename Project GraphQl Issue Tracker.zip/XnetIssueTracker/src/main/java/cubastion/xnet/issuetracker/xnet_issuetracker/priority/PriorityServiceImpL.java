package cubastion.xnet.issuetracker.xnet_issuetracker.priority;

import java.util.List;
import java.util.Optional;

public interface PriorityServiceImpL {

    Priority addPriority(Priority priority);

    List<Priority> getAllPriority();

    Optional<Priority> getPriorityById(Long id);

    Priority updatePriority(Priority priority);

    String deletePriorityById(Long id);

}
