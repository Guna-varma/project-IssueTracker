package cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity;

import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "actionTable")
public class ActionTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "issueId")
    private Long issueId;

    @Column(name = "author")
    private String author;

    @Column(name = "actionType")
    private String actionType;

    @Column(name = "actionLevel")
    private String actionLevel;

    @Column(name = "roleLevel")
    private String roleLevel;

    @Column(name = "actionBody")
    private String actionBody;

    @Column(name = "actionNumber")
    private Long actionNumber;

    @CreationTimestamp
    @Column(name = "createdAt", nullable = false, updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updatedAt", nullable = false)
    private Date updateAt;

    @ManyToOne
    @JoinColumn(name = "issueId", insertable = false, updatable = false)
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private Issues issues;





}
