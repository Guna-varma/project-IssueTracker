package cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class ActionTableInput {
    private Long issueId;
    private String author;
    private String actionType;
    private String actionLevel;
    private String roleLevel;
    private String actionBody;
    private Long actionNumber;

}
