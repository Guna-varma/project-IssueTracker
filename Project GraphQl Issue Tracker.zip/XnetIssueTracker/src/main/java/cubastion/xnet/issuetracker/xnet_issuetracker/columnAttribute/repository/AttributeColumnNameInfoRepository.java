package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.NativeQuery;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeDisplayName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AttributeColumnNameInfoRepository extends JpaRepository<AttributeColumnNameInfo, Long> {

    @Query(value = NativeQuery.FindFindAvailableColumnQuery, nativeQuery = true)
    String findFindAvailableColumn(Long issueTypeId, Long dataTypeId);

     AttributeColumnNameInfo findByAttributeKey(String name);

}