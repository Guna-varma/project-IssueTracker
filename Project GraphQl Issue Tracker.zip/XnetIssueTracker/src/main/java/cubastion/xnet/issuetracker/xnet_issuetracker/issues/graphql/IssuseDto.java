package cubastion.xnet.issuetracker.xnet_issuetracker.issues.graphql;

import lombok.Data;

@Data
public class IssuseDto {
    String key;
    String value;
    String keyColumnName;
    String keyDisplayName;
}
