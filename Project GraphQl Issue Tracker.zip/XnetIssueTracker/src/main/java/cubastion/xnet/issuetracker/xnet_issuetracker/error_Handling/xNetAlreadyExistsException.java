package cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling;

import java.util.Map;

public class xNetAlreadyExistsException extends AbstractGraphQLException {


    public xNetAlreadyExistsException(String message) {
        super(message);
    }

    public xNetAlreadyExistsException(String message, Map<String, Object> additionParams) {
        super(message, additionParams);
    }

}
