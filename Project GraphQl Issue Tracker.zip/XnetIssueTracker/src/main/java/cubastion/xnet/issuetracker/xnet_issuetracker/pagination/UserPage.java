package cubastion.xnet.issuetracker.xnet_issuetracker.pagination;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import lombok.*;

import java.util.List;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserPage {
//    private DataClass data;
    private List<User> data;
    private Pagination pagination;
    private int totalRecords;
    private int totalPerPage;
    private int totalPage;
    private int currentPage;
    private int nextPage;
    private int previousPage;
}
