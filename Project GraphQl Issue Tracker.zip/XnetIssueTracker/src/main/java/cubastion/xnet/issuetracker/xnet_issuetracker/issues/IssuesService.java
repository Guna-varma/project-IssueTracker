package cubastion.xnet.issuetracker.xnet_issuetracker.issues;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.RulesExecutor;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeColumnNameInfoRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeDisplayNameRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service.AttributeDisplayNameService;
import cubastion.xnet.issuetracker.xnet_issuetracker.config.Utility;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterFields;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JoinFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JunctionTableFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.MultiFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.graphql.IssuseDTOcollection;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.graphql.IssuseDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.Pagination;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses.IssuesPaginationResponse;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.Issues_User_Roles_Repo;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.AutomationLOV.ISSUECREATED;
import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.AutomationLOV.ISSUEUPDATE;

@Service
public class IssuesService implements IssuesServiceImpL {

    @Autowired
    private IssuesRepository repo;

    @Autowired
    private AttributeDisplayNameService service;
    @Autowired
    private JoinFiltersSpecification<Issues> IssuesFiltersSpecification;

    @Autowired
    private MultiFiltersSpecification<Issues> IssuesMultiFiltersSpecification;

    @Autowired
    private JunctionTableFiltersSpecification<Issues> junctionTableFiltersSpecification;

    @Autowired
    AttributeColumnNameInfoRepository attributeColumnNameInfoRepository;

    @Autowired
    AttributeDisplayNameRepository attributeDisplayNameRepository;

    @Autowired
    Issues_User_Roles_Repo issuesUserRolesRepo;

    @Autowired
    RulesExecutor rulesExecutor;
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    EntityManager entityManager;

    @Override
    public Issues add(Issues issues) {
        try {
            Issues reis = repo.save(issues);

            Boolean response = rulesExecutor.executeRulesForIssues(ISSUECREATED, reis.getId());
            if (response) {
                return repo.findById(reis.getId()).orElse(null);
            } else {
                return reis;
            }
        } catch (Exception e) {
            throw new xNetInvalidInputException("Invalid Input at Issues List : Please add Input fields!");
        }
    }

    public Boolean ruleConditionValidation(String columnName, String columnValue, Long id) {
        Boolean res = false;
        try {
            DataSource dataSource = jdbcTemplate.getDataSource();
            Connection con = DataSourceUtils.getConnection(dataSource);
            Statement s = con.createStatement();
            String query = "select * from issues where " + columnName + " = '" + columnValue + "' AND id = " + id;
            ResultSet resultSet = s.executeQuery(query);
            res = resultSet.next();
            JdbcUtils.closeStatement(s);
            DataSourceUtils.releaseConnection(con, dataSource);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return res;
    }

    public Boolean issueAssigneeUpdate(Long id, String assignee) {
        Issues issues = repo.findById(id).orElse(null);
        issues.setAssignee(assignee);
        Long r_id = repo.save(issues).getId();
        return r_id > 0;
    }

    @Override
    public List<Issues> getAll() {
        List<Issues> issuesList = null;
        try {
            issuesList = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (issuesList.isEmpty()) throw new xNetNotFoundException("Issues List is Null");
        return issuesList;
    }

    @Override
    public Optional<Issues> getIssuesById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(() -> new xNetNotFoundException("Issues with ID: " + String.valueOf(id) + " is not found")));
    }

    @Override
    public String deleteIssues(Long id) {
        repo.deleteById(id);
        return "Issue of Id: '" + String.valueOf(id) + "' deleted Successfully!";
    }

    public Issues update(Long id, Issues issues) {
//        Issues updateI = updateReq(id, issues);
//        return repo.save(updateI);
        try {
            Issues updateI = updateReq(id, issues);
            Issues issueUpdate = repo.save(updateI);

            Boolean response = rulesExecutor.executeRulesForIssues(ISSUEUPDATE, issueUpdate.getId());
            if (response) {
                return repo.findById(issueUpdate.getId()).orElse(null);
            } else {
                return issueUpdate;
            }
        } catch (Exception e) {
            throw new xNetInvalidInputException("Invalid Input: Please add valid Input fields!");
        }
    }

    public Issues dtoToIssuseData(IssuseDTOcollection issuseDTOcollection) {
        Issues i = new Issues();
        try {
            ArrayList<IssuseDto> issueDtoArrayList = issuseDTOcollection.getIssuseDtoArrayList();
            for (IssuseDto issuseDto : issueDtoArrayList) {
                String cname = getColumnNameByKey(issuseDto.getKey());
                String keyCname = issuseDto.getKeyColumnName();
                if (!cname.equals(keyCname)) {
                    throw new xNetInvalidInputException("Please add Correct Column Name! " + keyCname);
                }

                switch (cname) {
                    case "id":
                        i.setId(Long.valueOf(issuseDto.getValue()));
                        break;
                    case "issueTypeId":
                        if (Long.valueOf(issuseDto.getValue()) > 0) {
                            i.setIssueTypeId(Long.valueOf(issuseDto.getValue()));
                        } else {
                            throw new xNetInvalidInputException("Please add valid issueTypeId !");
                        }
                        break;
                    case "projectId":
                        if (Long.valueOf(issuseDto.getValue()) > 0) {
                            i.setProjectId(Long.valueOf(issuseDto.getValue()));
                        } else {
                            throw new xNetInvalidInputException("Please add valid projectId !");
                        }
                        break;
                    case "summary":
                        i.setSummary(issuseDto.getValue());
                        break;
                    case "description":
                        i.setDescription(issuseDto.getValue());
                        break;
                    case "reporter":
                        i.setReporter(issuseDto.getValue());
                        break;
                    case "assignee":
                        i.setAssignee(issuseDto.getValue());
                        break;
                    case "priority":
                        i.setPriority(issuseDto.getValue());
                        break;
                    case "resolution":
                        i.setResolution(issuseDto.getValue());
                        break;
                    case "issueStatus":
                        i.setIssueStatus(issuseDto.getValue());
                        break;
                    case "votes":
                        i.setVotes(Long.valueOf(issuseDto.getValue()));
                        break;
                    case "watches":
                        i.setWatches(Long.valueOf(issuseDto.getValue()));
                        break;
                    case "workflowId":
                        i.setWorkflowId(Long.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate1":
                        i.setAttributeDate1(Utility.parseDate(issuseDto.getValue()));
                        break;
                    case "attributeDate2":
                        i.setAttributeDate2(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate3":
                        i.setAttributeDate3(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate4":
                        i.setAttributeDate4(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate5":
                        i.setAttributeDate5(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate6":
                        i.setAttributeDate6(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate7":
                        i.setAttributeDate7(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate8":
                        i.setAttributeDate8(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate9":
                        i.setAttributeDate9(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate10":
                        i.setAttributeDate10(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate11":
                        i.setAttributeDate11(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate12":
                        i.setAttributeDate12(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate13":
                        i.setAttributeDate13(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate14":
                        i.setAttributeDate14(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate15":
                        i.setAttributeDate15(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate16":
                        i.setAttributeDate16(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate17":
                        i.setAttributeDate17(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate18":
                        i.setAttributeDate18(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate19":
                        i.setAttributeDate19(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeDate20":
                        i.setAttributeDate20(Date.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeSingleLine1":
                        i.setAttributeSingleLine1(issuseDto.getValue());
                        break;
                    case "attributeSingleLine2":
                        i.setAttributeSingleLine2(issuseDto.getValue());
                        break;
                    case "attributeSingleLine3":
                        i.setAttributeSingleLine3(issuseDto.getValue());
                        break;
                    case "attributeSingleLine4":
                        i.setAttributeSingleLine4(issuseDto.getValue());
                        break;
                    case "attributeSingleLine5":
                        i.setAttributeSingleLine5(issuseDto.getValue());
                        break;
                    case "attributeSingleLine6":
                        i.setAttributeSingleLine6(issuseDto.getValue());
                        break;
                    case "attributeSingleLine7":
                        i.setAttributeSingleLine7(issuseDto.getValue());
                        break;
                    case "attributeSingleLine8":
                        i.setAttributeSingleLine8(issuseDto.getValue());
                        break;
                    case "attributeSingleLine9":
                        i.setAttributeSingleLine9(issuseDto.getValue());
                        break;
                    case "attributeSingleLine10":
                        i.setAttributeSingleLine10(issuseDto.getValue());
                        break;


                    case "attributeNumericField1":
                        i.setAttributeNumericField1(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField2":
                        i.setAttributeNumericField2(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField3":
                        i.setAttributeNumericField3(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField4":
                        i.setAttributeNumericField4(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField5":
                        i.setAttributeNumericField5(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField6":
                        i.setAttributeNumericField6(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField7":
                        i.setAttributeNumericField7(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField8":
                        i.setAttributeNumericField8(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField9":
                        i.setAttributeNumericField9(Integer.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumericField10":
                        i.setAttributeNumericField10(Integer.valueOf(issuseDto.getValue()));
                        break;

                    case "attributeNumberField1":
                        i.setAttributeNumberField1(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField2":
                        i.setAttributeNumberField2(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField3":
                        i.setAttributeNumberField3(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField4":
                        i.setAttributeNumberField4(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField5":
                        i.setAttributeNumberField5(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField6":
                        i.setAttributeNumberField6(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField7":
                        i.setAttributeNumberField7(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField8":
                        i.setAttributeNumberField8(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField9":
                        i.setAttributeNumberField9(Float.valueOf(issuseDto.getValue()));
                        break;
                    case "attributeNumberField10":
                        i.setAttributeNumberField10(Float.valueOf(issuseDto.getValue()));
                        break;


                    case "attributeTextField1":
                        i.setAttributeTextField1(issuseDto.getValue());
                        break;
                    case "attributeTextField2":
                        i.setAttributeTextField2(issuseDto.getValue());
                        break;
                    case "attributeTextField3":
                        i.setAttributeTextField3(issuseDto.getValue());
                        break;
                    case "attributeTextField4":
                        i.setAttributeTextField4(issuseDto.getValue());
                        break;
                    case "attributeTextField5":
                        i.setAttributeTextField5(issuseDto.getValue());
                        break;
                    case "attributeTextField6":
                        i.setAttributeTextField6(issuseDto.getValue());
                        break;
                    case "attributeTextField7":
                        i.setAttributeTextField7(issuseDto.getValue());
                        break;
                    case "attributeTextField8":
                        i.setAttributeTextField8(issuseDto.getValue());
                        break;
                    case "attributeTextField9":
                        i.setAttributeTextField9(issuseDto.getValue());
                        break;
                    case "attributeTextField10":
                        i.setAttributeTextField10(issuseDto.getValue());
                        break;


                    case "attributeMultilineTextField1":
                        i.setAttributeMultilineTextField1(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField2":
                        i.setAttributeMultilineTextField2(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField3":
                        i.setAttributeMultilineTextField3(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField4":
                        i.setAttributeMultilineTextField4(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField5":
                        i.setAttributeMultilineTextField5(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField6":
                        i.setAttributeMultilineTextField6(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField7":
                        i.setAttributeMultilineTextField7(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField8":
                        i.setAttributeMultilineTextField8(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField9":
                        i.setAttributeMultilineTextField9(issuseDto.getValue());
                        break;
                    case "attributeMultilineTextField10":
                        i.setAttributeMultilineTextField10(issuseDto.getValue());
                        break;


                    case "attributeMultiLineString1":
                        i.setAttributeMultiLineString1(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString2":
                        i.setAttributeMultiLineString2(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString3":
                        i.setAttributeMultiLineString3(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString4":
                        i.setAttributeMultiLineString4(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString5":
                        i.setAttributeMultiLineString5(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString6":
                        i.setAttributeMultiLineString6(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString7":
                        i.setAttributeMultiLineString7(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString8":
                        i.setAttributeMultiLineString8(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString9":
                        i.setAttributeMultiLineString9(issuseDto.getValue());
                        break;
                    case "attributeMultiLineString10":
                        i.setAttributeMultiLineString10(issuseDto.getValue());
                        break;


                    case "attributeUserPickList1":
                        i.setAttributeUserPickList1(issuseDto.getValue());
                        break;
                    case "attributeUserPickList2":
                        i.setAttributeUserPickList2(issuseDto.getValue());
                        break;
                    case "attributeUserPickList3":
                        i.setAttributeUserPickList3(issuseDto.getValue());
                        break;
                    case "attributeUserPickList4":
                        i.setAttributeUserPickList4(issuseDto.getValue());
                        break;
                    case "attributeUserPickList5":
                        i.setAttributeUserPickList5(issuseDto.getValue());
                        break;
                    case "attributeUserPickList6":
                        i.setAttributeUserPickList6(issuseDto.getValue());
                        break;
                    case "attributeUserPickList7":
                        i.setAttributeUserPickList7(issuseDto.getValue());
                        break;
                    case "attributeUserPickList8":
                        i.setAttributeUserPickList8(issuseDto.getValue());
                        break;
                    case "attributeUserPickList9":
                        i.setAttributeUserPickList9(issuseDto.getValue());
                        break;
                    case "attributeUserPickList10":
                        i.setAttributeUserPickList10(issuseDto.getValue());
                        break;


                    case "attributePickList1":
                        i.setAttributePickList1(issuseDto.getValue());
                        break;
                    case "attributePickList2":
                        i.setAttributePickList2(issuseDto.getValue());
                        break;
                    case "attributePickList3":
                        i.setAttributePickList3(issuseDto.getValue());
                        break;
                    case "attributePickList4":
                        i.setAttributePickList4(issuseDto.getValue());
                        break;
                    case "attributePickList5":
                        i.setAttributePickList5(issuseDto.getValue());
                        break;
                    case "attributePickList6":
                        i.setAttributePickList6(issuseDto.getValue());
                        break;
                    case "attributePickList7":
                        i.setAttributePickList7(issuseDto.getValue());
                        break;
                    case "attributePickList8":
                        i.setAttributePickList8(issuseDto.getValue());
                        break;
                    case "attributePickList9":
                        i.setAttributePickList9(issuseDto.getValue());
                        break;
                    case "attributePickList10":
                        i.setAttributePickList10(issuseDto.getValue());
                        break;
                }
            }
        } catch (Exception e) {
            throw new xNetInvalidInputException("Invalid Input, Please add a issue fields");
        }
        return i;
    }


    public String getColumnNameByKey(String key) {
        AttributeColumnNameInfo attributeColumnNameInfo = attributeColumnNameInfoRepository.findByAttributeKey(key);
        String cName = attributeColumnNameInfo.getAttributeColumnName();
        return cName;
    }


    public Issues updateReq(Long id, Issues issues) {

        Issues i = repo.findById(id).orElseThrow(() -> new xNetNotFoundException("Issues Not found!, Please mention correct issues Id"));

        if (issues.getAssignee() != null) {
            i.setAssignee(issues.getAssignee());
        }
        if (issues.getDescription() != null) {
            i.setDescription(issues.getDescription());
        }
        if (issues.getIssueStatus() != null) {
            i.setIssueStatus(issues.getIssueStatus());
        }
        if (issues.getIssueTypeId() != null) {
            i.setIssueTypeId(issues.getIssueTypeId());
        }
        if (issues.getPriority() != null) {
            i.setPriority(issues.getPriority());
        }
        if (issues.getProjectId() != null) {
            i.setProjectId(issues.getProjectId());
        }
        if (issues.getDescription() != null) {
            i.setDescription(issues.getDescription());
        }
        if (issues.getReporter() != null) {
            i.setReporter(issues.getReporter());
        }
        if (issues.getResolution() != null) {
            i.setResolution(issues.getResolution());
        }
        if (issues.getSummary() != null) {
            i.setSummary(issues.getSummary());
        }
        if (issues.getVotes() != null) {
            i.setVotes(issues.getVotes());
        }
        if (issues.getWatches() != null) {
            i.setWatches(issues.getWatches());
        }
        if (issues.getWorkflowId() != null) {
            i.setWorkflowId(issues.getWorkflowId());
        }

        if (issues.getAttributeDate1() != null) {
            i.setAttributeDate1(issues.getAttributeDate1());
        }
        if (issues.getAttributeDate2() != null) {
            i.setAttributeDate2(issues.getAttributeDate2());
        }
        if (issues.getAttributeDate3() != null) {
            i.setAttributeDate3(issues.getAttributeDate3());
        }
        if (issues.getAttributeDate4() != null) {
            i.setAttributeDate4(issues.getAttributeDate4());
        }
        if (issues.getAttributeDate5() != null) {
            i.setAttributeDate5(issues.getAttributeDate5());
        }
        if (issues.getAttributeDate6() != null) {
            i.setAttributeDate6(issues.getAttributeDate6());
        }
        if (issues.getAttributeDate7() != null) {
            i.setAttributeDate7(issues.getAttributeDate7());
        }
        if (issues.getAttributeDate8() != null) {
            i.setAttributeDate8(issues.getAttributeDate8());
        }
        if (issues.getAttributeDate9() != null) {
            i.setAttributeDate9(issues.getAttributeDate9());
        }
        if (issues.getAttributeDate10() != null) {
            i.setAttributeDate10(issues.getAttributeDate10());
        }
        if (issues.getAttributeDate11() != null) {
            i.setAttributeDate11(issues.getAttributeDate11());
        }
        if (issues.getAttributeDate12() != null) {
            i.setAttributeDate12(issues.getAttributeDate12());
        }
        if (issues.getAttributeDate13() != null) {
            i.setAttributeDate13(issues.getAttributeDate13());
        }
        if (issues.getAttributeDate14() != null) {
            i.setAttributeDate14(issues.getAttributeDate14());
        }
        if (issues.getAttributeDate15() != null) {
            i.setAttributeDate15(issues.getAttributeDate15());
        }
        if (issues.getAttributeDate16() != null) {
            i.setAttributeDate16(issues.getAttributeDate16());
        }
        if (issues.getAttributeDate17() != null) {
            i.setAttributeDate17(issues.getAttributeDate17());
        }
        if (issues.getAttributeDate18() != null) {
            i.setAttributeDate18(issues.getAttributeDate18());
        }
        if (issues.getAttributeDate19() != null) {
            i.setAttributeDate9(issues.getAttributeDate19());
        }
        if (issues.getAttributeDate20() != null) {
            i.setAttributeDate20(issues.getAttributeDate20());
        }


        if (issues.getAttributeMultiLineString1() != null) {
            i.setAttributeMultiLineString1(issues.getAttributeMultiLineString1());
        }
        if (issues.getAttributeMultiLineString2() != null) {
            i.setAttributeMultiLineString2(issues.getAttributeMultiLineString2());
        }
        if (issues.getAttributeMultiLineString3() != null) {
            i.setAttributeMultiLineString3(issues.getAttributeMultiLineString3());
        }
        if (issues.getAttributeMultiLineString4() != null) {
            i.setAttributeMultiLineString4(issues.getAttributeMultiLineString4());
        }
        if (issues.getAttributeMultiLineString5() != null) {
            i.setAttributeMultiLineString5(issues.getAttributeMultiLineString5());
        }
        if (issues.getAttributeMultiLineString6() != null) {
            i.setAttributeMultiLineString6(issues.getAttributeMultiLineString6());
        }
        if (issues.getAttributeMultiLineString7() != null) {
            i.setAttributeMultiLineString7(issues.getAttributeMultiLineString7());
        }
        if (issues.getAttributeMultiLineString8() != null) {
            i.setAttributeMultiLineString8(issues.getAttributeMultiLineString8());
        }
        if (issues.getAttributeMultiLineString9() != null) {
            i.setAttributeMultiLineString9(issues.getAttributeMultiLineString9());
        }
        if (issues.getAttributeMultiLineString10() != null) {
            i.setAttributeMultiLineString10(issues.getAttributeMultiLineString10());
        }


        if (issues.getAttributeMultilineTextField1() != null) {
            i.setAttributeMultilineTextField1(issues.getAttributeMultilineTextField1());
        }
        if (issues.getAttributeMultilineTextField2() != null) {
            i.setAttributeMultilineTextField2(issues.getAttributeMultilineTextField2());
        }
        if (issues.getAttributeMultilineTextField3() != null) {
            i.setAttributeMultilineTextField3(issues.getAttributeMultilineTextField3());
        }
        if (issues.getAttributeMultilineTextField4() != null) {
            i.setAttributeMultilineTextField4(issues.getAttributeMultilineTextField4());
        }
        if (issues.getAttributeMultilineTextField5() != null) {
            i.setAttributeMultilineTextField5(issues.getAttributeMultilineTextField5());
        }
        if (issues.getAttributeMultilineTextField6() != null) {
            i.setAttributeMultilineTextField6(issues.getAttributeMultilineTextField6());
        }
        if (issues.getAttributeMultilineTextField7() != null) {
            i.setAttributeMultilineTextField7(issues.getAttributeMultilineTextField7());
        }
        if (issues.getAttributeMultilineTextField8() != null) {
            i.setAttributeMultilineTextField8(issues.getAttributeMultilineTextField8());
        }
        if (issues.getAttributeMultilineTextField9() != null) {
            i.setAttributeMultilineTextField9(issues.getAttributeMultilineTextField9());
        }
        if (issues.getAttributeMultilineTextField10() != null) {
            i.setAttributeMultilineTextField10(issues.getAttributeMultilineTextField10());
        }


        if (issues.getAttributeNumericField1() != null) {
            i.setAttributeNumericField1(issues.getAttributeNumericField1());
        }
        if (issues.getAttributeNumericField2() != null) {
            i.setAttributeNumericField2(issues.getAttributeNumericField2());
        }
        if (issues.getAttributeNumericField3() != null) {
            i.setAttributeNumericField3(issues.getAttributeNumericField3());
        }
        if (issues.getAttributeNumericField4() != null) {
            i.setAttributeNumericField4(issues.getAttributeNumericField4());
        }
        if (issues.getAttributeNumericField5() != null) {
            i.setAttributeNumericField5(issues.getAttributeNumericField5());
        }
        if (issues.getAttributeNumericField6() != null) {
            i.setAttributeNumericField6(issues.getAttributeNumericField6());
        }
        if (issues.getAttributeNumericField7() != null) {
            i.setAttributeNumericField7(issues.getAttributeNumericField7());
        }
        if (issues.getAttributeNumericField8() != null) {
            i.setAttributeNumericField8(issues.getAttributeNumericField8());
        }
        if (issues.getAttributeNumericField9() != null) {
            i.setAttributeNumericField9(issues.getAttributeNumericField9());
        }
        if (issues.getAttributeNumericField10() != null) {
            i.setAttributeNumericField10(issues.getAttributeNumericField10());
        }


        if (issues.getAttributeNumberField1() != null) {
            i.setAttributeNumberField1(issues.getAttributeNumberField1());
        }
        if (issues.getAttributeNumberField2() != null) {
            i.setAttributeNumberField2(issues.getAttributeNumberField2());
        }
        if (issues.getAttributeNumberField3() != null) {
            i.setAttributeNumberField3(issues.getAttributeNumberField3());
        }
        if (issues.getAttributeNumberField4() != null) {
            i.setAttributeNumberField4(issues.getAttributeNumberField4());
        }
        if (issues.getAttributeNumberField5() != null) {
            i.setAttributeNumberField5(issues.getAttributeNumberField5());
        }
        if (issues.getAttributeNumberField1() != null) {
            i.setAttributeNumberField1(issues.getAttributeNumberField1());
        }
        if (issues.getAttributeNumberField6() != null) {
            i.setAttributeNumberField6(issues.getAttributeNumberField6());
        }
        if (issues.getAttributeNumberField7() != null) {
            i.setAttributeNumberField7(issues.getAttributeNumberField7());
        }
        if (issues.getAttributeNumberField8() != null) {
            i.setAttributeNumberField8(issues.getAttributeNumberField8());
        }
        if (issues.getAttributeNumberField9() != null) {
            i.setAttributeNumberField9(issues.getAttributeNumberField9());
        }
        if (issues.getAttributeNumberField10() != null) {
            i.setAttributeNumberField10(issues.getAttributeNumberField10());
        }


        if (issues.getAttributePickList1() != null) {
            i.setAttributePickList1(issues.getAttributePickList1());
        }
        if (issues.getAttributePickList2() != null) {
            i.setAttributePickList2(issues.getAttributePickList2());
        }
        if (issues.getAttributePickList3() != null) {
            i.setAttributePickList3(issues.getAttributePickList3());
        }
        if (issues.getAttributePickList4() != null) {
            i.setAttributePickList4(issues.getAttributePickList4());
        }
        if (issues.getAttributePickList5() != null) {
            i.setAttributePickList5(issues.getAttributePickList5());
        }
        if (issues.getAttributePickList6() != null) {
            i.setAttributePickList6(issues.getAttributePickList6());
        }
        if (issues.getAttributePickList7() != null) {
            i.setAttributePickList7(issues.getAttributePickList7());
        }
        if (issues.getAttributePickList8() != null) {
            i.setAttributePickList8(issues.getAttributePickList8());
        }
        if (issues.getAttributePickList9() != null) {
            i.setAttributePickList9(issues.getAttributePickList9());
        }
        if (issues.getAttributePickList10() != null) {
            i.setAttributePickList10(issues.getAttributePickList10());
        }


        if (issues.getAttributeSingleLine1() != null) {
            i.setAttributeSingleLine1(issues.getAttributeSingleLine1());
        }
        if (issues.getAttributeSingleLine2() != null) {
            i.setAttributeSingleLine2(issues.getAttributeSingleLine2());
        }
        if (issues.getAttributeSingleLine3() != null) {
            i.setAttributeSingleLine3(issues.getAttributeSingleLine3());
        }
        if (issues.getAttributeSingleLine4() != null) {
            i.setAttributeSingleLine4(issues.getAttributeSingleLine4());
        }
        if (issues.getAttributeSingleLine5() != null) {
            i.setAttributeSingleLine5(issues.getAttributeSingleLine5());
        }
        if (issues.getAttributeSingleLine6() != null) {
            i.setAttributeSingleLine6(issues.getAttributeSingleLine6());
        }
        if (issues.getAttributeSingleLine7() != null) {
            i.setAttributeSingleLine7(issues.getAttributeSingleLine7());
        }
        if (issues.getAttributeSingleLine8() != null) {
            i.setAttributeSingleLine8(issues.getAttributeSingleLine8());
        }
        if (issues.getAttributeSingleLine9() != null) {
            i.setAttributeSingleLine9(issues.getAttributeSingleLine9());
        }
        if (issues.getAttributeSingleLine10() != null) {
            i.setAttributeSingleLine10(issues.getAttributeSingleLine10());
        }


        if (issues.getAttributeTextField1() != null) {
            i.setAttributeTextField1(issues.getAttributeTextField1());
        }
        if (issues.getAttributeTextField2() != null) {
            i.setAttributeTextField2(issues.getAttributeTextField2());
        }
        if (issues.getAttributeTextField3() != null) {
            i.setAttributeTextField3(issues.getAttributeTextField3());
        }
        if (issues.getAttributeTextField4() != null) {
            i.setAttributeTextField4(issues.getAttributeTextField4());
        }
        if (issues.getAttributeTextField5() != null) {
            i.setAttributeTextField5(issues.getAttributeTextField5());
        }
        if (issues.getAttributeTextField6() != null) {
            i.setAttributeTextField6(issues.getAttributeTextField6());
        }
        if (issues.getAttributeTextField7() != null) {
            i.setAttributeTextField7(issues.getAttributeTextField7());
        }
        if (issues.getAttributeTextField8() != null) {
            i.setAttributeTextField8(issues.getAttributeTextField8());
        }
        if (issues.getAttributeTextField9() != null) {
            i.setAttributeTextField9(issues.getAttributeTextField9());
        }
        if (issues.getAttributeTextField10() != null) {
            i.setAttributeTextField10(issues.getAttributeTextField10());
        }


        if (issues.getAttributeUserPickList1() != null) {
            i.setAttributeUserPickList1(issues.getAttributeUserPickList1());
        }
        if (issues.getAttributeUserPickList2() != null) {
            i.setAttributeUserPickList2(issues.getAttributeUserPickList2());
        }
        if (issues.getAttributeUserPickList3() != null) {
            i.setAttributeUserPickList3(issues.getAttributeUserPickList3());
        }
        if (issues.getAttributeUserPickList4() != null) {
            i.setAttributeUserPickList4(issues.getAttributeUserPickList4());
        }
        if (issues.getAttributeUserPickList5() != null) {
            i.setAttributeUserPickList5(issues.getAttributeUserPickList5());
        }
        if (issues.getAttributeUserPickList6() != null) {
            i.setAttributeUserPickList6(issues.getAttributeUserPickList6());
        }
        if (issues.getAttributeUserPickList7() != null) {
            i.setAttributeUserPickList7(issues.getAttributeUserPickList7());
        }
        if (issues.getAttributeUserPickList8() != null) {
            i.setAttributeUserPickList8(issues.getAttributeUserPickList8());
        }
        if (issues.getAttributeUserPickList9() != null) {
            i.setAttributeUserPickList9(issues.getAttributeUserPickList9());
        }
        if (issues.getAttributeUserPickList10() != null) {
            i.setAttributeUserPickList10(issues.getAttributeUserPickList10());
        }
        return i;
    }

    @Override
    public List<Issues> issuesWithFilter(FilterKey filter) {
        Specification<Issues> spec = new FilterSpecification<Issues>().fSpecWithFilter(filter);

        for (FilterFields filterField : filter.getKey()) {
            if ((filterField.getOperator().isEmpty() | filterField.getKeyValue().isEmpty())) {
                throw new xNetInvalidInputException(" 'keyValue' or 'operator' is Empty, Please add valid Inputs..!");
            } else {
                return repo.findAll(spec);
            }
        }
        return (List<Issues>) spec;
    }

    public Page<Issues> issuesPage(Integer pageNumber, Integer pageSize) {
        pageNumber--;

        if (pageNumber < 0) {
            throw new xNetInvalidInputException("pageNumber should be Valid..!");
        } else {
            PageRequest pr = PageRequest.of(pageNumber, pageSize);
            return repo.findAll(pr);
        }

    }

    public IssuesPaginationResponse<List<Issues>> issuesPagination(Integer pageNumber, Integer offset) {
        pageNumber--;
        if (pageNumber < 0 | offset < 1) {
            throw new xNetInvalidInputException("Invalid input, please enter Valid pageNumber & offset..!");
        } else {
            PageRequest p = PageRequest.of(pageNumber, offset);
            Page<Issues> pageUser = this.repo.findAll(p);
            List<Issues> data = pageUser.getContent();

            if (data == null | data.isEmpty()) {
                throw new xNetNotFoundException("Data Not Found in this page..!");
            }
            return new IssuesPaginationResponse<List<Issues>>(data, new Pagination((int) pageUser.getTotalElements(), p.getPageSize(), pageUser.getTotalPages(), p.getPageNumber() + 1, Math.min(p.getPageNumber() + 2, pageUser.getTotalPages()), p.getPageNumber()));
        }
    }

    public List<Issues> issuesJoinFilter(RequestDto requestDto) {
        Specification<Issues> searchSpecification = IssuesFiltersSpecification.getSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());
        try {
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return repo.findAll(searchSpecification);
                }
            }
        } catch (Exception e) {
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return repo.findAll(searchSpecification);
    }

    public List<Issues> issuesMultiJoinFilter(RequestDto requestDto) {
        Specification<Issues> searchSpecification = IssuesMultiFiltersSpecification.getMultiSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());
        try {
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable1().isEmpty() | searchRequestDto.getJoinTable2().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable1' or 'JoinTable2' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return repo.findAll(searchSpecification);
                }
            }
        } catch (Exception e) {
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return repo.findAll(searchSpecification);
    }

    public List<Issues> issueJunctionTableFilter(RequestDto requestDto) {
        Specification<Issues> searchSpecification = junctionTableFiltersSpecification.getMultiSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());
        try {
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable1().isEmpty() | searchRequestDto.getJoinTable2().isEmpty() | searchRequestDto.getJoinTable3().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable1' or 'JoinTable2' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return repo.findAll(searchSpecification);
                }
            }
        } catch (Exception e) {
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return repo.findAll(searchSpecification);

    }
}