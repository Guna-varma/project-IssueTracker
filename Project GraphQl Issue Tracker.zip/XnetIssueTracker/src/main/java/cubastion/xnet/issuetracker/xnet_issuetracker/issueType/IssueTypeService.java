package cubastion.xnet.issuetracker.xnet_issuetracker.issueType;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IssueTypeService implements IssueTypeServiceImpL{

    @Autowired
    private IssueTypeRepository repo;

    @Override
    public IssueType addIssueType(IssueType issueType) {
        try{
            return repo.save(issueType);
        }catch (Exception e){
            throw new xNetInvalidInputException("Failed to create IssueType : Please add Input fields!");
        }
    }

    @Override
    public List<IssueType> getAllIssueType() {
        List<IssueType> issueTypeList = null;
        try{
            issueTypeList = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (issueTypeList.isEmpty())
            throw new xNetNotFoundException("IssueType List is Null");
        return issueTypeList;
    }

    @Override
    public Optional<IssueType> getIssueTypeById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("Issue type with ID: " + String.valueOf(id) + " is not found")
        ));
    }

    @Override
    public IssueType updateIssueType(IssueType issueType) {
        return null;
    }

    @Override
    public String deleteIssueType(Long id) {
        repo.deleteById(id);
        return "IssueType Id: "+id+" is deleted suucessfully!";
    }

}