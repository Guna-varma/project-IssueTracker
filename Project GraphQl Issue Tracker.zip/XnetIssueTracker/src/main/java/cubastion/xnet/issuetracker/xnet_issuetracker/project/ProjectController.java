package cubastion.xnet.issuetracker.xnet_issuetracker.project;

import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterFields;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses.ProjectPaginationResponse;
import cubastion.xnet.issuetracker.xnet_issuetracker.project.graphql.ProjectDto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProjectRepo projectRepo;

    @MutationMapping
    private Project addProject(@Argument(name = "addProjectInput") ProjectDto projectDto){
            Project pdto=new Project();
            pdto.setId(projectDto.getId());
            pdto.setProjectKey(projectDto.getProjectKey());
            pdto.setProjectName(projectDto.getProjectName());
            pdto.setProjectDescription(projectDto.getProjectDescription());
            pdto.setProjectLead(projectDto.getProjectLead());
            pdto.setAssigneeType(projectDto.getAssigneeType());
            pdto.setUrl(projectDto.getUrl());
            return projectService.addProject(pdto);
    }

    @QueryMapping
    private List<Project> getAllProject() {
        return projectService.getAll();
    }

    @QueryMapping
    private Project getProjectById(@Argument Long id){
            return projectService.getProjectById(id);


    }

    @MutationMapping
    private Project updateProject(@Argument("updateProjectInput") Project project){
        return projectService.update(project);
    }

    @QueryMapping
    public List<Project> withDynamicSearch() {
        return projectService.findProjectsWithPredicate();
    }

    @QueryMapping
    public List<Project> projectWithFilter(@Argument("filter") FilterKey filter) {
        return projectService.projectWithFilter(filter);
    }

    private Specification<Project> getSpecification(FilterFields filterField, String key) {
        return (root, query, builder) -> filterField.generateCriteria(builder, root.get(key));
    }

    @QueryMapping
    public ProjectPaginationResponse<List<Project>> projectPagination(@Argument("page") Integer pageNumber, @Argument("offset") Integer offset){
        return projectService.projectPagination(pageNumber,offset);
    }

    @QueryMapping
    public List<Project> projectJoinFilter(@Argument("filter") RequestDto requestDto){
        return projectService.projectJoinFilter(requestDto);
    }

    @QueryMapping
    public List<Project> projectMultiJoinFilter(@Argument("filter") RequestDto requestDto){
        return projectService.projectMultiJoinFilter(requestDto);
    }

    @QueryMapping
    public List<Project> projectJunctionTableFilter(@Argument("filter") RequestDto requestDto){
        return projectService.projectJunctionTableFilter(requestDto);
    }

}
