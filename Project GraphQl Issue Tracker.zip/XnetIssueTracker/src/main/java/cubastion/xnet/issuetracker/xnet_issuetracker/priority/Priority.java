package cubastion.xnet.issuetracker.xnet_issuetracker.priority;

import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "priority")
public class Priority {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "projectId")
    private Long projectId;

    @NotBlank
    @Column(name = "priorityName",nullable = false)
    private String priorityName;

    @Column(name = "description")
    private String description;

    @Column(name = "iconColor")
    private String iconColor;

    @Column(name = "statusColor")
    private String statusColor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projectId",insertable = false,updatable = false)
    private Project project;

}