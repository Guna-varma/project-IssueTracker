package cubastion.xnet.issuetracker.xnet_issuetracker.users.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql.AddProjectUserRolesInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.service.Project_User_Role_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class Project_User_Roles_Controller {

    @Autowired
    private Project_User_Role_Service service;

    @MutationMapping
    private PROJECT_USER_ROLES_TABLE addProjectUserRole(@Argument("addProjectUserRoleInput") AddProjectUserRolesInput input){

        PROJECT_USER_ROLES_TABLE u = new PROJECT_USER_ROLES_TABLE();
            if (input.getProjectId() > 0) {
                u.setProjectId(input.getProjectId());
            } else {
                throw new xNetInvalidInputException("Please Enter valid ProjectId");
            }
            if (input.getRoleId() > 0) {
                u.setRoleId(input.getRoleId());
            } else {
                throw new xNetInvalidInputException("please Enter Valid RoleId");
            }
            if(input.getUserId()>0){
                u.setUserId(input.getUserId());
            }else {
                throw new xNetInvalidInputException("Please Enter valid UserId!");
            }
            return service.addProjectUserRoles(u);

    }

    @QueryMapping
    private List<PROJECT_USER_ROLES_TABLE> getAllProjectUserRoles(){
        return service.getAllProjectUserRoles();
    }

    @QueryMapping
    private Optional<PROJECT_USER_ROLES_TABLE> getProjectUserRoleById(@Argument Long id){
        return service.getProjectUserById(id);
    }
}
