package cubastion.xnet.issuetracker.xnet_issuetracker.users.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterFields;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JoinFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JunctionTableFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.MultiFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.Pagination;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.UserPage;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses.UserPaginationResponse;
import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.serviceImpl.UserServiceImpL;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;


import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
//@Transactional
public class UserService implements UserServiceImpL {


    @Autowired
    private JoinFiltersSpecification<User> userFiltersSpecification;

    @Autowired
    private MultiFiltersSpecification<User> userMultiFiltersSpecification;

    @Autowired
    private JunctionTableFiltersSpecification<User> junctionTableFiltersSpecification;
    @Autowired
    private UserRepository repo;

    @Autowired
    private JavaMailSender emailSender;

    @Override
    public User add(User user) {
        try {
            return repo.save(user);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create User: Please add Input fields!");
        }
    }




    @Override
    public List<User> getAll() {
        List<User> users = null;
        try {
            users = (List<User>) repo.findAll();

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (users.isEmpty())
            throw new xNetNotFoundException("Users List is Null");
        return users;
    }

    @Override
    public Optional<User> getUserById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("User with ID: " + String.valueOf(id) + " is not found")
        ));
    }

    @Override
    public String delete(Long id) {
        repo.deleteById(id);
        return "User Id: " + id + " Deleted Successfully!";
    }


    @Override
    public User update(User user) {
        User u = repo.findById(user.getId()).orElseThrow(
                () -> new xNetNotFoundException("User Not found")
        );
        if (user.getUserName() != null) {
            u.setUserName(user.getUserName());
        }
        if (user.getActive() != null) {
            u.setActive(user.getActive());
        }
        if (user.getEmail() != null) {
            u.setEmail(user.getEmail());
        }
        if (user.getPassword() != null) {
            u.setPassword(user.getPassword());
        }
        if (user.getFullName() != null) {
            u.setFullName(user.getFullName());
        }
        return repo.save(u);
    }

    @Override
    public List<User> userWithFilter(FilterKey filter) {
        Specification<User> spec = new FilterSpecification<User>().fSpecWithFilter(filter);

        for (FilterFields filterField : filter.getKey()) {
            if ((filterField.getOperator().isEmpty() | filterField.getKeyValue().isEmpty())) {
                throw new xNetInvalidInputException(" 'keyValue' or 'operator' is Empty, Please add valid Inputs..!");
            } else {
                return repo.findAll(spec);
            }
        }
        return (List<User>) spec;
    }

    public Page<User> userPage(Integer pageNumber, Integer offSet) {
        pageNumber--;

        if (pageNumber < 0) {
            throw new xNetInvalidInputException("pageNumber should be Valid..!");
        } else {
            PageRequest pr = PageRequest.of(pageNumber, offSet);
            return repo.findAll(pr);
        }
    }

    public UserPaginationResponse<List<User>> userPagination(Integer pageNumber, Integer offset) {
        pageNumber--;
        if (pageNumber < 0 | offset<1 ) {
            throw new xNetInvalidInputException("Invalid input, please enter Valid pageNumber & offset..!");
        } else {
            PageRequest p = PageRequest.of(pageNumber, offset);
            Page<User> pageUser = this.repo.findAll(p);
            List<User> userData = pageUser.getContent();

            if (userData == null | userData.isEmpty()) {
                throw new xNetNotFoundException("Data Not Found in this page..!");
            }

            return new UserPaginationResponse<>(
                    userData,
                    new Pagination(
                            (int) pageUser.getTotalElements(),
                            p.getPageSize(),
                            pageUser.getTotalPages(),
                            p.getPageNumber() + 1,
                            Math.min(p.getPageNumber() + 2, pageUser.getTotalPages()),
                            p.getPageNumber()
                    )
            );
        }
    }

    public UserPage userPageNew(Integer page, Integer offSet) {
        page--;
        if (page < 0) {
            throw new xNetInvalidInputException("Invalid PageNumber, please enter Valid PageNumber..!");
        } else {
            Pageable pageable = PageRequest.of(page, offSet);
            Page<User> pageUser = repo.findAll(pageable);

            // Convert Page<User> to UserPage GraphQL type
            List<User> userData = pageUser.getContent();

            Pagination p = new Pagination(
                    (int) pageUser.getTotalElements(),
                    pageable.getPageSize(),
                    pageUser.getTotalPages(),
                    pageable.getPageNumber() + 1,
                    Math.min(pageable.getPageNumber() + 2, pageUser.getTotalPages()),
                    pageable.getPageNumber()
            );

            UserPage userPageResponse = new UserPage();
            userPageResponse.setData(userData);
            userPageResponse.setPagination(p);

            return userPageResponse;
        }
    }

    public List<User> userJoinFilter(RequestDto requestDto) {
        Specification<User> searchSpecification = userFiltersSpecification
                .getSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());

        try{
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return repo.findAll(searchSpecification);
                }
            }
        } catch (Exception e){
            throw new xNetInvalidInputException("Please Add valid 'JoinTable' or 'Column' name");
        }
        return repo.findAll(searchSpecification);
    }

    public List<User> userMultiJoinFilter(RequestDto requestDto) {
        Specification<User> searchSpecification = userMultiFiltersSpecification
                .getMultiSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());

        try{
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable1().isEmpty() | searchRequestDto.getJoinTable2().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable1' or 'JoinTable2' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return repo.findAll(searchSpecification);
                }
            }
        } catch (Exception e){
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return repo.findAll(searchSpecification);
    }

    public List<User> userJunctionTableFilter(RequestDto requestDto) {
        Specification<User> searchSpecification = junctionTableFiltersSpecification.getMultiSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());

        try{
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable1().isEmpty() | searchRequestDto.getJoinTable2().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable1' or 'JoinTable2' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return repo.findAll(searchSpecification);
                }
            }
        } catch (Exception e){
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return repo.findAll(searchSpecification);
    }

    public List<User> findAllUsersByRoleIdAndIssueId(String[] roleIds, Long issueId) {
        return repo.findAllUsersByRoleIdAndIssueId(roleIds,issueId);
    }

    public List<User> findAllUsersByRoleId(String[] roleIds) {
        return repo.findAllUsersByRoleId(roleIds);
    }



}
