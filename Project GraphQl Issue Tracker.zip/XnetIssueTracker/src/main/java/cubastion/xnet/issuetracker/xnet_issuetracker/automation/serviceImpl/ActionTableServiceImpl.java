package cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionLevel;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.ActionTableRepository;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ActionTableServiceImpl {
    @Autowired
    private ActionTableRepository actionTableRepository;
    public ActionTable createActionTable(ActionTable actionTable) {
        return actionTableRepository.save(actionTable);

    }

    public String deleteActionTableById(Long id) {
        actionTableRepository.deleteById(id);
        return "Priority Id: "+id+" Deleted Successfully!!";
    }

    public ActionTable update(Long id, Long issueId, String author, String actionType, String actionLevel, String roleLevel, String actionBody, Long actionNumber) throws NotFoundException {
        Optional<ActionTable> actionTableOptional=actionTableRepository.findById(id);
        if(actionTableOptional.isPresent()){
            ActionTable actionTable=actionTableOptional.get();
            if(issueId != null)
                actionTable.setIssueId(issueId);
            if(author != null)
                actionTable.setAuthor(author);
            if(actionType != null)
                actionTable.setActionType(actionType);
            if(actionLevel != null)
                actionTable.setActionLevel(actionLevel);
            if(roleLevel != null)
                actionTable.setRoleLevel(roleLevel);
            if(actionBody != null)
                actionTable.setActionBody(actionBody);
            if(actionNumber != null)
                actionTable.setActionNumber(actionNumber);
            return actionTableRepository.save(actionTable);

        }
        throw new NotFoundException("Not found Action to update!");
    }

    public List<ActionTable> getAllActions() {
        return actionTableRepository.findAll();
    }

    public ActionTable getActionById(Long id) {
        return actionTableRepository.findById(id).get();
    }
}
