package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttributeDisplayNameInput {

    private Long id;
    private Long issueTypeId;
    private String attributeDisplayName;
    private Long dataTypeInfoId;
    private String attributeKey;


}
