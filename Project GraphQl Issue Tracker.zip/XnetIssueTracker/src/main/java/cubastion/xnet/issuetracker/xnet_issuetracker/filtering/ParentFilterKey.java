package cubastion.xnet.issuetracker.xnet_issuetracker.filtering;

import lombok.Data;

import java.util.List;

@Data
public class ParentFilterKey{

    private List<FilterKey> keyParent;
    private String predicateParent;
}
