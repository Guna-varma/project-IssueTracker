package cubastion.xnet.issuetracker.xnet_issuetracker.users.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;

import java.util.List;
import java.util.Optional;

public interface Issue_User_Role_ServiceImpl {

    ISSUE_USER_ROLES_TABLE addIssueUserRoles(ISSUE_USER_ROLES_TABLE userRolesTable);

    List<ISSUE_USER_ROLES_TABLE> getAllIssueUserRoles();

    Optional<ISSUE_USER_ROLES_TABLE> getIssueUserRolesById(Long id);

}
