package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowStatusRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.services.WorkflowStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkflowStatusServiceImpl implements WorkflowStatusService {
    @Autowired
    WorkflowStatusRepository workflowStatusRepository;

    public WorkflowStatus createWorkflowStatus(WorkflowStatus workflowStatus) {
        try {
            return workflowStatusRepository.save(workflowStatus);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create Workflow status: Please add Input fields!");
        }
    }

    public List<WorkflowStatus> getAllStatus() {
        return workflowStatusRepository.findAll();
    }

    public WorkflowStatus getWorkflowStatusById(Long id) {
        return workflowStatusRepository.findById(id).get();
    }
}
