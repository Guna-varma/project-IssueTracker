package cubastion.xnet.issuetracker.xnet_issuetracker.users.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "user")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name = "userName", nullable = false)
    private String userName;

    @NotBlank
    @Column(name = "fullName",nullable = false)
    private String fullName;

    @NotBlank
    @Column(name = "password",nullable = false)
    private String password;

    @Email(regexp = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}", flags = Pattern.Flag.CASE_INSENSITIVE)
    @Size(max = 150)
    @Column(name = "email",unique = true, nullable = false)
    private String email;

    @Column(name = "active")
    private Boolean active;

    @Column(name = "createdAt", nullable = false, updatable = false)
    @CreationTimestamp
    private Date createdAt;

    @Column(name = "updatedAt", nullable = false)
    @UpdateTimestamp
    private Date updatedAt;

//    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
//    private List<Issues> issues;

    @JsonIgnore
    @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
    private List<PROJECT_USER_ROLES_TABLE> project_user_roles_table;

    @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
    private List<ISSUE_USER_ROLES_TABLE> issue_user_roles_table;
}