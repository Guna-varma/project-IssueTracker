package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.WorkflowTableInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl.WorkflowServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class WorkflowController {
    @Autowired
    WorkflowServiceImpl workflowService;

    @MutationMapping
    private WorkflowTable addWorkflow(@Argument("workflowTableInput") WorkflowTableInput input){

            WorkflowTable workflowTable=new WorkflowTable();
            workflowTable.setDescription(input.getDescription());
            workflowTable.setName(input.getName());
            return workflowService.createWorkflow(workflowTable);


    }

    @QueryMapping
    private List<WorkflowTable> getAllWorkflow(){

        return workflowService.getAllWorkflowTable();
    }

    @QueryMapping
    private Optional<WorkflowTable> getWorkflowById(@Argument Long id){
            return workflowService.getWorkflowTableById(id);


    }
}
