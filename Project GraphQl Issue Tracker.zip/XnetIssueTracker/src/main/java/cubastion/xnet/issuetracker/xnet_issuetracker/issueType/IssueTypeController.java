package cubastion.xnet.issuetracker.xnet_issuetracker.issueType;


import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.graphql.AddIssueTypeInput;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class IssueTypeController {
    @Autowired
    private IssueTypeService service;

    @MutationMapping
    private IssueType addIssueType(@Argument(name = "addIssueTypeInput") AddIssueTypeInput input){

            IssueType i = new IssueType();
            i.setIssueTypeName(input.getIssueTypeName());
            i.setDescription(input.getDescription());
            return service.addIssueType(i);

    }

    @QueryMapping
    private List<IssueType> getAllIssueType(){
        return service.getAllIssueType();
    }

    @QueryMapping
    private Optional<IssueType> getIssueTypeById(@Argument Long id){
        return service.getIssueTypeById(id);
    }

    @MutationMapping
    private String deleteIssueType(@Argument Long id){
        try {
            return service.deleteIssueType(id);
        }
        catch (Exception e){
            throw new xNetInvalidInputException("Issue Type Id is Invalid, Please fill the correct Id");
        }

    }

    @MutationMapping
    private IssueType updateIssueType(@Argument IssueType issueType){
        return service.updateIssueType(issueType);
    }
}
