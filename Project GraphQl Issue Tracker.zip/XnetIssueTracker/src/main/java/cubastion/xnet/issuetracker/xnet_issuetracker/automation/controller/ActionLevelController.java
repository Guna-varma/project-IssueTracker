package cubastion.xnet.issuetracker.xnet_issuetracker.automation.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionLevel;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.Condition;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.ActionLevelInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.ConditionInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.ActionLevelServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.ConditionServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueType;
import jakarta.validation.Valid;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class ActionLevelController {
    @Autowired
    private ActionLevelServiceImpl actionLevelService;

    @MutationMapping
    private ActionLevel addActionLevel(@Argument("actionLevel") ActionLevelInput input){
        ActionLevel actionLevel=new ActionLevel();
        actionLevel.setLevelName(input.getLevelName());
        return actionLevelService.createActionLevel(actionLevel);

    }

    @QueryMapping
    private List<ActionLevel> getAllActionLevel(){
        return actionLevelService.getAllActionLevel();
    }

    @QueryMapping
    private ActionLevel getActionLevelById(@Argument Long id){
        return actionLevelService.getActionLevelById(id);

    }
    @MutationMapping
    private String deleteActionLevel(@Valid @Argument Long id){
        return actionLevelService.deletePriorityById(id);
    }
    @MutationMapping
    private ActionLevel updateActionLevel(@Argument Long id,String levelName) throws NotFoundException {
        return actionLevelService.updateAction(id,levelName);
    }

}

