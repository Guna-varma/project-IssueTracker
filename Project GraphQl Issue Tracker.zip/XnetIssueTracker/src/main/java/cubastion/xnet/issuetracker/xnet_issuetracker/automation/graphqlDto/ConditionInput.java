package cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class ConditionInput {
    public String conditionValue;
    private String conditionName;
    private String definition;

}
