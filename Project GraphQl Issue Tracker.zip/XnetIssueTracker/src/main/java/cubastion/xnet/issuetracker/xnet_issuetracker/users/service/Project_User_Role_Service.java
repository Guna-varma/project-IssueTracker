package cubastion.xnet.issuetracker.xnet_issuetracker.users.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.Issues_User_Roles_Repo;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.Project_User_Roles_Repo;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.serviceImpl.Project_User_Role_ServiceImpL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Project_User_Role_Service implements Project_User_Role_ServiceImpL {

    @Autowired
    private Project_User_Roles_Repo repo;


    @Override
    public PROJECT_USER_ROLES_TABLE addProjectUserRoles(PROJECT_USER_ROLES_TABLE project_user_roles_table) {
        try {
            return repo.save(project_user_roles_table);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create PROJECT_USER_ROLES_TABLE: Please add Input fields!");
        }
    }

    @Override
    public List<PROJECT_USER_ROLES_TABLE> getAllProjectUserRoles() {
        List<PROJECT_USER_ROLES_TABLE> pur = null;
        try {
            pur = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (pur.isEmpty())
            throw new xNetNotFoundException("PROJECT_USER_ROLES_TABLE List is Null");
        return pur;
    }

    @Override
    public Optional<PROJECT_USER_ROLES_TABLE> getProjectUserById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("PROJECT_USER_ROLES_TABLE with ID: " + String.valueOf(id) + " is not found")
        ));
    }
}
