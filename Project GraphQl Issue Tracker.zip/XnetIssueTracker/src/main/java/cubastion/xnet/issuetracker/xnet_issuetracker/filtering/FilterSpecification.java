package cubastion.xnet.issuetracker.xnet_issuetracker.filtering;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.domain.Specification;

import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.KEYS.AND;
import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.KEYS.OR;

public class FilterSpecification<T>{

    public Specification<T> fSpecWithFilter(@NotNull FilterKey filter) {
        Specification<T> spec = null;

        for (FilterFields filterField: filter.getKey()) {
            if (spec == null) {
                spec = getSpecification(filterField, filterField.getKeyValue());
            } else if (filter.getPredicate().equalsIgnoreCase(OR)) {
                spec = spec.or(getSpecification(filterField, filterField.getKeyValue()));
            } else if (filter.getPredicate().equalsIgnoreCase(AND)) {
                spec = spec.and(getSpecification(filterField, filterField.getKeyValue()));
            } else {
                throw new xNetNotFoundException("Predicate not found, Please Enter 'AND' (or) 'OR' Predicate..!");
            }
        }
        return spec;
    }

    private Specification<T> getSpecification(FilterFields filterField, String key) {
        return (root, query, builder) -> filterField.generateCriteria(builder, root.get(key));
    }

}
