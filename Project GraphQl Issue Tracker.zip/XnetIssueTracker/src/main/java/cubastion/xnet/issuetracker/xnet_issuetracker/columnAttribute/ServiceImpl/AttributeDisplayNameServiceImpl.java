package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.ServiceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeDisplayName;

import java.util.List;
import java.util.Optional;

public interface AttributeDisplayNameServiceImpl {

    AttributeDisplayName addAttributeDisplayName( AttributeDisplayName attributeDisplayName);

    List<AttributeDisplayName> getAll();

    Optional<AttributeDisplayName> getById(Long id);

}
