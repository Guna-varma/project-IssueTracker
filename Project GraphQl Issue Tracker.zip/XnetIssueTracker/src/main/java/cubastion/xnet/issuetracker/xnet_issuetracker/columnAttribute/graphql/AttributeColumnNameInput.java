package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttributeColumnNameInput {
    private Long id;
    private String attributeColumnName;
    private Long dataTypeInfoId;
    private Boolean subscriptionTypeId;
}
