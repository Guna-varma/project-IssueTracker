package cubastion.xnet.issuetracker.xnet_issuetracker.project.graphql;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProjectFilter {
    private String projectName;
    private String url;
    private String projectLead;
    private String projectDescription;
    private String projectKey;
    private Long assigneeType;
}
