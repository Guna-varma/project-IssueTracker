package cubastion.xnet.issuetracker.xnet_issuetracker.automation.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.IssueTrigger;

public interface IssueTriggerService {

}
