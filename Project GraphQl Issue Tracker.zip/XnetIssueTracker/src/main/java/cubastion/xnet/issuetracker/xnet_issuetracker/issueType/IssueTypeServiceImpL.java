package cubastion.xnet.issuetracker.xnet_issuetracker.issueType;

import java.util.List;
import java.util.Optional;

public interface IssueTypeServiceImpL {
    IssueType addIssueType(IssueType issueType);

    List<IssueType> getAllIssueType();

    Optional<IssueType> getIssueTypeById(Long id);

    IssueType updateIssueType(IssueType issueType);

    String deleteIssueType(Long id);
}
