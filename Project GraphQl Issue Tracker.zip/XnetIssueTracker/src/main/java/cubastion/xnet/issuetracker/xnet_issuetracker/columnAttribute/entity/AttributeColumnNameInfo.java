package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.w3c.dom.Attr;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "attributeColumnNameInfo")
public class AttributeColumnNameInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "attributeColumnName")
    private String attributeColumnName;

    @Column(name = "dataTypeInfoId")
    private Long dataTypeInfoId;

    @Column(name = "subscriptionTypeId")
    private Boolean subscriptionTypeId;

    @Column(name = "attributeKey")
    private String attributeKey;

//    @JsonIgnore
//    @OneToMany(mappedBy = "attributeKey", cascade = CascadeType.ALL)
//    private List<AttributeDisplayName> attributeDisplayName;

    public AttributeColumnNameInfo(String attributeColumnName, Long dataTypeInfoId, Boolean subscriptionTypeId,String attributeKey) {
        this.attributeColumnName = attributeColumnName;
        this.dataTypeInfoId = dataTypeInfoId;
        this.subscriptionTypeId = subscriptionTypeId;
        this.attributeKey=attributeKey;
    }

}