package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowTableRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.services.WorkflowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WorkflowServiceImpl implements WorkflowService {
    @Autowired
    WorkflowTableRepository workflowTableRepository;

//    @Autowired
//    WorkflowStatusRepository workflowStatusRepository;
//
//    @Autowired
//    WorkflowStepTableRepository workflowStepTableRepository;

    public WorkflowTable createWorkflow(WorkflowTable workflowTable) {
        try {
            return workflowTableRepository.save(workflowTable);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create Work flow: Please add Input fields!");
        }
    }

    public List<WorkflowTable> getAllWorkflowTable() {
        List<WorkflowTable> workflowTables = null;
        try {
            workflowTables = workflowTableRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (workflowTables.isEmpty())
            throw new xNetNotFoundException("Work flow List is Null");
        return workflowTables;

    }

    public Optional<WorkflowTable> getWorkflowTableById(Long id) {
        return Optional.ofNullable(workflowTableRepository.findById(id).orElseThrow(
                () -> new xNetNotFoundException("WorkFlow with ID: " + String.valueOf(id) + " is not found")
        ));
    }


//    public WorkflowStatus getStatusNameByWorkFlowId(Long id){
//        ArrayList<Long> statusIds=workflowStepTableRepository.getStatusIdByWorkflowTableId(id);
//        workflowStatusRepository.findAll(statusIds);
//        return null;
//    }
}
