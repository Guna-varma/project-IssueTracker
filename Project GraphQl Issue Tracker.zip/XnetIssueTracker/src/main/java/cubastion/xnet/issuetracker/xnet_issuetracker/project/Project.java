package cubastion.xnet.issuetracker.xnet_issuetracker.project;

import com.fasterxml.jackson.annotation.JsonIgnore;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.priority.Priority;
import cubastion.xnet.issuetracker.xnet_issuetracker.resolution.Resolution;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Where;

import java.util.List;

@Getter
@Setter
@Entity(name = "project")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

//    @NotBlank
    @Column(name = "projectName", nullable = false)
    private String projectName;

    @Column(name = "projectUrl")
    private String url;

    @Column(name = "projectLead")
    private String projectLead;

    @Column(name = "projectDescription")
    private String projectDescription;

    @NotBlank
    @Column(name = "projectKey", nullable = false)
    private String projectKey;

    @Column(name = "assigneeType")
    private Long assigneeType;

    @JsonIgnore
    @OneToMany(mappedBy = "project",cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Issues> issues;

    @JsonIgnore
    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private List<Priority> priority;

    @JsonIgnore
    @OneToMany(mappedBy = "proj",cascade = CascadeType.ALL)
    private List<Resolution> resolution;

    @JsonIgnore
    @OneToMany(mappedBy = "project", cascade = CascadeType.ALL)
    private List<PROJECT_USER_ROLES_TABLE> project_user_roles_table;

}