package cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable.graphql;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class RolesTableInput {
//    Long id;
    String name;
}
