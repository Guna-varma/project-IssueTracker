package cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class IssueTriggerInput {

    private String name;
    private String description;


}
