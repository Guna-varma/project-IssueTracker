package cubastion.xnet.issuetracker.xnet_issuetracker.users.repo;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.NativeQuery;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


public interface UserRepository extends CrudRepository<User, Long>,JpaSpecificationExecutor<User>, PagingAndSortingRepository<User,Long> {

    @Modifying
    @Transactional
    @Query(value = NativeQuery.QueryForUsers, nativeQuery = true)
    List<User> findAllUsersByRoleIdAndIssueId(@Param("roleIds") String[] roleIds, @Param("issueId") Long issueId);

    @Modifying
    @Transactional
    @Query(value = NativeQuery.QueryForUserRoles, nativeQuery = true)
    List<User> findAllUsersByRoleId(@Param("roleIds") String[] roleIds);
}
