package cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.handler;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.AbstractGraphQLException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import graphql.ErrorClassification;
import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.language.SourceLocation;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.graphql.execution.DataFetcherExceptionResolverAdapter;
import org.springframework.graphql.execution.ErrorType;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class CustomExceptionResolver extends DataFetcherExceptionResolverAdapter {

    public enum DefaultErrorClassification implements ErrorClassification {
        ServerError

    }
    @Override
    protected GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        if (ex instanceof xNetNotFoundException) {
            return GraphqlErrorBuilder.newError()
                    .errorType(ErrorType.NOT_FOUND)
                    .message(ex.getMessage())
                    .path(env.getExecutionStepInfo().getPath())
                    .location(env.getField().getSourceLocation())
//                    .extensions(Map.of("source", toSourceLocation(ex)))
                    .build();
        } else if (ex instanceof xNetInvalidInputException) {
            return GraphqlErrorBuilder.newError()
                    .errorType(ErrorType.BAD_REQUEST)
                    .message(ex.getMessage())
                    .path(env.getExecutionStepInfo().getPath())
//                    .extensions(Map.of("source", toSourceLocation(ex)))
                    .location(env.getField().getSourceLocation())
                    .build();
        } else if (ex instanceof AbstractGraphQLException) {
            return GraphqlErrorBuilder.newError()
                    .errorType(DefaultErrorClassification.ServerError)
                    .message(ex.getMessage())
                    .path(env.getExecutionStepInfo().getPath())
                    .location(env.getField().getSourceLocation())
//                    .extensions(((AbstractGraphQLException) ex).getExtensions())
                    .build();
        } else {
            return GraphqlErrorBuilder.newError().message("Internal Server Error(s) while executing query").errorType(DefaultErrorClassification.ServerError).extensions(Map.of("source", toSourceLocation(ex))).build();
        }
    }

    private SourceLocation toSourceLocation(Throwable t) {
        if (t.getStackTrace().length == 0) {
            return null;
        }
        StackTraceElement st = t.getStackTrace()[0];
        return new SourceLocation(st.getLineNumber(), -1, st.toString());
    }

}
