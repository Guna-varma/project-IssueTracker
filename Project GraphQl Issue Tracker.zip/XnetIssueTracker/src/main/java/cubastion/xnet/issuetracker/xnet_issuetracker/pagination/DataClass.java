package cubastion.xnet.issuetracker.xnet_issuetracker.pagination;

import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import lombok.*;

import java.util.List;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DataClass {
    private List<User> userData;
    private List<Issues> issuesData;
}
