package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.TransitionTableInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl.TransitionTableServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.TransitionTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class TransitionController {
    @Autowired
    TransitionTableServiceImpl transitionTableService;

    @MutationMapping
    private TransitionTable addTransitionTable(@Argument("transitionTableInput") TransitionTableInput input){
            TransitionTable transitionTable=new TransitionTable();
            if(input.getToStepId()>0 && input.getFromStepId()>0){
                transitionTable.setDescription(input.getDescription());
                transitionTable.setTransitionName(input.getTransitionName());
                transitionTable.setFromStepId(input.getFromStepId());
                transitionTable.setToStepId(input.getToStepId());
                return transitionTableService.createTransitionTable(transitionTable);
            }else {
                throw new xNetInvalidInputException("Please enter valid ToStepId or FromStepId");
            }




    }

    @QueryMapping
    private List<TransitionTable> getAllTransitionTable() {
        return transitionTableService.getAllTransitionTable();
    }

    @QueryMapping
    private Optional<TransitionTable> getTransitionTableById(@Argument Long id){
        try {
            return transitionTableService.getTransitionTableById(id);
        }
        catch (Exception e){
            throw new xNetInvalidInputException("TransitionTable Id is Invalid, Please fill the correct Id");
        }
    }
}
