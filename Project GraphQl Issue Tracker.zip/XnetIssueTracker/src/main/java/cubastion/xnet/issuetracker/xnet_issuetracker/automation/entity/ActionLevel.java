package cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "actionLevel")
public class ActionLevel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "levelName")
    private String levelName;

    public ActionLevel(String levelName) {
        this.levelName = levelName;
    }
}

