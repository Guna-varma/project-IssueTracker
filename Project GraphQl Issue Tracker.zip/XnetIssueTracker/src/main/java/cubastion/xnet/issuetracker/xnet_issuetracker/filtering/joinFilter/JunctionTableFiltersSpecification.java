package cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class JunctionTableFiltersSpecification<T> {

    @PersistenceContext
    private EntityManager entityManager;

    public Specification<T> getMultiSearchSpecification(List<SearchRequestDto> searchRequestDtos, RequestDto.GlobalOperator globalOperator) {
        return (root, query, criteriaBuilder) -> {

            List<Predicate> predicates = new ArrayList<>();

            for (SearchRequestDto requestDto : searchRequestDtos) {

                Join<Object, Object> joinTable1 = root.join(requestDto.getJoinTable1());
                Join<Object, Object> joinTable2 = joinTable1.join(requestDto.getJoinTable2());
                Join<Object, Object> joinTable3 = joinTable1.join(requestDto.getJoinTable3());

                switch (requestDto.getOperation()) {

                    case "contains":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.like(joinTable2.get(requestDto.getColumn2()), "%" + requestDto.getValue2() + "%"),
                                        criteriaBuilder.like(joinTable3.get(requestDto.getColumn3()), "%" + requestDto.getValue3() + "%")
                                ));
                        break;

                    case "equal":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.equal(joinTable2.get(requestDto.getColumn2()), requestDto.getValue2()),
                                        criteriaBuilder.equal(joinTable3.get(requestDto.getColumn3()), requestDto.getValue3())
                                ));
                        break;

                    case "eq":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.equal(joinTable2.get(requestDto.getColumn2()), Integer.parseInt(requestDto.getValue2())),
                                        criteriaBuilder.equal(joinTable3.get(requestDto.getColumn3()), Integer.parseInt(requestDto.getValue3()))
                                ));
                        break;

                    case "gt":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.gt(joinTable2.get(requestDto.getColumn2()), Integer.parseInt(requestDto.getValue2())),
                                        criteriaBuilder.gt(joinTable3.get(requestDto.getColumn3()), Integer.parseInt(requestDto.getValue3()))
                                ));
                        break;

                    case "lt":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.lt(joinTable2.get(requestDto.getColumn2()), Integer.parseInt(requestDto.getValue2())),
                                        criteriaBuilder.lt(joinTable3.get(requestDto.getColumn3()), Integer.parseInt(requestDto.getValue3()))
                                ));
                        break;

                    case "ge":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.ge(joinTable2.get(requestDto.getColumn2()), Integer.parseInt(requestDto.getValue2())),
                                        criteriaBuilder.ge(joinTable3.get(requestDto.getColumn3()), Integer.parseInt(requestDto.getValue3()))
                                ));
                        break;

                    case "le":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.le(joinTable2.get(requestDto.getColumn2()), Integer.parseInt(requestDto.getValue2())),
                                        criteriaBuilder.le(joinTable3.get(requestDto.getColumn3()), Integer.parseInt(requestDto.getValue3()))
                                ));
                        break;

                    case "startsWith":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.like(joinTable2.get(requestDto.getColumn2()), requestDto.getValue2() + "%"),
                                        criteriaBuilder.like(joinTable3.get(requestDto.getColumn3()), requestDto.getValue3() + "%")
                                ));
                        break;

                    case "endsWith":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.like(joinTable2.get(requestDto.getColumn2()), "%" + requestDto.getValue2()),
                                        criteriaBuilder.like(joinTable3.get(requestDto.getColumn3()), "%" + requestDto.getValue3())
                                ));
                        break;

                    case "IN":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.or(joinTable2.get(requestDto.getColumn2()).in(requestDto.getValuesIN())),
                                        criteriaBuilder.like(joinTable3.get(requestDto.getColumn3()), "%" + requestDto.getValue3() + "%")
                                ));
                        break;

                    case "INs":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.or(joinTable2.get(requestDto.getColumn2()).in(requestDto.getValuesIN1())),
                                        criteriaBuilder.or(joinTable3.get(requestDto.getColumn3()).in(requestDto.getValuesIN2()))
                                ));
                        break;

                    case "NOT":
                        predicates.add(
                                criteriaBuilder.and(
                                        criteriaBuilder.notLike(joinTable2.get(requestDto.getColumn2()), "%" + requestDto.getValue2() + "%"),
                                        criteriaBuilder.notLike(joinTable3.get(requestDto.getColumn3()), "%" + requestDto.getValue3() + "%")
                                )
                        );
                        break;

                    default:
                        throw new xNetInvalidInputException("Unexpected value: " + requestDto.getOperation() + ", please add valid Operation Name");
                }
            }

            if (globalOperator.equals(RequestDto.GlobalOperator.AND)) {
                return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
            } else {
                return criteriaBuilder.or(predicates.toArray(new Predicate[0]));
            }

        };
    }
}