package cubastion.xnet.issuetracker.xnet_issuetracker.issues;


import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;

import java.util.List;
import java.util.Optional;

public interface IssuesServiceImpL {

    Issues add(Issues issues);

    List<Issues> getAll();

    Optional<Issues> getIssuesById(Long id);

    String deleteIssues(Long id);

    List<Issues> issuesWithFilter(FilterKey filter);

}
