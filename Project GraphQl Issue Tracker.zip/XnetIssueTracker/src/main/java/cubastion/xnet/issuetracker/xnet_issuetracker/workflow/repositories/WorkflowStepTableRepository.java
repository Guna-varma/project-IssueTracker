package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories;

import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStepTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.WorkflowStatusDTO;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.utitlity.QUERIES;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface WorkflowStepTableRepository extends JpaRepository<WorkflowStepTable, Long> {

    @Query(value = QUERIES.Status_Name_By_WorkflowId,
            nativeQuery = true)
    List<WorkflowStatusDTO> findWorkflowStatusNameByWorkflowId(Long workflowTableId);

}