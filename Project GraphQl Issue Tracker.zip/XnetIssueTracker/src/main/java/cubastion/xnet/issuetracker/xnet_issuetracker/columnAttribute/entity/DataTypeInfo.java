package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity;

import jakarta.persistence.*;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

import javax.persistence.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "dataTypeInfo")
public class DataTypeInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "dataTypeName", unique=true)
    private String dataTypeName;

    public DataTypeInfo(String dataTypeName) {
        this.dataTypeName = dataTypeName;
    }

    public Long getId() {
        return id;
    }

    public String getDataTypeName() {
        return dataTypeName;
    }

}