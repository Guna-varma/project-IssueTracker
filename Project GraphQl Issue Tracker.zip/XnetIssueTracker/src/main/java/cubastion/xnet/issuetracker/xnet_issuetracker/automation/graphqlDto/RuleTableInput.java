package cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class RuleTableInput {
    private String name;
    private Long ownerId;
    private Long issueTriggerId;
    private Long conditionTableId;
    private Long postFunctionId;
    private String description;
    private String actionLevel;
    private String category;
    private String configurationData;
}
