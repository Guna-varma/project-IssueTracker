package cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "ruleTable")
public class RuleTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "ownerId")
    private Long ownerId;

    @Column(name = "issueTriggerId")
    private Long issueTriggerId;

    @Column(name = "conditionTableId")
    private Long conditionTableId;

    @Column(name = "postFunctionId")
    private Long postFunctionId;

    @Column(name="actionLevel")
    private String actionLevel;

    @Column(name = "description")
    private String description;

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name="configurationData",columnDefinition = "JSON")
    private String configurationData;

    @CreationTimestamp
    @Column(name = "createdAt", nullable = false, updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updatedAt", nullable = false)
    private Date updateAt;

    @ManyToOne
    @JoinColumn(name = "conditionTableId", insertable = false, updatable = false)
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private Condition condition;

    @ManyToOne
    @JoinColumn(name = "issueTriggerId", insertable = false, updatable = false)
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private IssueTrigger issueTrigger;

    @ManyToOne
    @JoinColumn(name = "postFunctionId", insertable = false, updatable = false)
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private PostFunction postFunctions;

}