package cubastion.xnet.issuetracker.xnet_issuetracker.issueType;


import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import jakarta.persistence.*;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "issueType")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IssueType {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name = "issueTypeName", nullable = false)
    private String issueTypeName;

    @NotBlank
    @Column(name = "description", nullable = false)
    private String description;

    @OneToMany(mappedBy = "issueType",
            orphanRemoval = true,
            cascade = CascadeType.ALL)
    private List<Issues> issues;

    public IssueType(String issueTypeName, String description) {
        this.issueTypeName = issueTypeName;
        this.description = description;
    }
}

