package cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.IssueTrigger;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IssueTriggerRepository extends JpaRepository<IssueTrigger, Long>, JpaSpecificationExecutor<IssueTrigger>, PagingAndSortingRepository<IssueTrigger,Long> {
}
