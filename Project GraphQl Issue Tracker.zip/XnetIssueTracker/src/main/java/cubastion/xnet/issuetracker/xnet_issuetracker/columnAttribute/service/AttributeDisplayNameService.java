package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.ServiceImpl.AttributeDisplayNameServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeDisplayName;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeColumnNameInfoRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeDisplayNameRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AttributeDisplayNameService implements AttributeDisplayNameServiceImpl {

    @Autowired
    AttributeDisplayNameRepository attributeDisplayNameRepository;

    @Autowired
    AttributeColumnNameInfoRepository columnNameInfoRepository;

//    @Override
    public AttributeDisplayName addAttributeDisplayName(AttributeDisplayName attributeDisplayName) {
        return attributeDisplayNameRepository.save(attributeDisplayName);
    }


    public AttributeDisplayName getAttributeDisplayNameByDisplayName(String displayName) {
        return attributeDisplayNameRepository.findByAttributeDisplayName(displayName);
    }


    @Override
    public List<AttributeDisplayName> getAll() {
        List<AttributeDisplayName> displayNameList = null;
        try {
            displayNameList = attributeDisplayNameRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (displayNameList.isEmpty())
            throw new xNetNotFoundException("AttributeDisplayName List is Null");
        return displayNameList;

    }

    @Override
    public Optional<AttributeDisplayName> getById(Long id) {
        return Optional.ofNullable(attributeDisplayNameRepository.findById(id).orElseThrow(
                () -> new xNetNotFoundException("AttributeDisplayName with ID: " + String.valueOf(id) + " is not found")
        ));
    }
}
