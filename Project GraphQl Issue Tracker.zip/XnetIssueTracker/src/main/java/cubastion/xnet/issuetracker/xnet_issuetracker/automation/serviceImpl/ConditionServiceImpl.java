package cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.Condition;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.RuleTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.ConditionRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.service.ConditionService;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterFields;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import kotlin.reflect.jvm.internal.impl.descriptors.Visibilities;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ConditionServiceImpl implements ConditionService {
    @Autowired
    ConditionRepository conditionRepository;
    public Condition createCondition(Condition condition) {
        return conditionRepository.save(condition);
    }

    public List<Condition> getAllConditionTable() {
        return conditionRepository.findAll();
    }

    public Condition getConditionById(Long id) {
        //conditionRepository.findAllById()
        return conditionRepository.findById(id).orElseThrow();
    }
//    public Condition getConditionIdByName(String name){
//        List<RuleTable> ruleTables=new ArrayList<>();
//
//        return null;
//    }
    public List<Condition> getConditionByIds(ArrayList<Long> idks ){

        List<Condition> conditions=conditionRepository.findAllById(idks);

        for(Condition condition:conditions){

           String name  = condition.getConditionName();
           String value = condition.getConditionValue();

        }





        return conditionRepository.findAllById(idks);
    }
    public String deleteConditionById(Long id) {
        conditionRepository.deleteById(id);
        return "Priority Id: "+id+" Deleted Successfully!!";
    }




//    public List<Long> getIdsByTwoColumns(List<String> conditionNames, List<String> definitions){
//        return conditionRepository.getIdsByTwoColumns(conditionNames, definitions);
//    }

//    public List<Long> getIdsByConditionAndDefinition(List<String> conditionNames, List<String> definitions){
//        List<Long> result = new ArrayList<>();
//        for (String conditionName : conditionNames) {
//            for (String definition : definitions) {
//                List<Long> ids = conditionRepository.getIdsByConditionAndDefinition(conditionNames, definitions);
//                result.addAll(ids);
//            }
//        }
//        return result;
//    }

   public List<Condition> getConditionList(String conditionName, String conditionValue){
       Specification<Condition> spec = getConditionListByDetails(conditionName,conditionValue);
       return conditionRepository.findAll(spec);
   }

    public Specification<Condition> getConditionListByDetails(String conditionName, String conditionValue){
        return (root, query, criteriaBuilder) -> {
            Expression<Boolean> c1 = criteriaBuilder.like(root.get("conditionName"),conditionName);
            Expression<Boolean> c2 = criteriaBuilder.like(root.get("conditionValue"),conditionValue);
            return criteriaBuilder.and(c1,c2);

        };
    }

    }

