package cubastion.xnet.issuetracker.xnet_issuetracker.issues;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IssuesRepository extends JpaRepository<Issues, Long>,JpaSpecificationExecutor<Issues>, PagingAndSortingRepository<Issues,Long> {

}
