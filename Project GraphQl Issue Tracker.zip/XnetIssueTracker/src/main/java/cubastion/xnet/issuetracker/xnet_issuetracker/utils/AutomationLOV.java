package cubastion.xnet.issuetracker.xnet_issuetracker.utils;

public class AutomationLOV {

    //for issueCategory
    public static final String ISSUECREATED = "issuecreated";

    public static final String ISSUEUPDATE = "issueupdate";

    public static final String ISSUEDELETE = "issuedelete";


// for postfunction key
    public static final String SENDEMAIL = "sendEmail";
    public static final String ASSIGNISSUE = "assignIssue";
    public static final String TRANSITIONISSUE = "transitionIssue";
    public static final String EDITISSUE = "editIssue";

    public static final String SENDEMAILTOROLES = "sendEmailToRoles";

    //FOR Configuration json keys
    public static final String CONTENT = "content";
    public static final String SUBJECT = "subject";
    public static final String TO = "to";
    public static final String ASSIGNEE = "assignee";

}
