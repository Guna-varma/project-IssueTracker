package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql.AttributeDisplayNameInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeDisplayName;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service.AttributeDisplayNameService;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class AttributeDisplayNameController {

    @Autowired
    private AttributeDisplayNameService attributeDisplayNameService;

    @MutationMapping
    private AttributeDisplayName addAttributeDisplayName(@Argument(name = "addAttributeDisplayName") AttributeDisplayNameInput attributeDisplayNameInput){
        AttributeDisplayName aDN=new AttributeDisplayName();
        if(!attributeDisplayNameInput.getAttributeDisplayName().isBlank()){
            aDN.setAttributeDisplayName(attributeDisplayNameInput.getAttributeDisplayName());
        }
        else {
            throw new xNetInvalidInputException("Please add valid AttributeDisplayName..!");
        }

        if(attributeDisplayNameInput.getDataTypeInfoId()>0){
            aDN.setDataTypeInfoId(attributeDisplayNameInput.getDataTypeInfoId());
        }else {
            throw new xNetInvalidInputException("Please add valid DataTypeInfoId..!");
        }
        if(attributeDisplayNameInput.getIssueTypeId()>0){
            aDN.setIssueTypeId(attributeDisplayNameInput.getIssueTypeId());
        }else {
            throw new xNetInvalidInputException("Please add valid IssueTypeId..!");
        }
        if(attributeDisplayNameInput.getAttributeKey().isBlank()){
            throw new xNetInvalidInputException("Please add valid AttributeKey..!");

        }else {
            aDN.setAttributeKey(attributeDisplayNameInput.getAttributeKey());
        }

        return attributeDisplayNameService.addAttributeDisplayName(aDN);
    }

    @QueryMapping
    private List<AttributeDisplayName> getAllAttributeDisplayName(){

        return attributeDisplayNameService.getAll();
    }

    @QueryMapping
    private Optional<AttributeDisplayName> getAttributeDisplayNameById(@Argument Long id){
        return attributeDisplayNameService.getById(id);
    }

}
