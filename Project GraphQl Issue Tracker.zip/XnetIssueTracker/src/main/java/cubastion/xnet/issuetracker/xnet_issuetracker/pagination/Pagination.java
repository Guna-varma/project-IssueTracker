package cubastion.xnet.issuetracker.xnet_issuetracker.pagination;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Pagination {
    private int totalRecords;
    private int totalPerPage;
    private int totalPage;
    private int currentPage;
    private int nextPage;
    private int previousPage;
}
