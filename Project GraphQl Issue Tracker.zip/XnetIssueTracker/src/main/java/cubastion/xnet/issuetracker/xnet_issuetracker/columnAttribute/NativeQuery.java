package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute;

public class NativeQuery {
    public static final String AttributeColumnNameInfoTable = "attributecolumnnameinfo";
    public static final String AttributeDisplayNameTable = "attributedisplayname";
    public static final String FindFindAvailableColumnQuery =
              "SELECT T1.attributeKey " +
              " FROM (SELECT * FROM " +AttributeColumnNameInfoTable+" WHERE dataTypeInfoId =:dataTypeId) as T1 " +
            " LEFT JOIN (SELECT attributeKey FROM "+AttributeDisplayNameTable+" " +
            " WHERE issueTypeId =:issueTypeId AND dataTypeInfoId =:dataTypeId) as T2 " +
            " ON T1.attributeKey = T2.attributeKey " +
            " WHERE T2.attributeKey IS NULL " +
            " ORDER BY T1.id ASC LIMIT 1;";

    public static final String QueryForUsers =
            "SELECT u.* FROM user as u" +
            " JOIN issue_user_roles_table as iurt ON u.id = iurt.user_id" +
            " WHERE iurt.issue_id = :issueId AND iurt.role_id  IN (:roleIds)";

    public static final String QueryForUserRoles =
            "SELECT u.* FROM user as u" +
                    " JOIN issue_user_roles_table as iurt ON u.id = iurt.user_id" +
                    " WHERE iurt.role_id  IN (:roleIds)";

   /* "SELECT T1.attributeColumnName " +
            " FROM (SELECT * FROM " +AttributeColumnNameInfoTable+" WHERE dataTypeInfoId =:dataTypeId) as T1 " +
            " LEFT JOIN (SELECT attributeColumnName FROM "+AttributeDisplayNameTable+" " +
            " WHERE issueTypeId =:issueTypeId AND dataTypeInfoId =:dataTypeId) as T2 " +
            " ON T1.attributeColumnName = T2.attributeColumnName " +
            " WHERE T2.attributeColumnName IS NULL " +
            " ORDER BY T1.id ASC LIMIT 1;";*/

}