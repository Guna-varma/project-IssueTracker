package cubastion.xnet.issuetracker.xnet_issuetracker.resolution;

import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity(name = "resolution")
public class Resolution {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "projectId")
    private Long projectId;

    @NotBlank
    @Column(name = "resolutionName", nullable = false)
    private String resolutionName;

    @Column(name = "description")
    private String description;

    @Column(name = "iconUrl")
    private String iconUrl;

    @ManyToOne
    @JoinColumn(name = "projectId",insertable = false, updatable = false)
    private Project proj;

}