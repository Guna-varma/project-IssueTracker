package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WorkflowStepTableInput {
    private Long linkedStatusId;
    private String stepName;
    private Long workflowTableId;
}
