package cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses;

import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.Pagination;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserPaginationResponse<T>{
    private T data;
    private Pagination pagination;
}
