package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO;

public interface WorkflowStatusDTO {

    Long getId();

    String getName();

    String getDescription();

}
