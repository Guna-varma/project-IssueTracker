package cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SearchRequestDto {
    String operation;

    String value;
    String value1;
    String value2;
    String value3;

    String toValue;
    List<String> valuesIN;
    List<String> valuesIN1;
    List<String> valuesIN2;

    String joinTable;
    String joinTable1;
    String joinTable2;
    String joinTable3;

    String column;
    String column1;
    String column2;
    String column3;
}
