package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories;

import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowTable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkflowTableRepository extends JpaRepository<WorkflowTable, Long> {
}