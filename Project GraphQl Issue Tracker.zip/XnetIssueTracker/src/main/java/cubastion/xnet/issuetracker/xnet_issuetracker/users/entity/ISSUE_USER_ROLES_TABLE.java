package cubastion.xnet.issuetracker.xnet_issuetracker.users.entity;

import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable.RolesTable;
import jakarta.persistence.*;
import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name ="issue_user_roles_table")
public class ISSUE_USER_ROLES_TABLE {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "issue_id",nullable = false)
    private Long issue_id;

    @Column(name = "user_id",nullable = false)
    private Long user_id;

    @Column(name = "role_id", nullable = false)
    private Long role_id;

    @ManyToOne
    @JoinColumn(name = "user_id",updatable = false,insertable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "issue_id",insertable = false, updatable = false)
    private Issues issues;

    @ManyToOne
    @JoinColumn(name = "role_id",insertable = false, updatable = false)
    private RolesTable rolesTable;


//    @ManyToMany
//    @JoinTable(
//            name = "m2m_join_table",
//            joinColumns = @JoinColumn(name = "user_issueId"),
//            inverseJoinColumns = @JoinColumn(name = "issueId"))
//    private List<Issues> issuesList;




}
