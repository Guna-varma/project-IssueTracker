package cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class MultiFiltersSpecification<T> {

    @PersistenceContext
    private EntityManager entityManager;

    public Specification<T> getMultiSearchSpecification(List<SearchRequestDto> searchRequestDtos, RequestDto.GlobalOperator globalOperator) {
        return (root, query, criteriaBuilder) -> {

            List<Predicate> predicates = new ArrayList<>();

            for (SearchRequestDto requestDto : searchRequestDtos) {

                Join<Object, Object> joinTable1 = root.join(requestDto.getJoinTable1());
                Join<Object, Object> joinTable2 = joinTable1.join(requestDto.getJoinTable2());

                switch (requestDto.getOperation()) {

                    case "equal":
                        predicates.add(criteriaBuilder.equal(joinTable2.get(requestDto.getColumn()), requestDto.getValue()));
                        break;

                    case "contains":
                        predicates.add(criteriaBuilder.like(joinTable2.get(requestDto.getColumn()), "%"+requestDto.getValue()+"%"));
                        break;

                    case "startsWith":
                        predicates.add(criteriaBuilder.like(joinTable2.get(requestDto.getColumn()), requestDto.getValue()+"%"));
                        break;

                    case "endsWith":
                        predicates.add(criteriaBuilder.like(joinTable2.get(requestDto.getColumn()), "%"+requestDto.getValue()));
                        break;

                    case "eq":
                        predicates.add(criteriaBuilder.equal(joinTable2.get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue())));
                        break;

                    case "gt":
                        predicates.add(criteriaBuilder.gt(joinTable2.get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue())));
                        break;

                    case "lt":
                        predicates.add(criteriaBuilder.lt(joinTable2.get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue())));
                        break;

                    case "ge":
                        predicates.add(criteriaBuilder.ge(joinTable2.get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue())));
                        break;

                    case "le":
                        predicates.add(criteriaBuilder.le(joinTable2.get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue())));
                        break;

                    case "NOT":
                        predicates.add(criteriaBuilder.notLike(joinTable2.get(requestDto.getColumn()), "%"+requestDto.getValue()+"%"));
                        break;

                    case "IN":
                        predicates.add(criteriaBuilder.or(joinTable2.get(requestDto.getColumn()).in(requestDto.getValuesIN())));
                        break;

                    case "INT_BETWEEN":
                        predicates.add(criteriaBuilder.between(joinTable2.get(requestDto.getColumn()),
                                                                Integer.parseInt(requestDto.getValue()),
                                                                Integer.parseInt(requestDto.getToValue())));
                        break;

                    case "DATE_BETWEEN":
                        predicates.add(criteriaBuilder.between(joinTable2.get(requestDto.getColumn()),
                                Date.valueOf(requestDto.getValue()),
                                Date.valueOf(requestDto.getToValue())));
                        break;

                    case "RANGE":
                        predicates.add(criteriaBuilder.and(criteriaBuilder.greaterThanOrEqualTo(joinTable2.get(requestDto.getColumn()),
                                        Integer.parseInt(requestDto.getValue())),
                                        criteriaBuilder.lessThanOrEqualTo(joinTable2.get(requestDto.getColumn()),
                                        Integer.parseInt(requestDto.getToValue()))));
                        break;

                    default:
                        throw new xNetInvalidInputException("Unexpected value: " + requestDto.getOperation() + ", please add valid Operation Name");
                }
            }

            if (globalOperator.equals(RequestDto.GlobalOperator.AND)) {
                return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
            } else {
                return criteriaBuilder.or(predicates.toArray(new Predicate[0]));
            }

        };
    }
}