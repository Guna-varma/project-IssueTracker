package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.DataTypeInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DataTypeRepository extends JpaRepository<DataTypeInfo,Long> {

    DataTypeInfo findByDataTypeName(String integer);

    boolean existsByDataTypeName(String name);

}
