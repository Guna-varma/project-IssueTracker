package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.ServiceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;

import java.util.List;
import java.util.Optional;

public interface AttributeColumnServiceImpl {

    AttributeColumnNameInfo addAttributeColumnNameInfo(AttributeColumnNameInfo attributeColumnNameInfo);

    List<AttributeColumnNameInfo> getAllAttributeColumnName();

    Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoByDataTypeInfoId(Long id);

    Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoById(Long id);

    Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoByKeyId(String attributeKey);



}
