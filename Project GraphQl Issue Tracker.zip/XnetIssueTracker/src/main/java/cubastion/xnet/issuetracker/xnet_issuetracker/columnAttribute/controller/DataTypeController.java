package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql.DataTypeDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.DataTypeInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service.DataTypeInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class DataTypeController {

    @Autowired
    DataTypeInfoService dataTypeInfoService;

    @MutationMapping
    private DataTypeInfo addDataTypeInfo(@Argument(name = "addDatatype")DataTypeDto dataTypeDto){
        DataTypeInfo dataTypeInfo=new DataTypeInfo();
        dataTypeInfo.setId(dataTypeDto.getId());
        dataTypeInfo.setDataTypeName(dataTypeDto.getDataTypeName());
        return dataTypeInfoService.addDataTypeInfo(dataTypeInfo);
    }

    @QueryMapping
    private List<DataTypeInfo> getAllDataTypeInfo(){
        return dataTypeInfoService.getAllDataTypeInfo();
    }

    @QueryMapping
    private Optional<DataTypeInfo> getDataTypeInfoById(@Argument Long id){
        return dataTypeInfoService.getById(id);
    }
}
