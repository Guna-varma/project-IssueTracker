package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "workflowStatus")
public class WorkflowStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name = "name",nullable = false)
    private String name;

    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy = "workflowStatus", cascade = CascadeType.ALL)
    private List<WorkflowStepTable> workflowStepTableList;

    public WorkflowStatus(String name, String description) {
        this.name = name;
        this.description = description;
    }
}