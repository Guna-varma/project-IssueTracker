package cubastion.xnet.issuetracker.xnet_issuetracker.template;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.resolution.Resolution;
import cubastion.xnet.issuetracker.xnet_issuetracker.template.graphqlDTO.IssueTypeInTemplateDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class TemplateService implements TemplateServiceImpL {

    @Autowired
    private TemplateRepository repo;


    @Autowired
    private IssuetypeInTemplateRepository issuetypeInTemplateRepository;

    @Override
    public Template addTemplate(Template entity) {
        try{
            return repo.save(entity);
        }catch (Exception e){
            throw new xNetInvalidInputException("Failed to create Template: Please add valid input fields!");
        }
    }

    @Override
    public List<Template> getAll() {
        List<Template> templates = null;
        try{
            templates = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (templates.isEmpty())
            throw new xNetNotFoundException("Templates List is Null");
        return templates;
    }

    @Override
    public Optional<Template> getTemplateById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("Template with ID: " + String.valueOf(id) + " is not found")
        ));
    }

    public Template update(Template entity) {

        Template existingTemplate = repo.findById(entity.getId()).orElse(null);

        if (existingTemplate == null) {
            throw new xNetNotFoundException("Template Not Found!");
        }
        if(entity.getDescription()!=null)
            existingTemplate.setDescription(entity.getDescription());
        if(entity.getName()!=null)
            existingTemplate.setDescription(entity.getDescription());
        if(entity.getWorkflowId()!=null)
            existingTemplate.setWorkflowId(entity.getWorkflowId());
        return repo.save(existingTemplate);
    }

    public String delete(Long id) {
       repo.deleteById(id);
       return "Template Id:"+ id+ ", Deleted Successfully!";
    }




//    for IssueTypeInTemplate methods
    public List<IssuetypeInTemplate> addIssueTypeInTemplate(IssueTypeInTemplateDTO inTemplateDTO){
        ArrayList<IssuetypeInTemplate> inTemplateList=new ArrayList<>();
        Long templateID=inTemplateDTO.getTemplateId();
        for(Long id: inTemplateDTO.getIssuetypeIds()){
            inTemplateList.add(new IssuetypeInTemplate(templateID,id));
        }
        return issuetypeInTemplateRepository.saveAll(inTemplateList);
    }

    public List<IssuetypeInTemplate> getAllIssuetypeInTemplate(){
        return issuetypeInTemplateRepository.findAll();
    }
}
