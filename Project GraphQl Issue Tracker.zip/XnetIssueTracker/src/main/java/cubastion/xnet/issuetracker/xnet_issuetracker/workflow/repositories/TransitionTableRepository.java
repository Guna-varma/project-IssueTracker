package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories;

import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.TransitionTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransitionTableRepository extends JpaRepository<TransitionTable, Long> {
}