package cubastion.xnet.issuetracker.xnet_issuetracker.project;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterFields;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JoinFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JunctionTableFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.MultiFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.Pagination;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses.ProjectPaginationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProjectService implements ProjectServiceImpl {

    @Autowired
    private JoinFiltersSpecification<Project> projectFiltersSpecification;

    @Autowired
    private MultiFiltersSpecification<Project> projectMultiFiltersSpecification;

    @Autowired
    private JunctionTableFiltersSpecification<Project> junctionTableFiltersSpecification;

    @Autowired
    private ProjectRepo projectRepo;

    @Override
    public Project addProject(Project project) {
        try {
            return projectRepo.save(project);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create Project: Please add Input fields!");
        }

    }

    @Override
    public List<Project> getAll() {
        List<Project> projectList = null;
        try {
            projectList = projectRepo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (projectList.isEmpty())
            throw new xNetNotFoundException("project List is Null");
        return projectList;
    }

    @Override
    public Project getProjectById(Long id) {

//        if(projectRepo.existsById(id))
        return projectRepo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("Project with ID: " + String.valueOf(id) + " is not found")
        );

    }

    @Override
    public Project update(Project project) {

        Project p = projectRepo.findById(project.getId()).orElseThrow(
                () -> new xNetNotFoundException("Project Not found")
        );
        if (project.getProjectName() != null) {
            p.setProjectName(project.getProjectName());
        }
        if (project.getProjectDescription() != null) {
            p.setProjectDescription(project.getProjectDescription());
        }
        if (project.getProjectKey() != null) {
            p.setProjectKey(project.getProjectKey());
        }
        if (project.getProjectLead() != null) {
            p.setProjectLead(project.getProjectLead());
        }
        if (project.getAssigneeType() != 0) {
            p.setAssigneeType(project.getAssigneeType());
        }
        return projectRepo.save(p);
    }

    @Override
    public List<Project> findProjectsWithPredicate() {
//        GenericSpecification<Project> genericSpecification = new GenericSpecification<>();
//        genericSpecification.add(new SearchCriteria(PROJECT_LEAD,SearchOperation.EQUAL));
//        genericSpecification.add(new SearchCriteria(ASSIGNEE_TYPE, SearchOperation.EQUAL));
//        genericSpecification.add(new SearchCriteria(ID, SearchOperation.GREATER_THAN));
//
//        return projectRepo.findAll(genericSpecification);
        return null;
    }

    public ProjectPaginationResponse<List<Project>> projectPagination(Integer pageNumber, Integer offset) {
        pageNumber--;
        if (pageNumber < 0 | offset < 1) {
            throw new xNetInvalidInputException("Invalid input, please enter Valid pageNumber & offset..!");
        } else {
            PageRequest p = PageRequest.of(pageNumber, offset);
            Page<Project> pageUser = this.projectRepo.findAll(p);
            List<Project> userData = pageUser.getContent();

            if (userData == null | userData.isEmpty()) {
                throw new xNetNotFoundException("Data Not Found in this page..!");
            }

            return new ProjectPaginationResponse<>(
                    userData,
                    new Pagination(
                            (int) pageUser.getTotalElements(),
                            p.getPageSize(),
                            pageUser.getTotalPages(),
                            p.getPageNumber() + 1,
                            Math.min(p.getPageNumber() + 2, pageUser.getTotalPages()),
                            p.getPageNumber()
                    )
            );
        }
    }

    public List<Project> projectWithFilter(FilterKey filter) {
        Specification<Project> spec = new FilterSpecification<Project>().fSpecWithFilter(filter);

        for (FilterFields filterField : filter.getKey()) {
            if ((filterField.getOperator().isEmpty() | filterField.getKeyValue().isEmpty())) {
                throw new xNetInvalidInputException(" 'keyValue' or 'operator' is Empty, Please add valid Inputs..!");
            } else {
                return projectRepo.findAll(spec);
            }
        }
        return (List<Project>) spec;
    }

    public List<Project> projectJoinFilter(RequestDto requestDto) {
        Specification<Project> searchSpecification = projectFiltersSpecification
                .getSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());

        try{
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return projectRepo.findAll(searchSpecification);
                }
            }
        } catch (Exception e){
            throw new xNetInvalidInputException("Please Add valid 'JoinTable' or 'Column' name");
        }
        return projectRepo.findAll(searchSpecification);
    }

    public List<Project> projectMultiJoinFilter(RequestDto requestDto) {
        Specification<Project> searchSpecification = projectMultiFiltersSpecification.getMultiSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());
        try{
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable1().isEmpty() | searchRequestDto.getJoinTable2().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable1' or 'JoinTable2' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return projectRepo.findAll(searchSpecification);
                }
            }
        } catch (Exception e){
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return projectRepo.findAll(searchSpecification);
    }

    public List<Project> projectJunctionTableFilter(RequestDto requestDto) {
        Specification<Project> searchSpecification = junctionTableFiltersSpecification.getMultiSearchSpecification(requestDto.getSearchRequestDto(), requestDto.getGlobalOperator());
        try{
            for (SearchRequestDto searchRequestDto : requestDto.getSearchRequestDto()) {
                if ((searchRequestDto.getJoinTable1().isEmpty() | searchRequestDto.getJoinTable2().isEmpty() | searchRequestDto.getColumn().isEmpty())) {
                    throw new xNetInvalidInputException(" 'JoinTable1' or 'JoinTable2' or 'Column' is Empty, Please add valid Inputs..!");
                } else {
                    return projectRepo.findAll(searchSpecification);
                }
            }
        } catch (Exception e){
            throw new xNetInvalidInputException("Please Add valid Input Fields");
        }

        return projectRepo.findAll(searchSpecification);
    }
}
