package cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable;

import java.util.List;
import java.util.Optional;

public interface RolesTableServiceImpl {

    RolesTable addRolesTable(RolesTable rolesTable);

    List<RolesTable> getAllRolesTable();

    Optional<RolesTable> getByIdRolesTable(Long id);
}
