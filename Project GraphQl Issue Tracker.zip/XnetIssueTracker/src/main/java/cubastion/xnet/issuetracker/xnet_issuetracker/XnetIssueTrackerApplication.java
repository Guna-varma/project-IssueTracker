package cubastion.xnet.issuetracker.xnet_issuetracker;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeColumnNameInfoRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.DataTypeRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueTypeRepository;


import graphql.scalars.ExtendedScalars;

import graphql.schema.GraphQLDirective;
import graphql.schema.GraphQLScalarType;
import graphql.schema.GraphQLSchema;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.graphql.execution.RuntimeWiringConfigurer;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jakarta.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@SpringBootApplication
@Configuration
public class XnetIssueTrackerApplication implements CommandLineRunner {

    @Autowired
    DataTypeRepository dataTypeRepository;

    @Autowired
    IssueTypeRepository issueTypeRepository;

    @Autowired
    AttributeColumnNameInfoRepository attributeColumnNameInfoRepository;

    public static void main(String[] args) {
        SpringApplication.run(XnetIssueTrackerApplication.class, args);
    }

    @Bean
    public RuntimeWiringConfigurer runtimeWiringConfigurer() {
        return wiringBuilder -> wiringBuilder.scalar(ExtendedScalars.GraphQLLong);
    }

    @Bean
    public RuntimeWiringConfigurer runDate() {
        return wiringBuilder -> wiringBuilder.scalar(ExtendedScalars.Date);
    }

    @Bean
    public RuntimeWiringConfigurer runJSON() {
        return wiringBuilder -> wiringBuilder.scalar(ExtendedScalars.Json);
    }

    @Bean
    public RuntimeWiringConfigurer dateTime() {
        return wiringBuilder -> wiringBuilder.scalar(ExtendedScalars.DateTime);
    }

    @Override
    public void run(String... args) throws Exception {
    }

    @Autowired
    private EntityManager entityManager;

    // Allowed permission For  access-control-allow-origin header for graphQL
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(final CorsRegistry registry) {
                registry.addMapping("/graphql/**")
                        .allowedOrigins(CorsConfiguration.ALL)
                        .allowedHeaders(CorsConfiguration.ALL)
                        .allowedMethods(CorsConfiguration.ALL);
            }
        };
    }

}