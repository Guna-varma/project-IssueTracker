package cubastion.xnet.issuetracker.xnet_issuetracker.template;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.persistence.*;

@Entity(name = "IssuetypeInTemplate")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class IssuetypeInTemplate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    @Column(name = "templateId",nullable = false)
    private Long templateId;

    @NotBlank
    @Column(name = "issuetypeId",nullable = false)
    private Long issuetypeId;

    public IssuetypeInTemplate(Long templateId, Long issuetypeId) {
        this.templateId = templateId;
        this.issuetypeId = issuetypeId;
    }
}


