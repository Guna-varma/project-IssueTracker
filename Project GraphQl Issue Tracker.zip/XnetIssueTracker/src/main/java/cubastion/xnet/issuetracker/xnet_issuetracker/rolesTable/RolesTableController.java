package cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable;

import cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable.graphql.RolesTableInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class RolesTableController {

    @Autowired
    private RolesTableService service;

    @MutationMapping
    private RolesTable addRolesTable(@Argument("addRolesTableInput")RolesTableInput input){

        RolesTable rolesTable = new RolesTable();
        rolesTable.setName(input.getName());
        return service.addRolesTable(rolesTable);
    }

    @QueryMapping
    private List<RolesTable> getAllRolesTable(){
        return service.getAllRolesTable();
    }

    @QueryMapping
    private Optional<RolesTable> getRolesTableById(@Argument Long id){
        return service.getByIdRolesTable(id);
    }
}
