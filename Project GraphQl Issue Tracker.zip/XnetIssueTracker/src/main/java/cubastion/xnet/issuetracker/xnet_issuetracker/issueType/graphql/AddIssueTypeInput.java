package cubastion.xnet.issuetracker.xnet_issuetracker.issueType.graphql;

import lombok.Getter;

import lombok.Setter;

@Getter
@Setter
public class AddIssueTypeInput {

    private String issueTypeName;

    private String description;

}