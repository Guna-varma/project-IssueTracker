package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "workflowStepTable")
public class WorkflowStepTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name="stepName",nullable = false)
    private String stepName;

    @Column(name = "linkedStatusId")
    private Long linkedStatusId;

//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sequence")
    private int sequence;

    @Column(name = "workflowTableId")
    private Long workflowTableId;

    @ManyToOne
    @JoinColumn(name = "workflowTableId", insertable=false, updatable=false)
    private WorkflowTable workflowTable;

    @ManyToOne
    @JoinColumn(name = "linkedStatusId", insertable=false, updatable=false)
    private WorkflowStatus workflowStatus;

}