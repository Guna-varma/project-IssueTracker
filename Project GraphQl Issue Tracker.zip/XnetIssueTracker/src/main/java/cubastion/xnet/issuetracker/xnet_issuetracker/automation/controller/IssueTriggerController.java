package cubastion.xnet.issuetracker.xnet_issuetracker.automation.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.IssueTrigger;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.IssueTriggerInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.IssueTriggerServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class IssueTriggerController {
    @Autowired
    private IssueTriggerServiceImpl issueTriggerService;
    @MutationMapping
    private IssueTrigger addIssueTrigger(@Argument("issueTriggerInput") IssueTriggerInput input){
        IssueTrigger issueTrigger=new IssueTrigger();
        issueTrigger.setDescription(input.getDescription());
        issueTrigger.setName(input.getName());
        return issueTriggerService.createIssueTrigger(issueTrigger);
    }

    @QueryMapping
    private List<IssueTrigger> getAllIssueTrigger(){
    return issueTriggerService.getAllIssueTrigger();
    }

    @QueryMapping
    private IssueTrigger getIssueTriggerById(@Argument Long id){
        return issueTriggerService.getIssueTriggerById(id);
    }

    @MutationMapping
    private String deleteIssueTrigger(@Valid @Argument Long id){
        return issueTriggerService.deleteIssueTriggerById(id);
    }

    @QueryMapping
    private List<IssueTrigger> getTriggerIdByName(@Argument String name){
        return issueTriggerService.getTriggerIdByName(name);
    }

}