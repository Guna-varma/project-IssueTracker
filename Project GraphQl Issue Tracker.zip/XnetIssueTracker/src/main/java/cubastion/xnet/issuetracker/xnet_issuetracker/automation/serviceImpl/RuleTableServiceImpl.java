package cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.RuleTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.RuleTableRepository;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class RuleTableServiceImpl {
    @Autowired
    private RuleTableRepository ruleTableRepository;
    public RuleTable createRuleTable(RuleTable ruleTable) {
        return ruleTableRepository.save(ruleTable);
    }

    public List<RuleTable> getAllRuleTableList() {
        return ruleTableRepository.findAll();
    }
    public List<RuleTable> getRuleByTriggerId(Long issueTriggerId){
        return ruleTableRepository.findAllByIssueTriggerId(issueTriggerId);
    }

    public List<RuleTable> getAllRuleByConditionIds(ArrayList<Long> conditionId){
        return ruleTableRepository.findAll(getRuleByconditonIDs(conditionId));
    }

    public RuleTable getRuleTableListById(Long id) {
        return ruleTableRepository.findById(id).orElseThrow();
    }

    public String deleteRuleTableById(Long id) {
        ruleTableRepository.deleteById(id);
        return "Priority Id: "+id+" Deleted Successfully!!";
    }

    public RuleTable updateRuleTable(Long id, Long ownerId, Long issueTriggerId, Long conditionTableId, Long postFunctionId, String description, String actionLevel, String category) throws NotFoundException {
        Optional<RuleTable> ruleTable=ruleTableRepository.findById(id);
        if ((ruleTable.isPresent())){
            RuleTable ruleTable1=ruleTable.get();
            if(ownerId != null)
                ruleTable1.setOwnerId(ownerId);
            if(issueTriggerId != null)
                ruleTable1.setIssueTriggerId(issueTriggerId);
            if(conditionTableId != null)
                ruleTable1.setConditionTableId(conditionTableId);
            if(postFunctionId != null)
                ruleTable1.setPostFunctionId(postFunctionId);
            if(description != null)
                ruleTable1.setDescription(description);
            if(actionLevel != null)
                ruleTable1.setActionLevel(actionLevel);
            if(category != null)
                ruleTable1.setCategory(category);
            ruleTableRepository.save(ruleTable1);
            return ruleTable1;
        }
        throw new NotFoundException("Not found Rule to update!");
    }



    public Specification<RuleTable> getRuleByconditonIDs(ArrayList<Long> conditionId){
        return ((root, query, criteriaBuilder) -> criteriaBuilder.like(root.get("conditionTableId"),"%" + conditionId + "%"));
    }

    public List<RuleTable> getAllRulesForCreateIssue(String category) {
        return ruleTableRepository.findAllByCategory(category);
    }
}
