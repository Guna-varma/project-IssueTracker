package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowStatusRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowStepTableRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStepTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.WorkflowStatusDTO;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.services.WorkflowStepService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkflowStepServiceImpl implements WorkflowStepService {
    @Autowired
    private WorkflowStepTableRepository workflowStepTableRepository;

    public WorkflowStepTable createWorkflowTable(WorkflowStepTable workflowStepTable) {
        try {
            return workflowStepTableRepository.save(workflowStepTable);

        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create Workflow step: Please add Input fields!");
        }
    }

    public List<WorkflowStepTable> getAllWorkflowStep() {
        return workflowStepTableRepository.findAll();
    }

    public WorkflowStepTable getWorkflowStepById(Long id) {
        return workflowStepTableRepository.findById(id).get();
    }

    public List<WorkflowStatusDTO> getStatusNameByWorkflowId(Long workflowTableId) {
        return workflowStepTableRepository.findWorkflowStatusNameByWorkflowId(workflowTableId);
    }
}
