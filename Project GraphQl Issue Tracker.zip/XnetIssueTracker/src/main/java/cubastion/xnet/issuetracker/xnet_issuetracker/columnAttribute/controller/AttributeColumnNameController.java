package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql.AttributeColumnNameInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql.AttributeDisplayNameInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.graphql.DataTypeDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.DataTypeInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeColumnNameInfoRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service.AttributeColumnNameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class AttributeColumnNameController {

    @Autowired
    AttributeColumnNameService attributeColumnNameService;

    @MutationMapping
    private AttributeColumnNameInfo addAttributeColumnNameInfo(@Argument(name = "addAttributeColumnNameInfo") AttributeColumnNameInput attributeColumnNameInput){
        AttributeColumnNameInfo attributeColumnNameInfo=new AttributeColumnNameInfo();
        attributeColumnNameInfo.setAttributeColumnName(attributeColumnNameInput.getAttributeColumnName());
        attributeColumnNameInfo.setId(attributeColumnNameInput.getId());
        attributeColumnNameInfo.setDataTypeInfoId(attributeColumnNameInput.getDataTypeInfoId());
        attributeColumnNameInfo.setSubscriptionTypeId(attributeColumnNameInput.getSubscriptionTypeId());
        return attributeColumnNameService.addAttributeColumnNameInfo(attributeColumnNameInfo) ;
    }

    @QueryMapping
    private List<AttributeColumnNameInfo> getAllAttributeColumnNameInfo(){
        return attributeColumnNameService.getAllAttributeColumnName();
    }

    @QueryMapping
    private Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoById(@Argument Long id){
        return attributeColumnNameService.getAttributeColumnNameInfoById(id);
    }

    @QueryMapping
    private Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoByKeyId(@Argument String attributeKey){
        return attributeColumnNameService.getAttributeColumnNameInfoByKeyId(attributeKey);
    }

}
