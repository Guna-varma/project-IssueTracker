package cubastion.xnet.issuetracker.xnet_issuetracker.users.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;
import cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable.RolesTable;
import jakarta.persistence.*;
import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "project_user_roles_table")
public class PROJECT_USER_ROLES_TABLE {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id",nullable = false)
    private Long id;

    @Column(name = "userId",nullable = false)
    private Long userId;

    @Column(name = "roleId",nullable = false)
    private Long roleId;

    @Column(name = "projectId",nullable = false)
    private Long projectId;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "userId",insertable = false,updatable = false)
    private User user;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "projectId",insertable = false,updatable = false)
    private Project project;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "roleId",insertable = false, updatable = false)
    private RolesTable rolesTable;

}
