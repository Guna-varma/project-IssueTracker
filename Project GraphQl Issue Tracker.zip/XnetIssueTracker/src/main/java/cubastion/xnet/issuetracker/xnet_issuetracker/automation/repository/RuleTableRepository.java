package cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.IssueTrigger;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.PostFunction;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.RuleTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface RuleTableRepository extends JpaRepository<RuleTable, Long> , JpaSpecificationExecutor<RuleTable>, PagingAndSortingRepository<RuleTable,Long> {
    List<RuleTable> findAllByIssueTriggerId(Long issueTriggerId);

    List<RuleTable> findAllByCategory(String category);

//    List<RuleTable> findAllByConditionTableId(ArrayList<Long> conditionTableId);
}
