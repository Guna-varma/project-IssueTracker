package cubastion.xnet.issuetracker.xnet_issuetracker.priority;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.priority.graphql.AddPriorityInput;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class PriorityController {

    @Autowired
    private PriorityService service;

    @MutationMapping
    private Priority addPriority(@Argument("addPriorityInput")AddPriorityInput addPriorityInput){

            if(addPriorityInput.getProjectId()>0){
                Priority p = new Priority();
                p.setDescription(addPriorityInput.getDescription());
                p.setProjectId(addPriorityInput.getProjectId());
                p.setPriorityName(addPriorityInput.getPriorityName());
                p.setIconColor(addPriorityInput.getIconColor());
                p.setStatusColor(addPriorityInput.getStatusColor());
                return service.addPriority(p);
            }else {
              throw   new xNetInvalidInputException("Please add valid ProjectId!");
            }
    }

    @QueryMapping
    private List<Priority> getAllPriority(){
        return service.getAllPriority();
    }

    @QueryMapping
    private Optional<Priority> getPriorityById(@Argument Long id){
            return service.getPriorityById(id);
    }

    @MutationMapping
    private String deletePriority(@Valid @Argument Long id){
        return service.deletePriorityById(id);
    }
}
