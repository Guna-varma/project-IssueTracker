package cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling;

public class xNetInvalidInputException extends RuntimeException {

    public xNetInvalidInputException(String message) {
        super(message);
    }

}
