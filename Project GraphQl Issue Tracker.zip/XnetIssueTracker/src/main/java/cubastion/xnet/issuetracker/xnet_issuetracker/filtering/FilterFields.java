package cubastion.xnet.issuetracker.xnet_issuetracker.filtering;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueType;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import jakarta.persistence.criteria.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.domain.Specification;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Data
@Getter
@Setter
public class FilterFields {

    private List<FilterFields> key;

    private String predicate;
    private String operator;
    private String value;
    private String rbValue;
    private List<String> valuesIN;
    private String joinTable;

    private String keyValue;

    public Predicate generateCriteria(CriteriaBuilder builder, Path field) {

        List<Predicate> predicates = new ArrayList<>();

        try {
            switch (operator) {

                case "lt":
                    return builder.lt(field, Integer.parseInt(value));

                case "le":
                    return builder.le(field, Integer.parseInt(value));

                case "gt":
                    return builder.gt(field, Integer.parseInt(value));

                case "ge":
                    return builder.ge(field, Integer.parseInt(value));

                case "eq":
                    return builder.equal(field, Integer.parseInt(value));

                case "endsWith":
                    return builder.like(field, "%" + value);

                case "startsWith":
                    return builder.like(field, value + "%");

                case "contains":
                    return builder.like(field, "%" + value + "%");

                case "equal":
                    return builder.equal(field, value);

                case "NOT":
                    return builder.notLike(field, "%" + value + "%");

                case "BETWEEN":
                    return builder.between(field, Date.valueOf(value),Date.valueOf(rbValue));

                case "RANGE":
                    return builder.and(builder.greaterThanOrEqualTo(field, (Comparable) value),
                            builder.lessThanOrEqualTo(field, (Comparable) rbValue));

                case "IN":
                    return builder.or(field.in(valuesIN));

                case "ANDs":
                    Expression<Boolean> e1 = builder.like(field, "%" + value + "%");
                    return builder.and((Predicate) e1);

                case "ORs":
                    Expression<Boolean> or1 = builder.like(field, "%" + value + "%");
                    return builder.or((Predicate) or1);




            }

        } catch (Exception e) {
            throw new xNetNotFoundException("Input Values value not found!");
        }
        return null;
    }

}