package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories;

import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WorkflowStatusRepository extends JpaRepository<WorkflowStatus, Long> {
}