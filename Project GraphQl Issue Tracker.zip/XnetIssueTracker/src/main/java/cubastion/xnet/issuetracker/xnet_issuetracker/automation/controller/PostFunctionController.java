package cubastion.xnet.issuetracker.xnet_issuetracker.automation.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.PostFunction;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.PostFunctionInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.PostFunctionServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
@Controller
public class PostFunctionController {
    @Autowired
    private PostFunctionServiceImpl postFunctionService;

    @MutationMapping
    private PostFunction addPostFunction(@Argument("postFunctionInput") PostFunctionInput input){
        PostFunction postFunction=new PostFunction();
        postFunction.setDescription(input.getDescription());
        postFunction.setName(input.getName());
        postFunction.setPostFunctionKey((input.getPostFunctionKey()));
        return postFunctionService.createPostFunction(postFunction);
    }

    @QueryMapping
    private List<PostFunction> getAllPostFunction(){
        return postFunctionService.getAllPostFunc();
    }

    @QueryMapping
    private PostFunction getPostFunctionById(@Argument Long id){
        return postFunctionService.getPostFunctionById(id);
    }

    @MutationMapping
    private String deletePostFunction(@Valid @Argument Long id){
        return postFunctionService.deletePostFunctionById(id);
    }
}
