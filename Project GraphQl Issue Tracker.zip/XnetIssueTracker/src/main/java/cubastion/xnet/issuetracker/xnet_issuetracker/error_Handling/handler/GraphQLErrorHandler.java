package cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.handler;

import graphql.GraphQLError;
import graphql.GraphQLException;
import io.micrometer.core.instrument.config.validate.ValidationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.ArrayList;
import java.util.List;

@ControllerAdvice
public class GraphQLErrorHandler {

//
//    @ExceptionHandler(GraphQLException.class)
//    public ResponseEntity<GraphQLErrorResponse> handleGraphQLException(GraphQLException ex) {
//        List<GraphQLError> errors = ex.getErrors();
//        List<String> validationErrors = new ArrayList<>();
//        for (GraphQLError error : errors) {
//            if (error instanceof ValidationException) {
//                validationErrors.add(error.getMessage());
//            }
//        }
//        GraphQLErrorResponse errorResponse = new GraphQLErrorResponse(validationErrors);
//        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
//    }
}
