package cubastion.xnet.issuetracker.xnet_issuetracker.template.graphqlDTO;

import cubastion.xnet.issuetracker.xnet_issuetracker.template.IssuetypeInTemplate;
import lombok.Data;

import java.util.ArrayList;

@Data
public class IssueTypeInTemplateDTO {

    private Long templateId;

    private ArrayList<Long> issuetypeIds;
}

