package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.WorkflowStepTableInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowStatusRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowStepTableRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl.WorkflowStepServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStepTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.WorkflowStatusDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class WorkflowStepController {
    @Autowired
    WorkflowStepServiceImpl workflowStepService;

    @Autowired
    WorkflowStatusRepository statusRepository;

    @Autowired
    WorkflowStepTableRepository stepTableRepository;


    @MutationMapping
    private WorkflowStepTable addWorkflowStepTable(@Argument("workflowStepTableInput") WorkflowStepTableInput input) {
        WorkflowStepTable wf = new WorkflowStepTable();
        wf.setStepName(input.getStepName());
        wf.setLinkedStatusId(input.getLinkedStatusId());
        wf.setWorkflowTableId(input.getWorkflowTableId());

        WorkflowStatus workflowStatus = statusRepository.findById(input.getLinkedStatusId()).get();
        wf.setWorkflowStatus(workflowStatus);
        return workflowStepService.createWorkflowTable(wf);
    }

    private WorkflowStatus getStatusByLinkedStatus(){
        WorkflowStepTable wf = new WorkflowStepTable();
        WorkflowStatus workflowStatus = statusRepository.findById(wf.getLinkedStatusId()).get();
        return  workflowStatus;
    }

    @QueryMapping
    private List<WorkflowStepTable> getAllWorkflowStepTable() {
        return workflowStepService.getAllWorkflowStep();
    }

    @QueryMapping
    private WorkflowStepTable getWorkflowStepTableById(@Argument Long id) {
        try {
            return workflowStepService.getWorkflowStepById(id);
        } catch (Exception e) {
            throw new xNetInvalidInputException("WorkflowTable Id is Invalid, Please fill the correct Id");
        }
    }

    @QueryMapping
    private List<WorkflowStatusDTO> getStatusNameByWorkflowId(@Argument Long workflowTableId) {
        return workflowStepService.getStatusNameByWorkflowId(workflowTableId);

    }

}
