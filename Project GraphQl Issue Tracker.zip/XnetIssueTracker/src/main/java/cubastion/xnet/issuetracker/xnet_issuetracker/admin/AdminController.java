package cubastion.xnet.issuetracker.xnet_issuetracker.admin;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionLevel;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.ActionLevelRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeDisplayName;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.DataTypeInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeColumnNameInfoRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeDisplayNameRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.DataTypeRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.RolesTableRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.config.RandomKeyGenerator;
import cubastion.xnet.issuetracker.xnet_issuetracker.config.YamlPropertySourceFactory;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueType;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueTypeRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.IssuesRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable.RolesTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.WorkflowStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Controller
@PropertySource(value = "classpath:application.yml", factory = YamlPropertySourceFactory.class)
public class AdminController {

    //    @Value("$(data.totalIntegerColumns)")
    private int totalIntegerColumns;

    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    private DataTypeRepository dataTypeRepository;

    @Autowired
    private IssueTypeRepository issueTypeRepository;

    @Autowired
    IssuesRepository issuesRepository;

    @Autowired
    private AttributeColumnNameInfoRepository attributeColumnNameInfoRepository;

    @Autowired
    private AttributeDisplayNameRepository attributeDisplayNameRepository;

    @Autowired
    private WorkflowStatusRepository workflowStatusRepository;

    @Autowired
    private RolesTableRepository rolesTableRepository;
    @Autowired
    private ActionLevelRepository actionLevelRepository;


    @QueryMapping
    @ExceptionHandler(xNetNotFoundException.class)
    private String addAdminData() {
        performAdminAction();
        return "Successfully created Default settings for project";
    }

    @MutationMapping
    private String addCustomColumn(@Argument(name = "attributeDisplayNameInput")
                                   AttributeDisplayName attributeDisplayNameInput) {

        return setAttributeDisplayName(attributeDisplayNameInput.getIssueTypeId(),
                attributeDisplayNameInput.getAttributeDisplayName(),
                attributeDisplayNameInput.getDataTypeInfoId());
    }

    private void performAdminAction() {

        if (attributeColumnNameInfoRepository.count() < 1)
            storeAttributeColumnNameInfo();
        if (issueTypeRepository.count() < 1)
            generateDefaultIssueTypes();
        if (workflowStatusRepository.count() < 1)
            generateDefaultStatus();
        if(rolesTableRepository.count()<1)
            generateDefaultRolesTable();
        if(actionLevelRepository.count()<1)
            generateDefaultActionLevel();
    }

    private void generateDefaultStatus() {
        List<WorkflowStatus> workflowStatusList = new ArrayList<>();
        workflowStatusList.add(new WorkflowStatus("TODO", " not done"));
        workflowStatusList.add(new WorkflowStatus("IN Progress", " assigned work is started"));
        workflowStatusList.add(new WorkflowStatus("IN REVIEW", "work is under review"));
        workflowStatusList.add(new WorkflowStatus("DONE", "work is done"));
        workflowStatusList.add(new WorkflowStatus("Reopen", "Reopen the completed work"));
        workflowStatusList.add(new WorkflowStatus("Resolved", " issue resolved "));
        workflowStatusList.add(new WorkflowStatus("Closed", " assigned Work completed"));
        workflowStatusList.add(new WorkflowStatus("Building", "code is building"));
        workflowStatusList.add(new WorkflowStatus("Build Broken", "build is broken"));
        workflowStatusList.add(new WorkflowStatus("Declined", "changes id declined"));
        workflowStatusList.add(new WorkflowStatus("Waiting for Support", "Support is required"));
        workflowStatusList.add(new WorkflowStatus("Changes Not Saved", "Changes done by you not saved"));
        workflowStatusList.add(new WorkflowStatus("Pending", "Work is still pending"));
        workflowStatusList.add(new WorkflowStatus("Completed", "Work is completed"));
        workflowStatusList.add(new WorkflowStatus("Planning", "Planning for solving the problem"));
        workflowStatusList.add(new WorkflowStatus("Canceled", "Cancel the changes"));
        workflowStatusList.add(new WorkflowStatus("Implementing", "Implementing the task assign"));
        workflowStatusList.add(new WorkflowStatus("Awaiting Approval", "Waiting for the approval"));
        workflowStatusList.add(new WorkflowStatus("Draft", "Changes saved in the draft"));
        workflowStatusRepository.saveAll(workflowStatusList);
    }
    private void generateDefaultActionLevel(){
        List<ActionLevel> actionLevelList=new ArrayList<>();
        actionLevelList.add(new ActionLevel("GlobalLevel"));
        actionLevelList.add(new ActionLevel("IssueLevel"));
        actionLevelList.add(new ActionLevel("ProjectLevel"));
        actionLevelRepository.saveAll(actionLevelList);
    }


    private void generateDefaultIssueTypes() {

        IssueType bug = new IssueType("Bug", " Bug to resolved");
        IssueType task = new IssueType("Task", " task to be implemented");
        IssueType epic = new IssueType("Epic", "Epic scenario");
        IssueType subTask = new IssueType("SubTask", "SubTask to be implemented");

        issueTypeRepository.save(bug);
        issueTypeRepository.save(task);
        issueTypeRepository.save(epic);
        issueTypeRepository.save(subTask);

    }

    private void generateDefaultRolesTable() {

        RolesTable administrator = new RolesTable("Administrator");
        RolesTable projectManager = new RolesTable("Project Manager");
        RolesTable projectLead = new RolesTable("Project Lead");
        RolesTable developer = new RolesTable("Developer");
        RolesTable qaEngineer = new RolesTable("QA Engineer");
        RolesTable reporter = new RolesTable("Reporter");
        RolesTable watcher = new RolesTable("Watcher");
        RolesTable commenter = new RolesTable("Commenter");
        RolesTable assignee = new RolesTable("Assignee");


        rolesTableRepository.save(administrator);
        rolesTableRepository.save(projectManager);
        rolesTableRepository.save(projectLead);
        rolesTableRepository.save(developer);
        rolesTableRepository.save(qaEngineer);
        rolesTableRepository.save(reporter);
        rolesTableRepository.save(watcher);
        rolesTableRepository.save(commenter);
        rolesTableRepository.save(assignee);

    }

    private void storeAttributeColumnNameInfo() {

        ArrayList<AttributeColumnNameInfo> attributeColumnNameInfoList = new ArrayList<>();
        Long dataTypeID = 0L;
        try {
            DataSource dataSource = jdbcTemplate.getDataSource();
            Connection con = DataSourceUtils.getConnection(dataSource);
            Statement s = con.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM Issues");
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String dataType = rsmd.getColumnTypeName(i);
                if (!dataTypeRepository.existsByDataTypeName(dataType)) {
                    dataTypeID = dataTypeRepository.save(new DataTypeInfo(dataType)).getId();
                }
                attributeColumnNameInfoList.add(new AttributeColumnNameInfo(rsmd.getColumnName(i), dataTypeID, false, new RandomKeyGenerator().getAlphaNumericKey()));
            }

            JdbcUtils.closeStatement(s);
            DataSourceUtils.releaseConnection(con, dataSource);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        attributeColumnNameInfoRepository.saveAll(attributeColumnNameInfoList);
    }

    public String setAttributeDisplayName(Long issueTypeId, String columnDisplayName, Long dataTypeInfoId) {

        String availableColumnKey = attributeColumnNameInfoRepository.findFindAvailableColumn(issueTypeId, dataTypeInfoId);
        //        AttributeColumnNameInfo attributeColumnNameInfo = attributeColumnNameInfoRepository.
        //                findFindAvailableColumn(issueTypeId,dataTypeId);
        if (availableColumnKey == null) {
            return "All fields already consumed.";
        } else {
            AttributeDisplayName attributeDisplayName = new AttributeDisplayName(
                    issueTypeId,
                    columnDisplayName,
                    dataTypeInfoId,
                    availableColumnKey
            );
            attributeDisplayNameRepository.save(attributeDisplayName);
            return "Successfully mapped " + availableColumnKey + " to " + columnDisplayName;
        }
    }
}