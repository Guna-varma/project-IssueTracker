package cubastion.xnet.issuetracker.xnet_issuetracker.utils;

public class KEYS {

    public static final String AND = "AND";
    public static final String OR = "OR";

}
