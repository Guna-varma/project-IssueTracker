package cubastion.xnet.issuetracker.xnet_issuetracker.resolution;

import java.util.List;
import java.util.Optional;

public interface ResolutionServieImpL {
    Resolution addResolution(Resolution resolution);

    List<Resolution> getAllResolution();

    Optional<Resolution> getResolutionById(Long id);

    Resolution updateResolution(Resolution resolution);
}
