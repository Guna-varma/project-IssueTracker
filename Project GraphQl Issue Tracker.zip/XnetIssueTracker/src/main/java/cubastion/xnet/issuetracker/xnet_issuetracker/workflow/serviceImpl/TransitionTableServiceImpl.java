package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.repositories.TransitionTableRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.TransitionTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.services.TransitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransitionTableServiceImpl implements TransitionService {
    @Autowired
    TransitionTableRepository transitionTableRepository;

    public TransitionTable createTransitionTable(TransitionTable transitionTable) {
        try {
            return transitionTableRepository.save(transitionTable);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create Transition: Please add Input fields!");
        }
    }

    public List<TransitionTable> getAllTransitionTable() {
        List<TransitionTable> transitionTables = null;
        try {
            transitionTables = transitionTableRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (transitionTables.isEmpty())
            throw new xNetNotFoundException("Transition table List is Null");
        return transitionTables;
    }

    public Optional<TransitionTable> getTransitionTableById(Long id) {
        return Optional.ofNullable(transitionTableRepository.findById(id).orElseThrow(
                () -> new xNetNotFoundException("WorkFlow with ID: " + String.valueOf(id) + " is not found")
        ));
    }
}
