package cubastion.xnet.issuetracker.xnet_issuetracker.filtering;

import lombok.*;
import java.util.List;

@Data
public class FilterKey {
    private List<FilterFields> key;
    private String predicate;
}