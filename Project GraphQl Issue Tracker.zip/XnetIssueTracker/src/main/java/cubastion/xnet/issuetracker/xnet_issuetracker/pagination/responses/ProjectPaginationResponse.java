package cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses;

import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.Pagination;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ProjectPaginationResponse<T>{
    private T data;
    private Pagination pagination;
}
