package cubastion.xnet.issuetracker.xnet_issuetracker.users.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserServiceImpL {

    User add(User user);

    List<User> getAll();

    Optional<User> getUserById(Long id);

    String delete(Long id);

    User update(User user);

    List<User> userWithFilter(FilterKey filter);
}