package cubastion.xnet.issuetracker.xnet_issuetracker.automation;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.Condition;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.IssueTrigger;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.PostFunction;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.RuleTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.ConditionServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.IssueTriggerServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.PostFunctionServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.RuleTableServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.IssuesService;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.List;

import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.AutomationLOV.*;

@Service
public class RulesExecutor {
    @Autowired
    RuleTableServiceImpl ruleTableService;

    @Autowired
    IssueTriggerServiceImpl issueTriggerService;
    @Autowired
    ConditionServiceImpl conditionService;
    @Autowired
    PostFunctionServiceImpl postFunctionService;
    @Autowired
    IssuesService issuesService;

    @Autowired
    UserRepository userRepository;

    @Autowired
    private JavaMailSender emailSender;

    List<IssueTrigger> issueTriggers;
    List<RuleTable> ruleTables;

    public Boolean executeRulesForIssues(String category, Long id) {

        final Boolean[] result = {false};
        ruleTables = ruleTableService.getAllRulesForCreateIssue(category);
        ruleTables.forEach(rules -> {
            long conditionID = rules.getConditionTableId();
            String configurationData = rules.getConfigurationData();
            Condition condition = conditionService.getConditionById(conditionID);
            String con_Name = condition.getConditionName();
            String con_Value = condition.getConditionValue();
            Boolean pf = issuesService.ruleConditionValidation(con_Name, con_Value, id);

            if (pf) {
                long postFunctionID = rules.getPostFunctionId();
                PostFunction postFunction = postFunctionService.getPostFunctionById(postFunctionID);
                String pf_Name = postFunction.getName();
                String pf_Key = postFunction.getPostFunctionKey();
                Boolean innerResult = executePostFunction(pf_Key, pf_Name, id, configurationData);
                if (innerResult) {
                    result[0] = true;
                }
            }
        });
        return result[0];
    }

    private Boolean executePostFunction(String pfKey, String pfName, Long id, String configurationData) {
        switch (pfKey) {

            case SENDEMAIL:
                return sendSimpleMessage(configurationData);

            case ASSIGNISSUE:

                return addDeafaultAssginee(id, configurationData);

            case TRANSITIONISSUE:
                break;

            case EDITISSUE:
                break;

        }

        return false;
    }

    private Boolean addDeafaultAssginee(Long id, String configurationData) {

        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(configurationData);
            String defaultAssignee = jsonObject.getString(ASSIGNEE);
            return issuesService.issueAssigneeUpdate(id, defaultAssignee);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }


    private boolean sendSimpleMessage(String configurationData) {
        try {
            JSONObject jsonObject = new JSONObject(configurationData);
            String mailContent = jsonObject.getString(CONTENT);
            String mailSubject = jsonObject.getString(SUBJECT);
            JSONArray mailTo = jsonObject.getJSONArray(TO);

            String[] rolesId = new String[mailTo.length()];
            for (int i = 0; i < mailTo.length(); i++) {
                rolesId[i] = mailTo.getString(i);
            }

            List<User> usersList = userRepository.findAllUsersByRoleId(rolesId);
            String[] emails = new String[usersList.size()];

            for (int j = 0; j < usersList.size(); j++) {
                emails[j] = usersList.get(j).getEmail();
            }

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("devxnet@cubastion.com");
            message.setTo(emails);
            message.setText(mailContent);
            message.setSubject(mailSubject);
            emailSender.send(message);
            return true;

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

    }

}
