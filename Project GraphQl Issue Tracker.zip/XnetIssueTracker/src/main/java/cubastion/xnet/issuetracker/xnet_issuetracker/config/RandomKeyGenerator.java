package cubastion.xnet.issuetracker.xnet_issuetracker.config;

import java.util.*;
import java.nio.charset.*;

public class RandomKeyGenerator {


   public  String getAlphaNumericKey(){
//       int n=10;
//        byte[] array = new byte[256];
//        new Random().nextBytes(array);
//
//        String randomString = new String(array, Charset.forName("UTF-8"));
//
//        StringBuffer r = new StringBuffer();
//        for (int k = 0; k < randomString.length(); k++) {
//            char ch = randomString.charAt(k);
//            if (((ch >= 'a' && ch <= 'z')
//                    || (ch >= 'A' && ch <= 'Z')
//                    || (ch >= '0' && ch <= '9'))
//                    && (n > 0)) {
//                r.append(ch);
//                n--;
//            }
//        }
//       r.toString()
//        UUID.fromString(r.toString())
        return  UUID.randomUUID().toString();
    }


}