package cubastion.xnet.issuetracker.xnet_issuetracker.resolution;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.resolution.graphql.AddResolutionInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class ResolutionController {

    @Autowired
    private ResolutionService service;

    @MutationMapping
    private Resolution addResolution(@Argument(name = "addResolutionInput") AddResolutionInput addResolutionInput){
        if(addResolutionInput.getProjectId()>0) {
            Resolution r = new Resolution();
            r.setResolutionName(addResolutionInput.getResolutionName());
            r.setDescription(addResolutionInput.getDescription());
            r.setIconUrl(addResolutionInput.getIconUrl());
            r.setProjectId(addResolutionInput.getProjectId());
            return service.addResolution(r);
        }else {
        throw   new xNetInvalidInputException("Please add valid ProjectId!");
    }


    }

    @QueryMapping
    private List<Resolution> getAllResolution(){
        return service.getAllResolution();
    }

    @QueryMapping
    private Optional<Resolution> getResolutionById(@Argument Long id){
            return service.getResolutionById(id);
    }

    @MutationMapping
    private Resolution updateResolution(@Argument("updateResolutionInput")Resolution resolution){
        return service.updateResolution(resolution);
    }

}