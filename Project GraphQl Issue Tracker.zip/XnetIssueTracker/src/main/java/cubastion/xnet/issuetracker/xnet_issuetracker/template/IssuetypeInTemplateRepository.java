package cubastion.xnet.issuetracker.xnet_issuetracker.template;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IssuetypeInTemplateRepository extends JpaRepository<IssuetypeInTemplate,Long>{



}
