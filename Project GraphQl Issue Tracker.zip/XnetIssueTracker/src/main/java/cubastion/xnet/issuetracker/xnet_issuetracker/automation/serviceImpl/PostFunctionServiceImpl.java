package cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.PostFunction;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.PostFunctionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PostFunctionServiceImpl {
    @Autowired
    private PostFunctionRepository postFunctionRepository;
    public PostFunction createPostFunction(PostFunction postFunction) {
        return postFunctionRepository.save(postFunction);
    }

    public List<PostFunction> getAllPostFunc() {
        return postFunctionRepository.findAll();
    }

    public PostFunction getPostFunctionById(Long id) {
        return postFunctionRepository.findById(id).orElseThrow(null);
    }

    public String deletePostFunctionById(Long id) {
        postFunctionRepository.deleteById(id);
        return "Priority Id: "+id+" Deleted Successfully!!";
    }
}
