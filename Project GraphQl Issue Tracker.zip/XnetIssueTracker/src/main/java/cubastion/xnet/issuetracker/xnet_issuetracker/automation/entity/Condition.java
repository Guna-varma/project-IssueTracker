package cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "conditionTable")
public class Condition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "conditionName")
    private String conditionName;

    @Column(name="conditionValue")
    private String conditionValue;

    @Column(name = "definition")
    private String definition;

    @OneToMany(mappedBy = "condition", cascade = CascadeType.ALL)
    private List<RuleTable> ruleTables;

}
