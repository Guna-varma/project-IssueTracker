package cubastion.xnet.issuetracker.xnet_issuetracker.priority.graphql;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class AddPriorityInput {

    private String priorityName;
    private Long projectId;
    private String description;
    private String iconColor;
    private String statusColor;
}