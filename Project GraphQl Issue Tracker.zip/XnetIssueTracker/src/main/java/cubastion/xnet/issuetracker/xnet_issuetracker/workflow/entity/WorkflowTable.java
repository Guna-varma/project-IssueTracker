package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity;

import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "workflowTable")
public class WorkflowTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name = "name",nullable = false)
    private String name;

    @Column(name = "description")
    private String description;

    @CreationTimestamp
    @Column(name = "createdAt", nullable = false, updatable = false)
    private Date createdAt;

    @UpdateTimestamp
    @Column(name = "updatedAt", nullable = false)
    private Date updatedAt;

    @OneToMany(mappedBy = "workflowTable", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<WorkflowStepTable> workflowStepTables;

    @OneToMany(mappedBy = "workflowTable", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Issues> issues;

}