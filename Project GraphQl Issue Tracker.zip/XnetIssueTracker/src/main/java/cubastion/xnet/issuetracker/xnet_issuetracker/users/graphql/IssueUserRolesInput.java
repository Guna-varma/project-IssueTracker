package cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IssueUserRolesInput {
    private Long user_id;
    private Long role_id;
    private Long issue_id;
}
