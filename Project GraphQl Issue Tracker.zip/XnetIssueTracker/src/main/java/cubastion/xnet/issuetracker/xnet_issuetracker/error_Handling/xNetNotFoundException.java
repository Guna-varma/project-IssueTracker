package cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling;

public class xNetNotFoundException extends RuntimeException {


    public xNetNotFoundException(String message) {
        super(message);

    }

}
