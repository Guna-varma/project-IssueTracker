package cubastion.xnet.issuetracker.xnet_issuetracker.users.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql.IssueUserRolesInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.service.Issues_User_Roles_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class Issues_User_Roles_Controller {

    @Autowired
    private Issues_User_Roles_Service service;

    @MutationMapping
    private ISSUE_USER_ROLES_TABLE addIssueUserRoles(@Argument("addIssueUserRolesInput") IssueUserRolesInput input){


        ISSUE_USER_ROLES_TABLE u = new ISSUE_USER_ROLES_TABLE();
            if (input.getRole_id() > 0) {
                u.setRole_id(input.getRole_id());
            } else {
                throw new xNetInvalidInputException("Please enter valid RoleId");
            }
            if (input.getUser_id() > 0) {
                u.setUser_id(input.getUser_id());
            } else {
                throw new xNetInvalidInputException("please enter Valid UserId");
            }
            if(input.getIssue_id()>0){
                u.setIssue_id(input.getIssue_id());
            }else {
                throw new xNetInvalidInputException("Please enter valid issueId! ");
            }
            return service.addIssueUserRoles(u);
    }

    @QueryMapping
    private List<ISSUE_USER_ROLES_TABLE> getAllIssueUserRoles(){
        return service.getAllIssueUserRoles();
    }

    @QueryMapping
    private Optional<ISSUE_USER_ROLES_TABLE> getIssueUserRolesById(@Argument Long id){
        return service.getIssueUserRolesById(id);
    }

}
