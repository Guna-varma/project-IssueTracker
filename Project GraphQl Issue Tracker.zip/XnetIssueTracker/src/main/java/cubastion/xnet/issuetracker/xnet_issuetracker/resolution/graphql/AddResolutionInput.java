package cubastion.xnet.issuetracker.xnet_issuetracker.resolution.graphql;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class AddResolutionInput {
    private Long projectId;
    private String description;
    private String iconUrl;
    private String resolutionName;
}
