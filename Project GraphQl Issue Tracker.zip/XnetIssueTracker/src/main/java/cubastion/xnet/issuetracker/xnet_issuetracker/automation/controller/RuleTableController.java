package cubastion.xnet.issuetracker.xnet_issuetracker.automation.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.RuleTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.RuleTableInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.RuleTableServiceImpl;
import jakarta.validation.Valid;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class RuleTableController {
    @Autowired
    private RuleTableServiceImpl ruleTableService;

    @MutationMapping
    private RuleTable addRuleTable(@Argument("ruleTableInput") RuleTableInput input){
        RuleTable ruleTable=new RuleTable();
        ruleTable.setName(input.getName());
        ruleTable.setConditionTableId(input.getConditionTableId());
        ruleTable.setOwnerId(input.getOwnerId());
        ruleTable.setIssueTriggerId(input.getIssueTriggerId());
        ruleTable.setPostFunctionId(input.getPostFunctionId());
        ruleTable.setDescription(input.getDescription());
        ruleTable.setActionLevel(input.getActionLevel());
        ruleTable.setCategory(input.getCategory());
        ruleTable.setConfigurationData(input.getConfigurationData());
        return ruleTableService.createRuleTable(ruleTable);
    }
    @QueryMapping
    private List<RuleTable> getAllRuleTable(){
        return ruleTableService.getAllRuleTableList();
    }

    @QueryMapping
    private RuleTable getRuleTableById(@Argument Long id){
        return ruleTableService.getRuleTableListById(id);
    }
    @MutationMapping
    private String deleteRuleTable(@Valid @Argument Long id){
        return ruleTableService.deleteRuleTableById(id);
    }
    @MutationMapping
    private RuleTable updateRuleTable(@Argument Long id,String name,Long ownerId,Long issueTriggerId,Long conditionTableId,Long postFunctionId,String description,String actionLevel, String category) throws NotFoundException {
        return ruleTableService.updateRuleTable(id,ownerId,issueTriggerId,conditionTableId,postFunctionId,description,actionLevel, category);
    }
    @QueryMapping
    private List<RuleTable> findRuleByTrigger(@Argument Long issueTriggerId){
        return ruleTableService.getRuleByTriggerId(issueTriggerId);
    }


}
