package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeDisplayName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

@Repository
@EnableJpaRepositories
public interface AttributeDisplayNameRepository extends JpaRepository<AttributeDisplayName, Long> {

    AttributeDisplayName findByAttributeDisplayName(String name);

//    AttributeDisplayName findByAttributeDisplayName(String displayName);
}