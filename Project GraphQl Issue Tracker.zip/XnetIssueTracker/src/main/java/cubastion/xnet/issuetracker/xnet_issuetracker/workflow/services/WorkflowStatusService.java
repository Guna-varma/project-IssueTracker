package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.services;

public interface WorkflowStatusService {

}
