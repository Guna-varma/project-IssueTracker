package cubastion.xnet.issuetracker.xnet_issuetracker.issues.graphql;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;


@Getter
@Setter
public class AddIssuesInput {

    Long issueTypeId;
    Long projectId;
    String summary;
    String description;

    /* Generics */

    String attributeDate1;
    Date attributeDate2;
    Date attributeDate3;
    Date attributeDate4;
    Date attributeDate5;
    Date attributeDate6;
    Date attributeDate7;
    Date attributeDate8;
    Date attributeDate9;
    Date attributeDate10;
    Date attributeDate11;
    Date attributeDate12;
    Date attributeDate13;
    Date attributeDate14;
    Date attributeDate15;
    Date attributeDate16;
    Date attributeDate17;
    Date attributeDate18;
    Date attributeDate19;
    Date attributeDate20;

    String attributeSingleLine1;
    String attributeSingleLine2;
    String attributeSingleLine3;
    String attributeSingleLine4;
    String attributeSingleLine5;
    String attributeSingleLine6;
    String attributeSingleLine7;
    String attributeSingleLine8;
    String attributeSingleLine9;
    String attributeSingleLine10;

    Integer attributeNumericField1;
    Integer attributeNumericField2;
    Integer attributeNumericField3;
    Integer attributeNumericField4;
    Integer attributeNumericField5;
    Integer attributeNumericField6;
    Integer attributeNumericField7;
    Integer attributeNumericField8;
    Integer attributeNumericField9;
    Integer attributeNumericField10;

    Float attributeNumberField1;
    Float attributeNumberField2;
    Float attributeNumberField3;
    Float attributeNumberField4;
    Float attributeNumberField5;
    Float attributeNumberField6;
    Float attributeNumberField7;
    Float attributeNumberField8;
    Float attributeNumberField9;
    Float attributeNumberField10;

    String attributeTextField1;
    String attributeTextField2;
    String attributeTextField3;
    String attributeTextField4;
    String attributeTextField5;
    String attributeTextField6;
    String attributeTextField7;
    String attributeTextField8;
    String attributeTextField9;
    String attributeTextField10;

    String attributeMultilineTextField1;
    String attributeMultilineTextField2;
    String attributeMultilineTextField3;
    String attributeMultilineTextField4;
    String attributeMultilineTextField5;
    String attributeMultilineTextField6;
    String attributeMultilineTextField7;
    String attributeMultilineTextField8;
    String attributeMultilineTextField9;
    String attributeMultilineTextField10;

    String attributeMultiLineString1;
    String attributeMultiLineString2;
    String attributeMultiLineString3;
    String attributeMultiLineString4;
    String attributeMultiLineString5;
    String attributeMultiLineString6;
    String attributeMultiLineString7;
    String attributeMultiLineString8;
    String attributeMultiLineString9;
    String attributeMultiLineString10;
//
    String attributeUserPickList1;
    String attributeUserPickList2;
    String attributeUserPickList3;
    String attributeUserPickList4;
    String attributeUserPickList5;
    String attributeUserPickList6;
    String attributeUserPickList7;
    String attributeUserPickList8;
    String attributeUserPickList9;
    String attributeUserPickList10;
//
    String attributePickList1;
    String attributePickList2;
    String attributePickList3;
    String attributePickList4;
    String attributePickList5;
    String attributePickList6;
    String attributePickList7;
    String attributePickList8;
    String attributePickList9;
    String attributePickList10;

    Date createdAt;

}