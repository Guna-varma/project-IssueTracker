package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO;

import lombok.*;

@Getter
@Setter
@Data
public class TransitionTableInput {
    private String transitionName;
    private String description;
    private Long fromStepId;
    private Long toStepId;

}
