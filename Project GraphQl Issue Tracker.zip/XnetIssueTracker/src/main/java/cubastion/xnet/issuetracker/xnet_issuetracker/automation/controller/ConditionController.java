package cubastion.xnet.issuetracker.xnet_issuetracker.automation.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.Condition;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.ConditionInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.ConditionServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ConditionController {
    @Autowired
    private ConditionServiceImpl conditionService;

    @MutationMapping
    private Condition addCondition(@Argument("conditionInput") ConditionInput input){
        Condition condition=new Condition();
        condition.setConditionName(input.getConditionName());
        condition.setDefinition(input.getDefinition());
        condition.setConditionValue(input.getConditionValue());
        return conditionService.createCondition(condition);
    }

    @QueryMapping
    private List<Condition> getAllCondition(){
        return conditionService.getAllConditionTable();
    }

    @QueryMapping
    private Condition getConditionById(@Argument Long id){
        return conditionService.getConditionById(id);

    }
    @MutationMapping
    private String deleteConditionTable(@Valid @Argument Long id){
        return conditionService.deleteConditionById(id);
    }

    @QueryMapping
    private List<Condition> getConditionsById(@Argument("idks") ArrayList<Long> idks){
        return conditionService.getConditionByIds(idks);
    }

}
