package cubastion.xnet.issuetracker.xnet_issuetracker.project.graphql;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProjectDto {

    private Long id;

    private String projectName;
    private String url;
    private String projectLead;
    private String projectDescription;
    private String projectKey;
    private long assigneeType;

}
