package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.ServiceImpl.DataTypeServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.DataTypeInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.DataTypeRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DataTypeInfoService implements DataTypeServiceImpl {

    @Autowired
    private DataTypeRepository dataTypeRepository;

    @Override
    public DataTypeInfo addDataTypeInfo(DataTypeInfo dataTypeInfo) {
        return dataTypeRepository.save(dataTypeInfo);
    }

    @Override
    public List<DataTypeInfo> getAllDataTypeInfo() {

        List<DataTypeInfo> dataTypeInfoList = null;
        try {
            dataTypeInfoList = dataTypeRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (dataTypeInfoList.isEmpty())
            throw new xNetNotFoundException("DataTypeInfo List is Null");
        return dataTypeInfoList;

    }

    @Override
    public Optional<DataTypeInfo> getById(Long id) {
        return Optional.ofNullable(dataTypeRepository.findById(id).orElseThrow(
                () -> new xNetNotFoundException("DataTypeInfo with ID: " + String.valueOf(id) + " is not found")
        ));
    }
}
