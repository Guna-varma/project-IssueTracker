package cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "postFunction")
public class PostFunction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "postFunctionKey",nullable = false)
    private String postFunctionKey;

    @Column(name = "description")
    private String description;

    @OneToMany(mappedBy = "postFunctions", cascade = CascadeType.ALL)
    private List<RuleTable> ruleTables;
}
