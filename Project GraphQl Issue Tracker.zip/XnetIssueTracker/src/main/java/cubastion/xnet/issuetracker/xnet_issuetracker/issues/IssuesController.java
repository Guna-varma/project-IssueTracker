package cubastion.xnet.issuetracker.xnet_issuetracker.issues;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeDisplayNameRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.graphql.IssuseDTOcollection;

import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses.IssuesPaginationResponse;
import org.springframework.data.domain.Page;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class IssuesController {

    @Autowired
    private IssuesService service;

    @Autowired
    private IssuesRepository repo;

    @Autowired
    private AttributeDisplayNameRepository attributeDisplayNameRepository;

    @MutationMapping
    private Issues addIssues(@Argument("addIssuesInput") IssuseDTOcollection input) {
        Issues issues = service.dtoToIssuseData(input);
        return service.add(issues);
    }

    @QueryMapping
    private List<Issues> getAllIssues() {
        return service.getAll();
    }

    @QueryMapping
    private Optional<Issues> getIssuesById(@Argument Long id) {
        return service.getIssuesById(id);
    }

    @MutationMapping
    private String deleteIssues(@Argument Long id) {
        return service.deleteIssues(id);
    }

    @MutationMapping
    private Issues updateIssues(@Argument Long id, @Argument("updateIssuesInput") IssuseDTOcollection input) {
        Issues issues = service.dtoToIssuseData(input);
        return service.update(id, issues);
    }

    @QueryMapping
    public List<Issues> issuesWithFilter(@Argument("filter") FilterKey filter) {
        return service.issuesWithFilter(filter);
    }

    @QueryMapping
    public List<Issues> issuesJoinFilter(@Argument("filter") RequestDto requestDto){
        return service.issuesJoinFilter(requestDto);
    }

    @QueryMapping
    public List<Issues> issuesMultiJoinFilter(@Argument("filter") RequestDto requestDto){
        return service.issuesMultiJoinFilter(requestDto);
    }

    @QueryMapping
    public List<Issues> issueJunctionTableFilter(@Argument("filter") RequestDto requestDto){
        return service.issueJunctionTableFilter(requestDto);
    }


    @QueryMapping
    public Page<Issues> issuesPage(@Argument(name = "page") Integer pageNumber, @Argument(name = "offset") Integer pageSize) {
        return service.issuesPage(pageNumber, pageSize);
    }

    @QueryMapping
    public IssuesPaginationResponse<List<Issues>> issuesPagination(@Argument(name = "page") Integer pageNumber, @Argument(name = "offset") Integer offset) {
        return service.issuesPagination(pageNumber, offset);
    }

}