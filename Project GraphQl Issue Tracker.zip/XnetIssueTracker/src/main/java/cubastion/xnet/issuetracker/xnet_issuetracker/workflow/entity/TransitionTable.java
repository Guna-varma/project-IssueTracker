package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "transitionTable")
public class TransitionTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name = "transitionName",nullable = false)
    private String transitionName;

    @Column(name = "description")
    private String description;


    //TODO : Need to check mapping
    @Column(name = "fromStepId",nullable = false)
    private Long fromStepId;

    //TODO : Need to check mapping
    @Column(name = "toStepId",nullable = false)
    private Long toStepId;

}