package cubastion.xnet.issuetracker.xnet_issuetracker.template;

import java.util.List;
import java.util.Optional;

public interface TemplateServiceImpL {

    Template addTemplate(Template template);

    List<Template> getAll();

    Optional<Template> getTemplateById(Long id);

}


