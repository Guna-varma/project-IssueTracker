package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.utils;

public class KEYS {

    public final static String DATE_FORMAT= "YYYY-MM-dd";

}
