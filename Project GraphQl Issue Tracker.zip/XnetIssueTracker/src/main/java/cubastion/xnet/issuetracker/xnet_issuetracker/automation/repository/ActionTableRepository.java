package cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionLevel;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActionTableRepository extends JpaRepository<ActionTable, Long> {
}
