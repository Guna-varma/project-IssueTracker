package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.graphqlDTO.WorkflowStatusInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.serviceImpl.WorkflowStatusServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class WorkflowStatusController {
    @Autowired
    WorkflowStatusServiceImpl workflowStatusService;


    @MutationMapping
    private WorkflowStatus addWorkFlowStatus(@Argument("workflowStatusInput") WorkflowStatusInput input){
            WorkflowStatus workflowStatus=new WorkflowStatus();
            workflowStatus.setName(input.getName());
            workflowStatus.setDescription(input.getDescription());
            return workflowStatusService.createWorkflowStatus(workflowStatus);
    }
    @QueryMapping
    private List<WorkflowStatus> getAllWorkflowStatus(){
        return workflowStatusService.getAllStatus();
    }

    @QueryMapping
    private WorkflowStatus getWorkflowStatusById(@Argument Long id){
        try {
            return workflowStatusService.getWorkflowStatusById(id);
        }
        catch (Exception e){
            throw new xNetInvalidInputException("WorkflowTable Id is Invalid, Please fill the correct Id");
        }

    }
}
