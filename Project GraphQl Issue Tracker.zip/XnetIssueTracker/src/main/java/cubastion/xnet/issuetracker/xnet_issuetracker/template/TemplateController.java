package cubastion.xnet.issuetracker.xnet_issuetracker.template;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.template.graphqlDTO.IssueTypeInTemplateDTO;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
public class TemplateController {

    @Autowired
    private TemplateService service;

    @Autowired
    private TemplateRepository repo;


    @MutationMapping
    private Template addTemplate(@Argument("addTemplateInput") AddTemplateInput addTemplateInput){
            if (addTemplateInput.getWorkflowId()>0){
            Template t = new Template();
            t.setName(addTemplateInput.getName());
            t.setDescription(addTemplateInput.getDescription());
            t.setWorkflowId(addTemplateInput.getWorkflowId());
            return service.addTemplate(t);
            }else {
                throw new xNetInvalidInputException("Please enter valid WorkflowId");
            }
    }

    @MutationMapping
    private List<IssuetypeInTemplate> addIssuetypeInTemplate(@Argument IssueTypeInTemplateDTO inTemplateDTO){

        return service.addIssueTypeInTemplate(inTemplateDTO);
    }

    @QueryMapping
    private List<IssuetypeInTemplate> getAllgetAllIssuetypeInTemplate(){
        return service.getAllIssuetypeInTemplate();
    }

    @QueryMapping
    private List<Template> getAllTemplate(){
        return service.getAll();
    }

    @QueryMapping
    private Optional<Template> getById(@Argument Long id){
            return service.getTemplateById(id);

    }

    @PutMapping("/update")
    private Template update(@RequestBody Template entity){
        return service.update(entity);
    }

    @DeleteMapping("/delete/{id}")
    private String delete(@RequestParam Long id){
        return service.delete(id);
    }

}

@Getter
@Setter
class AddTemplateInput{
    Long id;
    String name;
    String description;
    Long workflowId;
}
