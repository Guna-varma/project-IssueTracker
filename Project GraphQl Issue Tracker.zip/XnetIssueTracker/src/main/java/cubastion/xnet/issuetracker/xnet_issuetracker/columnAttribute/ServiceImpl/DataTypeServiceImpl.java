package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.ServiceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.DataTypeInfo;

import java.util.List;
import java.util.Optional;

public interface DataTypeServiceImpl {

    DataTypeInfo addDataTypeInfo(DataTypeInfo dataTypeInfo);

    List<DataTypeInfo> getAllDataTypeInfo();

    Optional<DataTypeInfo> getById(Long id);
}
