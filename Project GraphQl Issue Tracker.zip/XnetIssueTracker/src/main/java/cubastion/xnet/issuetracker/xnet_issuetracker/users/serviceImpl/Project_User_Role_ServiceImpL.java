package cubastion.xnet.issuetracker.xnet_issuetracker.users.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;

import java.util.List;
import java.util.Optional;

public interface Project_User_Role_ServiceImpL {

    PROJECT_USER_ROLES_TABLE addProjectUserRoles(PROJECT_USER_ROLES_TABLE project_user_roles_table);

    List<PROJECT_USER_ROLES_TABLE> getAllProjectUserRoles();

    Optional<PROJECT_USER_ROLES_TABLE> getProjectUserById(Long id);

}
