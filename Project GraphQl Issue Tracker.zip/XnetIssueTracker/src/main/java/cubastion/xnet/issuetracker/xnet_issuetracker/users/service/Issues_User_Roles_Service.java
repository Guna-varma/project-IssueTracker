package cubastion.xnet.issuetracker.xnet_issuetracker.users.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.Issues_User_Roles_Repo;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.serviceImpl.Issue_User_Role_ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class Issues_User_Roles_Service implements Issue_User_Role_ServiceImpl {
    @Autowired
    private Issues_User_Roles_Repo repo;
    @Override
    public ISSUE_USER_ROLES_TABLE addIssueUserRoles(ISSUE_USER_ROLES_TABLE userRolesTable) {
        try {
            return repo.save(userRolesTable);
        } catch (Exception e) {
            throw new xNetInvalidInputException("Failed to create User: Please add Input fields!");
        }
    }
    @Override
    public List<ISSUE_USER_ROLES_TABLE> getAllIssueUserRoles() {
        List<ISSUE_USER_ROLES_TABLE> userRoles = null;
        try {
            userRoles = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (userRoles.isEmpty())
            throw new xNetNotFoundException("PROJECT_USER_ROLES_TABLE List is Null");
        return userRoles;
    }
    @Override
    public Optional<ISSUE_USER_ROLES_TABLE> getIssueUserRolesById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("PROJECT_USER_ROLES_TABLE with ID: " + String.valueOf(id) + " is not found")
        ));
    }
}
