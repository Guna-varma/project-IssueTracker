package cubastion.xnet.issuetracker.xnet_issuetracker.issues;

import com.fasterxml.jackson.annotation.JsonIgnore;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.RuleTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.utils.KEYS;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueType;
import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import cubastion.xnet.issuetracker.xnet_issuetracker.workflow.entity.WorkflowTable;
import jakarta.persistence.*;
import lombok.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "issues")
public class Issues {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "issueTypeId", nullable = false)
    private Long issueTypeId;

    @Column(name = "projectId", nullable = false)
    private Long projectId;

    @Column(name = "summary", nullable = false)
    private String summary;

    @Column(name = "description", nullable = false)
    private String description;

    @Column(name = "reporter")
    private String reporter;

    @Column(name = "assignee")
    private String assignee;

    @Column(name = "priority")
    private String priority;

    @Column(name = "resolution")
    private String resolution;

    @Column(name = "issueStatus")
    private String issueStatus;

    @Column(name = "createdAt", nullable = false, updatable = false)
    @CreationTimestamp
    private Date createdAt;

    @Column(name = "updatedAt", nullable = false)
    @UpdateTimestamp
    private Date updatedAt;

    @Column(name = "votes")
    private Long votes;

    @Column(name = "watches")
    private Long watches;

    @Column(name = "workflowId")
    private Long workflowId;

    @ManyToOne
    @JoinColumn(name = "workflowId", insertable = false, updatable = false)
    private WorkflowTable workflowTable;

    @OneToMany(mappedBy = "issues", cascade = CascadeType.ALL)
    private List<ActionTable> actionTables;

    @OneToMany(mappedBy = "issues", cascade = CascadeType.ALL)
    private List<ISSUE_USER_ROLES_TABLE> issue_user_roles_table;

//    @ManyToOne
//    @Fetch(FetchMode.JOIN)
//    @Getter(AccessLevel.NONE)
//    @Setter(AccessLevel.NONE)
//    @JoinColumn(name = "assignee",insertable = false,updatable = false)
//    private User user;
//
//    @ManyToOne
//    @JoinColumn(name = "reporter", insertable = false, updatable = false)
//    @Getter(AccessLevel.NONE)
//    @Setter(AccessLevel.NONE)
//    private User user;

    @ManyToOne
    @JoinColumn(name = "issueTypeId", insertable = false, updatable = false)
    @Fetch(FetchMode.JOIN)
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private IssueType issueType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projectId", insertable = false, updatable = false)
    private Project project;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate1")
    private Date attributeDate1;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate2")
    private Date attributeDate2;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate3")
    private Date attributeDate3;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate4")
    private Date attributeDate4;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate5")
    private Date attributeDate5;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate6")
    private Date attributeDate6;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate7")
    private Date attributeDate7;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate8")
    private Date attributeDate8;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate9")
    private Date attributeDate9;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate10")
    private Date attributeDate10;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate11")
    private Date attributeDate11;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate12")
    private Date attributeDate12;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate13")
    private Date attributeDate13;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate14")
    private Date attributeDate14;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate15")
    private Date attributeDate15;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate16")
    private Date attributeDate16;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate17")
    private Date attributeDate17;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate18")
    private Date attributeDate18;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate19")
    private Date attributeDate19;

    @DateTimeFormat(pattern = KEYS.DATE_FORMAT)
    @Column(name = "attributeDate20")
    private Date attributeDate20;

    @Column(name = "attributeSingleLine1", columnDefinition = "TEXT")
    private String attributeSingleLine1;

    public String getAttributeSingleLine1() {
        return attributeSingleLine1;
    }

    public String setAttributeSingleLine1() {
        return attributeSingleLine1;
    }

    public void setAttributeSingleLine1(String attributeSingleLine1) {
        this.attributeSingleLine1 = attributeSingleLine1;
    }

    @Column(name = "attributeSingleLine2", columnDefinition = "TEXT")
    private String attributeSingleLine2;

    @Column(name = "attributeSingleLine3", columnDefinition = "TEXT")
    private String attributeSingleLine3;

    @Column(name = "attributeSingleLine4", columnDefinition = "TEXT")
    private String attributeSingleLine4;

    @Column(name = "attributeSingleLine5", columnDefinition = "TEXT")
    private String attributeSingleLine5;

    @Column(name = "attributeSingleLine6", columnDefinition = "TEXT")
    private String attributeSingleLine6;

    @Column(name = "attributeSingleLine7", columnDefinition = "TEXT")
    private String attributeSingleLine7;

    @Column(name = "attributeSingleLine8", columnDefinition = "TEXT")
    private String attributeSingleLine8;

    @Column(name = "attributeSingleLine9", columnDefinition = "TEXT")
    private String attributeSingleLine9;

    @Column(name = "attributeSingleLine10", columnDefinition = "TEXT")
    private String attributeSingleLine10;

    @Column(name = "attributeNumericField1")
    private Integer attributeNumericField1;

    @Column(name = "attributeNumericField2")
    private Integer attributeNumericField2;

    @Column(name = "attributeNumericField3")
    private Integer attributeNumericField3;

    @Column(name = "attributeNumericField4")
    private Integer attributeNumericField4;

    @Column(name = "attributeNumericField5")
    private Integer attributeNumericField5;

    @Column(name = "attributeNumericField6")
    private Integer attributeNumericField6;

    @Column(name = "attributeNumericField7")
    private Integer attributeNumericField7;

    @Column(name = "attributeNumericField8")
    private Integer attributeNumericField8;

    @Column(name = "attributeNumericField9")
    private Integer attributeNumericField9;

    @Column(name = "attributeNumericField10")
    private Integer attributeNumericField10;

    @Column(name = "attributeNumberField1")
    private Float attributeNumberField1;

    @Column(name = "attributeNumberField2")
    private Float attributeNumberField2;

    @Column(name = "attributeNumberField3")
    private Float attributeNumberField3;

    @Column(name = "attributeNumberField4")
    private Float attributeNumberField4;

    @Column(name = "attributeNumberField5")
    private Float attributeNumberField5;

    @Column(name = "attributeNumberField6")
    private Float attributeNumberField6;


    @Column(name = "attributeNumberField7")
    private Float attributeNumberField7;

    @Column(name = "attributeNumberField8")
    private Float attributeNumberField8;

    @Column(name = "attributeNumberField9")
    private Float attributeNumberField9;

    @Column(name = "attributeNumberField10")
    private Float attributeNumberField10;

    @Column(name = "attributeTextField1")
    private String attributeTextField1;

    @Column(name = "attributeTextField2")
    private String attributeTextField2;

    @Column(name = "attributeTextField3")
    private String attributeTextField3;

    @Column(name = "attributeTextField4")
    private String attributeTextField4;

    @Column(name = "attributeTextField5")
    private String attributeTextField5;

    @Column(name = "attributeTextField6")
    private String attributeTextField6;

    @Column(name = "attributeTextField7")
    private String attributeTextField7;

    @Column(name = "attributeTextField8")
    private String attributeTextField8;

    @Column(name = "attributeTextField9")
    private String attributeTextField9;

    @Column(name = "attributeTextField10")
    private String attributeTextField10;

    @Column(name = "attributeMultilineTextField1", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField1;

    @Column(name = "attributeMultilineTextField2", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField2;

    @Column(name = "attributeMultilineTextField3", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField3;

    @Column(name = "attributeMultilineTextField4", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField4;

    @Column(name = "attributeMultilineTextField5", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField5;

    @Column(name = "attributeMultilineTextField6", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField6;

    @Column(name = "attributeMultilineTextField7", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField7;

    @Column(name = "attributeMultilineTextField8", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField8;

    @Column(name = "attributeMultilineTextField9", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField9;

    @Column(name = "attributeMultilineTextField10", columnDefinition = "MEDIUMTEXT")
    private String attributeMultilineTextField10;

    @Column(name = "attributeMultiLineString1", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString1;

    @Column(name = "attributeMultiLineString2", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString2;

    @Column(name = "attributeMultiLineString3", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString3;

    @Column(name = "attributeMultiLineString4", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString4;

    @Column(name = "attributeMultiLineString5", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString5;

    @Column(name = "attributeMultiLineString6", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString6;

    @Column(name = "attributeMultiLineString7", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString7;

    @Column(name = "attributeMultiLineString8", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString8;

    @Column(name = "attributeMultiLineString9", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString9;

    @Column(name = "attributeMultiLineString10", columnDefinition = "LONGTEXT")
    private String attributeMultiLineString10;

    @Column(name = "attributeUserPickList1", columnDefinition = "JSON")
    private String attributeUserPickList1;

    @Column(name = "attributeUserPickList2", columnDefinition = "JSON")
    private String attributeUserPickList2;

    @Column(name = "attributeUserPickList3", columnDefinition = "JSON")
    private String attributeUserPickList3;

    @Column(name = "attributeUserPickList4", columnDefinition = "JSON")
    private String attributeUserPickList4;

    @Column(name = "attributeUserPickList5", columnDefinition = "JSON")
    private String attributeUserPickList5;

    @Column(name = "attributeUserPickList6", columnDefinition = "JSON")
    private String attributeUserPickList6;

    @Column(name = "attributeUserPickList7", columnDefinition = "JSON")
    private String attributeUserPickList7;

    @Column(name = "attributeUserPickList8", columnDefinition = "JSON")
    private String attributeUserPickList8;

    @Column(name = "attributeUserPickList9", columnDefinition = "JSON")
    private String attributeUserPickList9;

    @Column(name = "attributeUserPickList10", columnDefinition = "JSON")
    private String attributeUserPickList10;

    @Column(name = "attributePickList1", columnDefinition = "JSON")
    private String attributePickList1;

    @Column(name = "attributePickList2", columnDefinition = "JSON")
    private String attributePickList2;

    @Column(name = "attributePickList3", columnDefinition = "JSON")
    private String attributePickList3;

    @Column(name = "attributePickList4", columnDefinition = "JSON")
    private String attributePickList4;

    @Column(name = "attributePickList5", columnDefinition = "JSON")
    private String attributePickList5;

    @Column(name = "attributePickList6", columnDefinition = "JSON")
    private String attributePickList6;

    @Column(name = "attributePickList7", columnDefinition = "JSON")
    private String attributePickList7;

    @Column(name = "attributePickList8", columnDefinition = "JSON")
    private String attributePickList8;

    @Column(name = "attributePickList9", columnDefinition = "JSON")
    private String attributePickList9;

    @Column(name = "attributePickList10", columnDefinition = "JSON")
    private String attributePickList10;



    @PrePersist
    private void dataPostLoad(){

        System.out.println("************************************************************************  test test test");
    }

}