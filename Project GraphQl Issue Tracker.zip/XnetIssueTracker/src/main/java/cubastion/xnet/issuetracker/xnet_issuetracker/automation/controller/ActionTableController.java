package cubastion.xnet.issuetracker.xnet_issuetracker.automation.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionLevel;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionTable;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.ActionLevelInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.graphqlDto.ActionTableInput;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl.ActionTableServiceImpl;
import jakarta.validation.Valid;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class ActionTableController {
    @Autowired
    private ActionTableServiceImpl actionTableService;

    @MutationMapping
    private ActionTable addActionTable(@Argument("actionTableInput") ActionTableInput input) {
        ActionTable actionTable=new ActionTable();
        actionTable.setIssueId(input.getIssueId());
        actionTable.setActionLevel(input.getActionLevel());
        actionTable.setAuthor(input.getAuthor());
        actionTable.setActionType(input.getActionType());
        actionTable.setActionBody(input.getActionBody());
        actionTable.setActionNumber(input.getActionNumber());
        actionTable.setRoleLevel(input.getRoleLevel());
        return actionTableService.createActionTable(actionTable) ;
    }
    @MutationMapping
    private String deleteActionTable(@Valid @Argument Long id){
        return actionTableService.deleteActionTableById(id);
    }
    @MutationMapping
    private ActionTable updateActionTable(@Argument Long id,Long issueId,String author,String actionType, String actionLevel,String roleLevel,String actionBody,Long actionNumber) throws NotFoundException {
    //private ActionTable updateActionTable(@Argument Long id,@Argument("updateIssuesInput")ActionTableInput input){
        //ActionTable actionTable=actionTableService.
        //return actionTableService update(id,input);
        return actionTableService.update(id,issueId,author,actionType,actionLevel,roleLevel,actionBody,actionNumber);
    }

    @QueryMapping
    private List<ActionTable> getAllActionTable(){
        return actionTableService.getAllActions();
    }
    @QueryMapping
    private ActionTable getActionTableById(@Argument Long id ){
        return actionTableService.getActionById(id);
    }
}
