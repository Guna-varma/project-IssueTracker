package cubastion.xnet.issuetracker.xnet_issuetracker.workflow.utitlity;

public final class QUERIES {

    public static final String WORKFLOWSTATUS_TABLE = "workflowStatus";

    public static final String WORKFLOWSTEP_TABLE = "workflowStepTable";


    public static final String Status_Name_By_WorkflowId="Select "+
            " workflowStatus_table.id, workflowStatus_table.name, workflowStatus_table.description "+
            " from " + WORKFLOWSTATUS_TABLE + " as workflowStatus_table"+
            " JOIN "+ WORKFLOWSTEP_TABLE+ " as workflowStepTable_table " +
            "ON workflowStatus_table.id=workflowStepTable_table.linkedStatusId " +
            "where workflowStepTable_table.workflowTableId=:workflowTableId";
}
