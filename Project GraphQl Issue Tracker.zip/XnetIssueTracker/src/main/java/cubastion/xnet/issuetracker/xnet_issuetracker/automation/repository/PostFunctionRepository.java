package cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.PostFunction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PostFunctionRepository extends JpaRepository<PostFunction, Long> {
}
