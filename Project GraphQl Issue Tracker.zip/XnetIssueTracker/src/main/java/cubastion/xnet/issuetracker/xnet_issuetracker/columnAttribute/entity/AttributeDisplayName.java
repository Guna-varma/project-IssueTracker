package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.Date;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "attributeDisplayName")
public class AttributeDisplayName {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "issueTypeId",nullable = false)
    private Long issueTypeId;

    @Column(name = "attributeDisplayName")
    private String attributeDisplayName;

    @Column(name = "dataTypeInfoId",nullable = false)
    private Long dataTypeInfoId;

    @Column(name = "attributeKey",nullable = false,unique = true)
    private String attributeKey;

//    @ManyToOne
//    @Getter(AccessLevel.NONE)
//    @Setter(AccessLevel.NONE)
//    @JoinColumn(name = "attributeKey", insertable = false, updatable = false)
//    private AttributeColumnNameInfo attrColumn;

    public AttributeDisplayName(Long issueTypeId, String attributeDisplayName, Long dataTypeInfoId, String attributeKey) {
        this.issueTypeId = issueTypeId;
        this.attributeDisplayName = attributeDisplayName;
        this.dataTypeInfoId = dataTypeInfoId;
        this.attributeKey = attributeKey;
    }

}