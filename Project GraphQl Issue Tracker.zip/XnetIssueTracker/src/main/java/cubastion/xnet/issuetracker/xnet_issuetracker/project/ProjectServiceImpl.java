package cubastion.xnet.issuetracker.xnet_issuetracker.project;

import java.util.List;

public interface ProjectServiceImpl {


    Project addProject(Project project);

    List<Project> getAll();

    Project getProjectById(Long id);

    Project update(Project project);

    List<Project> findProjectsWithPredicate();
}
