package cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateUserInput {
    private Long id;

    private String userName;

    private String fullName;

    private String password;

    private String email;

    private Boolean active;
}
