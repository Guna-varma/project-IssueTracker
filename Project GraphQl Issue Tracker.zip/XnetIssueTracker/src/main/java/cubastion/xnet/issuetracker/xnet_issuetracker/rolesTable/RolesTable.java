package cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.ISSUE_USER_ROLES_TABLE;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "rolesTable")
public class RolesTable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @NotBlank
    @Column(name = "name",nullable = false)
    private String name;

    public RolesTable(String name) {
        this.name = name;
    }

    @OneToMany(mappedBy = "rolesTable",cascade = CascadeType.ALL)
    private List<ISSUE_USER_ROLES_TABLE> issue_user_roles_table;

    @OneToMany(mappedBy = "rolesTable",cascade = CascadeType.ALL)
    private List<PROJECT_USER_ROLES_TABLE> project_user_roles_table;
}
