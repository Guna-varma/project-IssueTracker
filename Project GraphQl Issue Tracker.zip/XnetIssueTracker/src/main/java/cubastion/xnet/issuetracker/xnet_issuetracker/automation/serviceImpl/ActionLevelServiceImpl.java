package cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.ActionLevel;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.ActionLevelRepository;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.service.ActionLevelService;

import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ActionLevelServiceImpl implements ActionLevelService {
    @Autowired
    private ActionLevelRepository actionLevelRepository;

    public ActionLevel createActionLevel(ActionLevel actionLevel) {
        return actionLevelRepository.save(actionLevel);
    }

    public List<ActionLevel> getAllActionLevel() {
        return actionLevelRepository.findAll();
    }

    public ActionLevel getActionLevelById(Long id) {
        return actionLevelRepository.findById(id).orElseThrow();
    }

    public String deletePriorityById(Long id) {
        actionLevelRepository.deleteById(id);
        return "Priority Id: " + id + " Deleted Successfully!!";
    }


    public ActionLevel updateAction(Long id, String levelName) throws NotFoundException {
        Optional<ActionLevel> actionLevel = actionLevelRepository.findById(id);
        if (actionLevel.isPresent()) {
            ActionLevel actionLevel1 = actionLevel.get();
            if (levelName != null)
                actionLevel1.setLevelName(levelName);
            actionLevelRepository.save(actionLevel1);
            return actionLevel1;

        }
        throw new NotFoundException("Not found ActionLevel to update!");
    }



}
