package cubastion.xnet.issuetracker.xnet_issuetracker.priority;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.issueType.IssueType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class PriorityService implements PriorityServiceImpL {

    @Autowired
    private PriorityRepository repo;

    @Override
    public Priority addPriority(Priority priority) {
        try{
            return repo.save(priority);
        }
        catch (Exception e){
            throw new xNetInvalidInputException("Failed to create Priority: Please add Input fields!");
        }
    }

    @Override
    public List<Priority> getAllPriority() {
        List<Priority> priorityList = null;
        try{
            priorityList = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (priorityList.isEmpty())
            throw new xNetNotFoundException("priority List is Null");
        return priorityList;
    }

    @Override
    public Optional<Priority> getPriorityById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("Priority with ID: " + String.valueOf(id) + " is not found, please enter correct Id")
        ));
    }

    @Override
    public Priority updatePriority(Priority priority) {
        return null;
    }

    public String deletePriorityById(Long id) {
        repo.deleteById(id);
        return "Priority Id: "+id+" Deleted Successfully!!";
    }

}
