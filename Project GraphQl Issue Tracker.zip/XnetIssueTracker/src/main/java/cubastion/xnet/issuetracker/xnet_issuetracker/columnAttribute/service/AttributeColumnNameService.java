package cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.service;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.ServiceImpl.AttributeColumnServiceImpl;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.entity.AttributeColumnNameInfo;
import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.AttributeColumnNameInfoRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.resolution.Resolution;
import cubastion.xnet.issuetracker.xnet_issuetracker.template.Template;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class AttributeColumnNameService implements AttributeColumnServiceImpl {

    @Autowired
    AttributeColumnNameInfoRepository attributeColumnNameInfoRepository;

    @Override
    public AttributeColumnNameInfo addAttributeColumnNameInfo(AttributeColumnNameInfo attributeColumnNameInfo) {

        List<AttributeColumnNameInfo> list = null;
        try{
            list = attributeColumnNameInfoRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (list.isEmpty())
            throw new xNetNotFoundException("AttributeColumnNameInfo List is Null");
        return (AttributeColumnNameInfo) list;

    }

    @Override
    public List<AttributeColumnNameInfo> getAllAttributeColumnName() {
        List<AttributeColumnNameInfo> attrList = null;
        try{
            attrList = attributeColumnNameInfoRepository.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (attrList.isEmpty())
            throw new xNetNotFoundException("AttributeColumnNameInfo List is Null");
        return attrList;
    }

    @Override
    public Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoByDataTypeInfoId(Long id) {
        return Optional.ofNullable(attributeColumnNameInfoRepository.findById(id).orElseThrow(
                () -> new xNetNotFoundException("AttributeColumnNameInfo with ID: " + String.valueOf(id) + " is not found")
        ));
    }

    @Override
    public Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoById(Long id) {
        return Optional.ofNullable(attributeColumnNameInfoRepository.findById(id).orElseThrow(
                () -> new xNetNotFoundException("AttributeColumnNameInfo with ID: " + String.valueOf(id) + " is not found")
        ));
    }

    @Override
    public Optional<AttributeColumnNameInfo> getAttributeColumnNameInfoByKeyId(String attributeKey) {
        if (attributeColumnNameInfoRepository.findByAttributeKey(attributeKey) == null){
            throw new xNetNotFoundException("AttributeColumnNameInfo with Attribute Key: " + attributeKey + " is not found");
        }
        return Optional.ofNullable(attributeColumnNameInfoRepository.findByAttributeKey(attributeKey));
    }
}
