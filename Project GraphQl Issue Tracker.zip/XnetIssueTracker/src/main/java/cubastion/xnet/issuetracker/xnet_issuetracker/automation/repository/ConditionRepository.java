package cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.Condition;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConditionRepository extends JpaRepository<Condition, Long>, JpaSpecificationExecutor<Condition> {
//    List<Long> getIdsByTwoColumns(List<String> conditionNames, List<String> definitions);
//
//    List<Long> getIdsByConditionAndDefinition(List<String> conditionNames, List<String> definitions);
}
