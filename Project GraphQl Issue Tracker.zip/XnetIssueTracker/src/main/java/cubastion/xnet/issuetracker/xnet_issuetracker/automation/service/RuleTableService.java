package cubastion.xnet.issuetracker.xnet_issuetracker.automation.service;

public interface RuleTableService {
}
