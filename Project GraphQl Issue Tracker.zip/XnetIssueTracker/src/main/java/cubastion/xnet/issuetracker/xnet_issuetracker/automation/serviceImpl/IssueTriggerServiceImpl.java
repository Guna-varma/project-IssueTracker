package cubastion.xnet.issuetracker.xnet_issuetracker.automation.serviceImpl;

import cubastion.xnet.issuetracker.xnet_issuetracker.automation.entity.IssueTrigger;
import cubastion.xnet.issuetracker.xnet_issuetracker.automation.repository.IssueTriggerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IssueTriggerServiceImpl {
    @Autowired
    private IssueTriggerRepository issueTriggerRepository;
    public IssueTrigger createIssueTrigger(IssueTrigger issueTrigger) {
        return issueTriggerRepository.save(issueTrigger);
    }

    public List<IssueTrigger> getAllIssueTrigger() {
        return issueTriggerRepository.findAll();
    }

    public IssueTrigger getIssueTriggerById(Long id) {
        return issueTriggerRepository.findById(id).orElseThrow();
    }

    public String deleteIssueTriggerById(Long id) {
        issueTriggerRepository.deleteById(id);
        return "Priority Id: "+id+" Deleted Successfully!!";
    }

    public List<IssueTrigger> getTriggerIdByName(String name) {
       return issueTriggerRepository.findAll(getTrigger(name));
    }



    public Specification<IssueTrigger> getTrigger(String data){
        return ((root, query, criteriaBuilder) -> criteriaBuilder.like(root.get("name"),"%" + data + "%"));
    }
}
