package cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddProjectUserRolesInput {
    private Long userId;
    private Long projectId;
    private Long roleId;

}
