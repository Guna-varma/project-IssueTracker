package cubastion.xnet.issuetracker.xnet_issuetracker.resolution;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.project.Project;
import lombok.AllArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ResolutionService implements ResolutionServieImpL{

    @Autowired
    private ResolutionRepository repo;

    @Override

    public Resolution addResolution(Resolution resolution) {
        try{
            return repo.save(resolution);
        }catch (Exception e){
            throw new xNetInvalidInputException("Failed to create Resolution: Please add Input fields!");
        }

    }

    @Override
    public List<Resolution> getAllResolution() {
        List<Resolution> resolutions = null;
        try{
            resolutions = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (resolutions.isEmpty())
            throw new xNetNotFoundException("Resolutions List is Null");
        return resolutions;
    }

    @Override
    public Optional<Resolution> getResolutionById(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("Resolution with ID: " + String.valueOf(id) + " is not found")
        ));
    }

    @Override
    public Resolution updateResolution(Resolution resolution) {

        Resolution r = repo.findById(resolution.getId()).orElseThrow(() -> new xNetNotFoundException("Resolution Not found"));

        if(resolution.getProjectId()!=null){
            r.setProjectId(resolution.getProjectId());
        }
        if(resolution.getDescription()!=null){
            r.setDescription(resolution.getDescription());
        }
        if(resolution.getIconUrl()!=null){
            r.setIconUrl(resolution.getIconUrl());
        }
        return repo.save(r);
    }
}