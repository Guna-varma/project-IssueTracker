package cubastion.xnet.issuetracker.xnet_issuetracker.issues.graphql;

import lombok.Data;

import java.util.ArrayList;
@Data
public class IssuseDTOcollection {

    ArrayList<IssuseDto> issuseDtoArrayList;
}
