package cubastion.xnet.issuetracker.xnet_issuetracker.users.repo;

import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.PROJECT_USER_ROLES_TABLE;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Project_User_Roles_Repo extends JpaRepository<PROJECT_USER_ROLES_TABLE, Long> {
}
