package cubastion.xnet.issuetracker.xnet_issuetracker.utils;

import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.UserPage;

public class GarbageCollections {

//          ISSUE_USER_ROLES_TABLE issuesUserRoles = new ISSUE_USER_ROLES_TABLE();
//          issuesUserRoles.setIssues(issues);
//          issuesUserRoles.setIssue_id(issues.getId());


    /*

        Specification<Issues> spec =(root, query, builder) -> {
        Predicate e1 = builder.equal(root.get(columnName), "%" + columnValue + "%");
        Predicate  e2 = builder.equal(root.get("id"), id);
        return builder.and(e1,e2);
    };
    return repo.exists(spec);

    */

//    Automation create Issue Assignee
    /*
    try{
            DataSource dataSource = jdbcTemplate.getDataSource();
            Connection con = DataSourceUtils.getConnection(dataSource);
            Statement s = con.createStatement();
            String sql = "SELECT * FROM issues where "+columnName+ " = '"+columnValue+"' AND id = "+id+";";
            PreparedStatement preStmt = con.prepareStatement(sql);
            ResultSet rs = preStmt.executeQuery(sql);
            {
                rs.next();
//                System.out.println(rs.get(Boolean.class));
            }
            JdbcUtils.closeStatement(s);
            DataSourceUtils.releaseConnection(con, dataSource);
        } catch (SQLException e) {
            e.printStackTrace();
        }


    */
//    User Pagination
//
//            DataClass d = new DataClass();
//            d.getUserData();

//            List<User> a;
//            a = pageUser.getContent();

//            for (User u : d.getUserData()) {
//                u = (User) pageUser.getContent();
//            }
//            a = pageUser.getContent();
//            List<User> userData = pageUser.getContent();


//    User Pagination with new UserPage

    //            int totalElements = (int) pageUser.getTotalElements();
//            int totalPages = pageUser.getTotalPages();
//            int currentPage = pageUser.getNumber() + 1;
//            int totalPerPage = pageable.getPageSize();
//            int nextPage = pageUser.getNumber() + 2;
//            int previousPage = pageUser.getNumber();

//    UserPage userPageResponse = new UserPage();
//
//            userPageResponse.setData(userData);
//            userPageResponse.setTotalRecords(totalElements);
//            userPageResponse.setTotalPage(totalPages);
//            userPageResponse.setCurrentPage(currentPage);
//            userPageResponse.setTotalPerPage(totalPerPage);
//            userPageResponse.setNextPage(nextPage);
//            userPageResponse.setPreviousPage(previousPage);


// delete from UserController

//            if(filter.getId()!=null)
//                spec = (spec == null ? getSpecification(filter.getId(),ID) : filter.getOperand().equals("AND")?
//                        spec.and(getSpecification(filter.getId(),ID)) : filter.getOperand().equals("OR")?spec.or(getSpecification(filter.getId(),ID)): null);
//            if (filter.getUserName() != null)
//                spec = (spec == null ? getSpecification(filter.getUserName(),USERNAME) : filter.getOperand().equals("AND")?
//                        spec.and(getSpecification(filter.getUserName(),USERNAME)) : filter.getOperand().equals("OR")?spec.or(getSpecification(filter.getUserName(),USERNAME)):null);
//            if (filter.getFullName() != null)
//                spec = (spec == null ? getSpecification(filter.getFullName(),FULLNAME) : filter.getOperand().equals("AND")?
//                        spec.and(getSpecification(filter.getFullName(),FULLNAME)) :filter.getOperand().equals("OR")? spec.or(getSpecification(filter.getFullName(),FULLNAME)):null);
//            if (filter.getEmail() != null)
//                spec = (spec == null ? getSpecification(filter.getEmail(),EMAIL) : filter.getOperand().equals("AND")?
//                        spec.and(getSpecification(filter.getEmail(),EMAIL)): filter.getOperand().equals("OR")? spec.or(getSpecification(filter.getEmail(),EMAIL)): null);


// without validation
//        for (FilterFields filterField : filter.getKey()) {
//            spec = (spec == null ? getSpecification(filterField, filterField.getKeyValue()) : filter.getPredicate().equals(AND) ?
//                    spec.and(getSpecification(filterField, filterField.getKeyValue())) : filter.getPredicate().equals(OR) ? spec.or(getSpecification(filterField, filterField.getKeyValue())) : null);
//        }

//        if (spec != null)
//            return repo.findAll(spec);
//        else
//            return (List<User>) repo.findAll();

//   UserController

/*    package cubastion.xnet.issuetracker.xnet_issuetracker.users.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterFields;

import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.ParentFilterKey;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.UserRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.service.UserService;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql.AddUserInput;

import jakarta.persistence.criteria.Predicate;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.*;

import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.KEYS.AND;
import static cubastion.xnet.issuetracker.xnet_issuetracker.utils.KEYS.OR;

    @Controller
    public class UserController {

        @Autowired
        private UserService service;

        @Autowired
        private UserRepository repo;

        @MutationMapping
        private User addUser(@Argument("addUserInput") AddUserInput addUserInput) {
            User u = new User();
            if (addUserInput.getUserName().isBlank()) {
                throw new xNetInvalidInputException("Please Enter valid UserName!");
            } else {
                u.setUserName(addUserInput.getUserName());
            }
            if (addUserInput.getFullName().isBlank()) {
                throw new xNetInvalidInputException("Please Enter valid FullName!");
            } else {
                u.setFullName(addUserInput.getFullName());
            }
            if (addUserInput.getPassword().isBlank()) {
                throw new xNetInvalidInputException("Please Enter valid Password!");
            } else {
                u.setPassword(addUserInput.getPassword());
            }
            if (addUserInput.getEmail().isBlank()) {
                throw new xNetInvalidInputException("Please Enter valid EMail Address!");
            } else {
                u.setEmail(addUserInput.getEmail());
            }

            u.setActive(addUserInput.getActive());
            return service.add(u);
        }

        @QueryMapping
        private List<User> getAllUser() {
            return service.getAll();
        }

        @QueryMapping
        private Optional<User> getUserById(@Argument Long id) {
            return service.getUserById(id);
        }

        @MutationMapping
        private User updateUser(@Argument("updateUserInput") User user) {

            return service.update(user);
        }

        @MutationMapping
        private String deleteUser(@Argument Long id) {
            service.delete(id);
            return "User Deleted Successfully!";
        }



        @QueryMapping
        public List<User> usersWithFilter(@Argument("filter") ParentFilterKey pafilter) {
            Specification<User> specP = null;
            Specification<User> spec = null;
//        Specification<User> specOR = null;
//        Specification<User> specAND = null;

            for (FilterKey filterKey: pafilter.getKeyParent()){

                for (FilterFields filterField : filterKey.getKey()) {
                    if (spec == null) {
                        spec = getSpecification(filterField, filterField.getKeyValue());
                    } else if (filterKey.getPredicate().equalsIgnoreCase(OR)) {
                        spec = spec.or(getSpecification(filterField,filterField.getKeyValue()));
                    } else if (filterKey.getPredicate().equalsIgnoreCase(AND)) {
                        spec = spec.and(getSpecification(filterField,filterField.getKeyValue()));

                    }
                    else {
                        throw new xNetNotFoundException("Predicate not found, Please Enter 'AND' (or) 'OR' Predicate..!");
                    }
                }


            }
            if (specP==null){
                if (pafilter.getPredicateParent().equals(OR)){
                    specP=specP.or(spec);
                }else if(pafilter.getPredicateParent().equals(AND)){
                    specP=specP.and(spec);
                } else {
                    specP=spec;
                }

            }



//        for (FilterFields filterField : filter.getKey()) {
//                if (spec == null) {
//                    spec = getSpecification(filterField, filterField.getKeyValue());
//                } else if (filter.getPredicate().equalsIgnoreCase(OR)) {
//                        spec = spec.or(getSpecification(filterField,filterField.getKeyValue()));
//                } else if (filter.getPredicate().equalsIgnoreCase(AND)) {
//                    spec = spec.and(getSpecification(filterField,filterField.getKeyValue()));
//                }
//                else {
//                    throw new xNetNotFoundException("Predicate not found, Please Enter 'AND' (or) 'OR' Predicate..!");
//                }
//        }

//       {
//            if((filterField.getOperator().isEmpty() | filterField.getKeyValue().isEmpty())){
//                throw new xNetInvalidInputException(" 'keyValue' or 'operator' is Empty, Please add valid Inputs..!");
//            } else {
//                return repo.findAll(spec);
//            }
//        }

            return repo.findAll(specP);
        }

        private Specification<User> getSpecification(FilterFields filterField, String key) {
            return (root, query, builder) -> filterField.generateCriteria(builder, root.get(key));
        }



        private Specification<User> getPredicates(FilterFields filterField, String key){

            Predicate pOR=getPredicates()

            return null;
        }
    }*/


    //    private Boolean sendSimpleMessage() {
//
//        List<User> usersList = (List<User>) userRepository.findAll();
//        String[] emails = new String[usersList.size()];
//
//        for (int j = 0; j < usersList.size(); j++) {
//            emails[j] = usersList.get(j).getEmail();
//        }
//
//        SimpleMailMessage message = new SimpleMailMessage();
//        message.setFrom("devxnet@cubastion.com");
//        message.setTo(emails);
//        message.setText("Send Mail to All Users while adding Issue, when priority is Low");
//        message.setSubject("Send Mail to All UsersList");
//        emailSender.send(message);
//        return true;
//    }
}
