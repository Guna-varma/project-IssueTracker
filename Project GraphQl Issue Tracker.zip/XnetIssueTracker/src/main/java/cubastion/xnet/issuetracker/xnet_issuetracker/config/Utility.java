package cubastion.xnet.issuetracker.xnet_issuetracker.config;

import lombok.SneakyThrows;

import java.sql.Time;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Utility {

    public static Date parseDate(String date) throws ParseException {
        if (date == null || date.isBlank()) return null;
        DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date parsedDate = outputFormat.parse(date);
        return parsedDate;
    }

    public static String parseDateasString(String date) throws ParseException {
        if (date == null || date.isBlank()) return null;
        DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = outputFormat.parse(date);
        String formattedDate = outputFormat.format(date1);

        return formattedDate;
    }

    @SneakyThrows
    public static Time strToTime(String time){
        DateFormat df = new SimpleDateFormat("HH:mm");
        return new Time(df.parse(time).getTime());
    }

    public static String findTimeDiff(String startTime, String endTime) {

        DateFormat df = new SimpleDateFormat("HH:mm");
        String timeDiff = null;

        try {
            // parse method is used to parse the text from a string to produce the Time
            long start = df.parse(startTime).getTime();
            long end = df.parse(endTime).getTime();

            // Calculating time difference in milliseconds
            long difference_In_Time = end - start;

            // Calculating time difference in seconds, minutes and hours
//            long diffSec = TimeUnit.MILLISECONDS.toSeconds(difference_In_Time) % 60;

            long diffMin = TimeUnit.MILLISECONDS.toMinutes(difference_In_Time) % 60;

            long diffHour = TimeUnit.MILLISECONDS.toHours(difference_In_Time) % 24;

            timeDiff = diffHour + ":" + diffMin;
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return timeDiff;
    }

    public static Date getTodayDate(){
          LocalDate todayDate=LocalDate.now();
        Date date1;
          DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            date1 = outputFormat.parse(todayDate.toString());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        return  date1;
    }
    public static String getTodayDay(){
        Format f = new SimpleDateFormat("EEEE");
        String todayDay = f.format(new Date());
        return todayDay;
    }
    public static int getCurrentMonth(){
       LocalDate month=LocalDate.now();
       int cMonth=month.getMonth().getValue();
        return cMonth;
    }










//    public static void findDifference(String start_date,
//                               String end_date)
//    {
//        // SimpleDateFormat converts the
//        // string format to date object
//        DateFormat df = new SimpleDateFormat("HH:mm:ss");
//
//        // Try Class
//        try {
//
//            // parse method is used to parse
//            // the text from a string to
//            // produce the date
//            Date d1 = sdf.parse(start_date);
//            Date d2 = sdf.parse(end_date);
//
//            // Calucalte time difference
//            // in milliseconds
//            long difference_In_Time
//                    = d2.getTime() - d1.getTime();
//
//            // Calucalte time difference in seconds,
//            // minutes, hours, years, and days
//            long difference_In_Seconds
//                    = TimeUnit.MILLISECONDS
//                    .toSeconds(difference_In_Time)
//                    % 60;
//
//            long difference_In_Minutes
//                    = TimeUnit
//                    .MILLISECONDS
//                    .toMinutes(difference_In_Time)
//                    % 60;
//
//            long difference_In_Hours
//                    = TimeUnit
//                    .MILLISECONDS
//                    .toHours(difference_In_Time)
//                    % 24;
//
//            long difference_In_Days
//                    = TimeUnit
//                    .MILLISECONDS
//                    .toDays(difference_In_Time)
//                    % 365;
//
//            long difference_In_Years
//                    = TimeUnit
//                    .MILLISECONDS
//                    .toDays(difference_In_Time)
//                    / 365l;
//
//            // Print the date difference in
//            // years, in days, in hours, in
//            // minutes, and in seconds
//            System.out.print(
//                    "Difference"
//                            + " between two dates is: ");
//
//            // Print result
//            System.out.println(
//                    difference_In_Years
//                            + " years, "
//                            + difference_In_Days
//                            + " days, "
//                            + difference_In_Hours
//                            + " hours, "
//                            + difference_In_Minutes
//                            + " minutes, "
//                            + difference_In_Seconds
//                            + " seconds");
//        }
//        catch (ParseException e) {
//            e.printStackTrace();
//        }
//    }

}
