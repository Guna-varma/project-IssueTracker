package cubastion.xnet.issuetracker.xnet_issuetracker.users.controller;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.FilterKey;

import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter.JoinFiltersSpecification;
import cubastion.xnet.issuetracker.xnet_issuetracker.issues.Issues;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.UserPage;
import cubastion.xnet.issuetracker.xnet_issuetracker.pagination.responses.UserPaginationResponse;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.repo.UserRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.service.UserService;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.entity.User;
import cubastion.xnet.issuetracker.xnet_issuetracker.users.graphql.AddUserInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.*;

@Controller
public class UserController {

    @Autowired
    private UserService service;

    @Autowired
    private UserRepository repo;

    @MutationMapping
    private User addUser(@Argument("addUserInput") AddUserInput addUserInput) {
        User u = new User();
        if (addUserInput.getUserName().isBlank()) {
            throw new xNetInvalidInputException("Please Enter valid UserName!");
        } else {
            u.setUserName(addUserInput.getUserName());
        }
        if (addUserInput.getFullName().isBlank()) {
            throw new xNetInvalidInputException("Please Enter valid FullName!");
        } else {
            u.setFullName(addUserInput.getFullName());
        }
        if (addUserInput.getPassword().isBlank()) {
            throw new xNetInvalidInputException("Please Enter valid Password!");
        } else {
            u.setPassword(addUserInput.getPassword());
        }
        if (addUserInput.getEmail().isBlank()) {
            throw new xNetInvalidInputException("Please Enter valid EMail Address!");
        } else {
            u.setEmail(addUserInput.getEmail());
        }
        u.setActive(addUserInput.getActive());
        return service.add(u);
    }

    @QueryMapping
    private List<User> getUsersByRoleIdAndIssueId(@Argument(name = "roleIds") String[] roleIds, @Argument(name = "issueId") Long issueId){
        return service.findAllUsersByRoleIdAndIssueId(roleIds,issueId);
    }

    @QueryMapping
    private List<User> findAllUsersByRoleId(@Argument(name = "roleIds") String[] roleIds){
        return service.findAllUsersByRoleId(roleIds);
    }



    @QueryMapping
    private List<User> getAllUser() {
        return service.getAll();
    }

    @QueryMapping
    private Optional<User> getUserById(@Argument Long id) {
        return service.getUserById(id);
    }

    @MutationMapping
    private User updateUser(@Argument("updateUserInput") User user) {
        return service.update(user);
    }

    @MutationMapping
    private String deleteUser(@Argument Long id) {
        service.delete(id);
        return "User Deleted Successfully!";
    }

    @QueryMapping
    public List<User> usersWithFilter(@Argument("filter") FilterKey filter) {
        return service.userWithFilter(filter);
    }

    @QueryMapping
    public Page<User> userPage(@Argument(name = "page") Integer pageNumber, @Argument(name = "offSet") Integer offSet) {
        return service.userPage(pageNumber, offSet);
    }

    @QueryMapping
    public List<User> getAllUsersById(@Argument("ids") Long[] ids){
        return (List<User>) repo.findAllById(List.of(ids));
    }
    @QueryMapping
    public UserPaginationResponse<List<User>> userPagination(@Argument(name = "page") Integer pageNumber, @Argument(name = "offset") Integer offset) {
        return service.userPagination(pageNumber,offset);
    }

    @QueryMapping
    public UserPage userPaginationNew(@Argument Integer page, @Argument Integer offSet) {
        return service.userPageNew(page, offSet);
    }

    @QueryMapping
    public List<User> userJoinFilter(@Argument("filter") RequestDto requestDto) {
        return service.userJoinFilter(requestDto);
    }

    @QueryMapping
    public List<User> userMultiJoinFilter(@Argument("filter") RequestDto requestDto) {
        return service.userMultiJoinFilter(requestDto);
    }

    @QueryMapping
    public List<User> userJunctionTableFilter(@Argument("filter") RequestDto requestDto){
        return service.userJunctionTableFilter(requestDto);
    }



}