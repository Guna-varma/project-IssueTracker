package cubastion.xnet.issuetracker.xnet_issuetracker.filtering.joinFilter;

import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.RequestDto;
import cubastion.xnet.issuetracker.xnet_issuetracker.filtering.dto.SearchRequestDto;

import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Service
public class JoinFiltersSpecification<T> {

    @PersistenceContext
    private EntityManager entityManager;

    public Specification<T> getSearchSpecification(SearchRequestDto searchRequestDto) {

        return new Specification<T>() {
            @Override
            public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                return criteriaBuilder.equal(root.get(searchRequestDto.getColumn()), searchRequestDto.getValue());
            }
        };

    }

    public Specification<T> getSearchSpecification(List<SearchRequestDto> searchRequestDtos, RequestDto.GlobalOperator globalOperator) {
        return (root, query, criteriaBuilder) -> {

            List<Predicate> predicates = new ArrayList<>();

            for (SearchRequestDto requestDto : searchRequestDtos) {

                switch (requestDto.getOperation()) {

                    case "contains":
                        Predicate joinLike = criteriaBuilder.like(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), "%" + requestDto.getValue() + "%");
                        predicates.add(joinLike);
                        break;

                    case "equal":
                        Predicate joinequal = criteriaBuilder.equal(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), requestDto.getValue());
                        predicates.add(joinequal);
                        break;

                    case "startsWith":
                        Predicate joinStartsWith = criteriaBuilder.like(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), requestDto.getValue() + "%");
                        predicates.add(joinStartsWith);
                        break;

                    case "endsWith":
                        Predicate joinEndsWith = criteriaBuilder.like(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), "%" + requestDto.getValue());
                        predicates.add(joinEndsWith);
                        break;

                    case "eq":
                        Predicate joinEq = criteriaBuilder.equal(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue()));
                        predicates.add(joinEq);
                        break;

                    case "gt":
                        Predicate joinGt = criteriaBuilder.gt(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue()));
                        predicates.add(joinGt);
                        break;

                    case "lt":
                        Predicate joinLt = criteriaBuilder.lt(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue()));
                        predicates.add(joinLt);
                        break;

                    case "le":
                        Predicate joinLe = criteriaBuilder.le(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue()));
                        predicates.add(joinLe);
                        break;

                    case "ge":
                        Predicate joinGe = criteriaBuilder.ge(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), Integer.parseInt(requestDto.getValue()));
                        predicates.add(joinGe);
                        break;

                    case "RANGE":
                        Predicate joinRange = criteriaBuilder.and(criteriaBuilder.greaterThanOrEqualTo(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()),
                                        Integer.parseInt(requestDto.getValue())),
                                criteriaBuilder.lessThanOrEqualTo(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()),
                                        Integer.parseInt(requestDto.getToValue())));
                        predicates.add(joinRange);
                        break;

                    case "NOT":
                        Predicate joinNot = criteriaBuilder.notLike(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()), "%" + requestDto.getValue() + "%");
                        predicates.add(joinNot);
                        break;

                    case "IN":
                        Predicate joinIn = criteriaBuilder.or(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()).in(requestDto.getValuesIN()));
                        predicates.add(joinIn);
                        break;

                    case "INT_BETWEEN":
                        Predicate joinInBetween = criteriaBuilder.between(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()),
                                Integer.parseInt(requestDto.getValue()),
                                Integer.parseInt(requestDto.getToValue()));
                        predicates.add(joinInBetween);
                        break;

                    case "DATE_BETWEEN":
                        Predicate joinDateBetween = criteriaBuilder.between(root.join(requestDto.getJoinTable()).get(requestDto.getColumn()),
                                Date.valueOf(requestDto.getValue()),
                                Date.valueOf(requestDto.getToValue()));
                        predicates.add(joinDateBetween);
                        break;

                    default:
                        throw new xNetInvalidInputException("Unexpected value: " + requestDto.getOperation() + ", please add valid Operation Name");
                }
            }

            if (globalOperator.equals(RequestDto.GlobalOperator.AND)) {
                return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
            } else {
                return criteriaBuilder.or(predicates.toArray(new Predicate[0]));
            }

        };
    }
}