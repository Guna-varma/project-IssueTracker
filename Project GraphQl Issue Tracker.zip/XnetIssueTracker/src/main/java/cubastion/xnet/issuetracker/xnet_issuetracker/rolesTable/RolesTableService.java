package cubastion.xnet.issuetracker.xnet_issuetracker.rolesTable;

import cubastion.xnet.issuetracker.xnet_issuetracker.columnAttribute.repository.RolesTableRepository;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetInvalidInputException;
import cubastion.xnet.issuetracker.xnet_issuetracker.error_Handling.xNetNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RolesTableService implements RolesTableServiceImpl {

    @Autowired
    private RolesTableRepository repo;

    @Override
    public RolesTable addRolesTable(RolesTable rolesTable) {
        try{
            return repo.save(rolesTable);
        }catch (Exception e){
            throw new xNetInvalidInputException("Failed to create RolesTable : Please add Input fields!");
        }
    }

    @Override
    public List<RolesTable> getAllRolesTable() {
        List<RolesTable> rolesTableList = null;
        try{
            rolesTableList = repo.findAll();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
        if (rolesTableList.isEmpty())
            throw new xNetNotFoundException("RolesTable List is Null");
        return rolesTableList;
    }


    @Override
    public Optional<RolesTable> getByIdRolesTable(Long id) {
        return Optional.ofNullable(repo.findById(id).orElseThrow(
                () -> new xNetNotFoundException("RolesTable with ID: " + String.valueOf(id) + " is not found")
        ));
    }
}
