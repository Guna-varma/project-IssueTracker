//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.stereotype.Component;
//import org.springframework.stereotype.Service;
//
//@Service
//public class EmailServiceImpl {
//
//    @Autowired
//    private JavaMailSender emailSender;
//private void sendSimpleMessage(String to, String subject, String text)
//{
//    SimpleMailMessage message = new SimpleMailMessage();
//    message.setFrom("devxnet@cubastion.com");
//    message.setTo("somiya.parmar@cubastion.com");
//    message.setSubject("testing");
//    message.setText("message sent successfully");
//    emailSender.send(message);
//}
//}

